# Resumos visuais de Direito Administrativo · MapasPro

Entrega de 28/10/2026.

- `Previa_Resumo_Item_1_MapasPro_v1.pdf`: exemplar visual em oito páginas.
- `Previa_Resumo_Item_1_MapasPro_v1.html`: exemplar navegável, com temas claro/escuro e fontes incorporadas.
- `Triagem_e_Guia_Visual_Resumos_DAD_MapasPro_v1.md`: triagem dos 16 PDFs, 31 achados dirigidos, padrão visual, recursos novos e ordem de produção.
- `dados/`: inventário, índice estrutural das 404 páginas, achados, fontes, tokens, proveniência e conteúdo do piloto.
- `ativos/`: duas figuras SVG editáveis.
- `integracao/`: fragmento, estilos e instrução para adaptação da v17.
- `fontes/`: Atkinson Hyperlegible e licença OFL.
- `continuidade/`: scripts de autoria, registro de verificações e ponto de retomada.

O piloto abrange o item 1 e os subitens 1.1 e 1.2. Não equivale à conclusão da primeira leva, composta pelos itens principais 1, 2 e 3. Os demais onze itens não foram redesenhados nesta entrega.

Os originais e o arquivo v17 não foram alterados. Nenhum conteúdo foi publicado ou importado na plataforma. A triagem dos dezesseis documentos é editorial; a conferência normativa de cada frase, tabela e imagem permanece pendente. Os achados dirigidos não são um inventário exaustivo de erros.

Questões didáticas da prévia são inéditas e estão identificadas. As 1.321 questões da auditoria anterior são corpus de referência; esta entrega não ampliou a confirmação de gabaritos oficiais.

Fontes tipográficas obtidas do repositório Google Fonts, diretório `ofl/atkinsonhyperlegible`, em 28/10/2026. Os arquivos da marca e o texto fornecido foram tratados como materiais próprios da MapasPro conforme declaração do usuário.
