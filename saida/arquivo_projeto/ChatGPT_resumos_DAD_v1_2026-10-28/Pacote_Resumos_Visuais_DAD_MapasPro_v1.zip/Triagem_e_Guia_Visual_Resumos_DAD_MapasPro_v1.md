# MapasPro · Resumos visuais de Direito Administrativo para a Câmara

Triagem editorial e especificação visual v1 · 28/10/2026

## Decisões incorporadas

O conteúdo e os elementos visuais dos dezesseis PDFs são materiais próprios da MapasPro, conforme declaração do usuário. Podem ser reaproveitados após conferência. A adaptação seguirá o sistema da plataforma: papel, tinta azul-escura, marcador amarelo, verde/vermelho reservados a certo/errado, modo escuro e leitura em coluna. Infográficos precisos serão redesenhados preferencialmente em SVG. A ordem é a do edital, com levas dos itens 1–3, 4–6, 7–9 e 10–12.

A primeira entrega de desenho é uma prévia do **item 1, incluindo 1.1 e 1.2**. Esses são subitens do primeiro tópico, não uma leva de três itens principais. A primeira leva somente estará completa quando atos e agentes também tiverem resumos próprios. A prévia é o exemplar concreto para a revisão visual antes da expansão.

## O que foi efetivamente examinado

- Inventário e extração dos 16 PDFs, total de 404 páginas físicas; os originais foram preservados.
- Inspeção de todas as páginas em folhas de contato e ampliação de figuras/quadros selecionados. A inspeção de miniaturas identifica composição; não comprova correção de todo texto contido em imagens.
- Leitura dirigida do texto extraído, dos sumários, revisões finais, blocos pertinentes ao piloto e trechos de risco; mapeamento editorial dos 16 documentos.
- Conferência primária dirigida de 31 achados conceituais, normativos, jurisprudenciais ou temporais. Não é contagem exaustiva de erros, nem índice de qualidade dos PDFs.
- Recuperação e leitura do código da prévia `02_v17_template.html.txt`, identificada como v17, prévia não publicada de 21/10/2026. Tokens e ponto de renderização do resumo foram conferidos no arquivo. A cópia original não foi alterada.
- Uso da base de 1.321 questões como evidência editorial: 1.002 enquadradas integralmente, 17 parcialmente e 302 em reserva. Somente 25 gabaritos oficiais estavam confirmados na auditoria anterior. Esta tarefa não validou os demais gabaritos nem importou questões.

**Limites:** a revisão normativa de cada frase e de todas as figuras dos 16 PDFs permanece pendente. A triagem não concede liberação para publicação. Os testes desta entrega verificam o protótipo separado; não comprovam integração na aplicação, preservação de sessões ou aprovação independente por outro modelo. A segunda conferência feita pelo próprio executor não foi rotulada como QA independente.

As páginas citadas abaixo são a posição física no PDF, iniciada em 1. A numeração impressa é inconsistente em alguns arquivos; várias contracapas mostram “16”. Usar sempre documento + página física.

## Resultado editorial

Há uma identidade visual própria que vale preservar: títulos em faixas, alto contraste, amarelo de marca, comparação em tabelas, sinalização de alertas e fechamento de revisão. Há também conteúdo que exige reconstrução. A beleza da diagramação não funciona como validação normativa.

As decisões abaixo são por documento e por bloco, sem percentuais fictícios de aproveitamento. “Adaptar” significa aproveitar estrutura e conteúdo elegível depois das correções; “reescrever núcleos” significa preservar o objetivo didático e refazer a explicação; “reserva com recortes” mantém o acervo, usando apenas trechos vinculados ao edital.

| ID | Resumo | Páginas | Destino no edital | Decisão |
|---|---|---:|---|---|
| R12 | 1. INTRODUÇÃO AO DIREITO ADMINISTRATIVO | 27 | 1.1 | ADAPTAR |
| R13 | 2. ADMINISTRAÇÃO PÚBLICA | 25 | 1; 1.2 | REESCREVER NÚCLEOS |
| R14 | 3. ORGANIZAÇÃO ADMINISTRATIVA | 28 | 1.2; recortes em 8.2 | ADAPTAR COM CORREÇÕES |
| R08 | 6. ATOS ADMINISTRATIVOS | 27 | 2.1 | REESCREVER NÚCLEOS |
| R15 | 4. AGENTES PÚBLICOS | 20 | 3; 3.1; 3.2 | REESCREVER NÚCLEOS |
| R04 | LEI 8.112-90 - REGIME JURÍDICO ÚNICO DOS SERVIDORES DA UNIÃO | 39 | 3.4; 4.2; 4.3 | ADAPTAR COM ATUALIZAÇÃO |
| R01 | LEI DO PROCESSO ADMINISTRATIVO | 20 | 4.4 | ADAPTAR COM CORREÇÕES |
| R16 | 5. PODERES ADMINISTRATIVOS | 24 | 5.1; 5.2 | ADAPTAR COM CORREÇÃO CRÍTICA |
| R11 | 9. RESPONSABILIDADE CIVIL DO ESTADO | 23 | 6.1 a 6.5 | REESCREVER NÚCLEOS |
| R06 | LEI DE IMPROBIDADE ADMINISTRATIVA | 23 | 7 | REESCREVER NÚCLEOS |
| R10 | 8. CONTROLE DA ADMINISTRAÇÃO PÚBLICA | 21 | recortes em 2.1 e 9.2 | RECORTAR |
| R07 | LEI DE LICITAÇÕES E CONTRATOS | 27 | 10; 10.1 a 10.7 | REESCREVER NÚCLEOS |
| R05 | LEI DE ACESSO À INFORMAÇÃO | 21 | 11; conexão em 8.3 | ADAPTAR COM CORREÇÕES |
| R03 | LEI GERAL DE PROTEÇÃO DE DADOS | 32 | 12 | ADAPTAR COM RECONSTRUÇÃO DE FIGURAS |
| R09 | 7. SERVIÇO PÚBLICO | 22 | apenas recortes em 1.2 e 6 | RESERVA COM RECORTES |
| R02 | LEI GERAL DE CONCESSÕES | 25 | apenas recortes em 1.2 e 6 | RESERVA COM RECORTES |

## Triagem de cada resumo

### R12 · 1. INTRODUÇÃO AO DIREITO ADMINISTRATIVO

**Destino:** 1.1. **Decisão:** ADAPTAR.

**Aproveitar:** pp. 13–19: princípios; pp. 24–26: estrutura de revisão e pares de confusão.

**Reservar/redistribuir:** pp. 4–10: escolas, história e fontes da disciplina ficam em apoio, sem virar unidade obrigatória do item 1.

**Corrigir ou conferir:** p. 18 mantém referência cancelada; p. 15 iguala violação da moralidade a improbidade. Corrigir também as generalizações sobre publicidade, continuidade e indenização por revogação.

**Design observado:** pp. 7, 8, 11, 13, 17 e 20: boa intenção de comparação, mas excesso de miniaturas, cores e textos em imagem.

**Recurso proposto:** LIMPE em cinco linhas; comparação anulação/revogação será aprofundada no item 2.

**Rastreio:** N08,N09. QA normativo integral pendente.

### R13 · 2. ADMINISTRAÇÃO PÚBLICA

**Destino:** 1; 1.2. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 4–15: aproveitar as perguntas e a disposição das comparações; pp. 16–22: usar como lista de conceitos a conferir.

**Reservar/redistribuir:** Evitar duplicar a organização do R14. O conceito geral da disciplina não substitui Estado, governo e Administração.

**Corrigir ou conferir:** Reescrever sentidos amplo/estrito, soberania dos entes, relação órgão/CNPJ, criação das estatais e exemplos. A matriz antiga não está pronta para publicação.

**Design observado:** pp. 5, 10, 13 e 22: diagramas valiosos como referência de composição; os rótulos precisam ser refeitos.

**Recurso proposto:** Duas lentes da Administração e duas relações organizacionais, sem usar CNPJ como teste de personalidade.

**Rastreio:** N01,N02,N03,N04,N29,N30. QA normativo integral pendente.

### R14 · 3. ORGANIZAÇÃO ADMINISTRATIVA

**Destino:** 1.2; recortes em 8.2. **Decisão:** ADAPTAR COM CORREÇÕES.

**Aproveitar:** pp. 4–16: organização, órgãos e entidades; pp. 20–24: agências e consórcios após revisão.

**Reservar/redistribuir:** pp. 17–19: terceiro setor migra para 8.2, com ligação de retorno; não repetir integralmente em 1.2.

**Corrigir ou conferir:** Corrigir falência das estatais, prazo em quádruplo do CPC, contrato de agência executiva e maioria do capital votante. Exemplos de empresas e regime de pessoal precisam de data e lei própria.

**Design observado:** pp. 5, 8, 11, 15, 17, 22 e 24: substituir peças densas por comparações menores.

**Recurso proposto:** Órgão/entidade; EP/SEM; reguladora/executiva em recursos distintos.

**Rastreio:** N05,N06,N07,N29. QA normativo integral pendente.

### R08 · 6. ATOS ADMINISTRATIVOS

**Destino:** 2.1. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 4–5 e 8–18: estrutura de classificações e espécies; pp. 24–26: formato comparativo e revisão.

**Reservar/redistribuir:** Falta desenvolvimento próprio de 2.2, responsabilidade do parecerista. Não preencher com um parágrafo genérico sobre atos enunciativos.

**Corrigir ou conferir:** Refazer os elementos, a relação entre motivo e motivação, os vícios e a convalidação. A sigla da p. 6 anuncia seis elementos e lista nove entradas. Revisar caducidade e os exemplos de autoexecutoriedade.

**Design observado:** p. 12: contraste vinculado/discricionário é útil; tabelas de pp. 6–7 e 20–22 precisam de reconstrução jurídica.

**Recurso proposto:** Cinco elementos; decisão anular/revogar/convalidar com limites; parecer em peça própria.

**Rastreio:** N10,N11,N12. QA normativo integral pendente.

### R15 · 4. AGENTES PÚBLICOS

**Destino:** 3; 3.1; 3.2. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 3–12: categorias, vínculos, ingresso, remuneração e previdência como roteiro; p. 17: responsabilidades como conexão ao item 4.

**Reservar/redistribuir:** pp. 13–16: militares estaduais ficam em reserva para esta trilha. Falta tratamento específico de requisição, item 3.3.

**Corrigir ou conferir:** Corrigir artigo do concurso, acumulação de saúde, mandato eletivo e promoção/progressão. O PDF da Lei 8.112 será a referência principal para o recorte federal.

**Design observado:** p. 4: classificação pode virar lista hierárquica leve. As tabelas de pp. 8–9 não podem ser reaproveitadas como estão.

**Recurso proposto:** Cargo/emprego/função; ingresso/permanência; requisição em quadro próprio.

**Rastreio:** N14,N15,N16,N17. QA normativo integral pendente.

### R04 · LEI 8.112-90 - REGIME JURÍDICO ÚNICO DOS SERVIDORES DA UNIÃO

**Destino:** 3.4; 4.2; 4.3. **Decisão:** ADAPTAR COM ATUALIZAÇÃO.

**Aproveitar:** pp. 5–20: provimento, posse, exercício, direitos e vantagens; pp. 21–35: deveres, proibições, responsabilidades e PAD.

**Reservar/redistribuir:** Distribuir por item, com uma única origem editorial. Não colocar o PAD inteiro em agentes e repeti-lo no item 4.

**Corrigir ou conferir:** Atualizar a acumulação conforme EC 138/2025; conferir licenças, incorporações, inspeção de saúde, estágio e normas aplicáveis à Câmara. Separar lei estatutária de regulamentos do Executivo.

**Design observado:** pp. 7, 9, 12, 14, 19, 22, 26 e 28: bons temas visuais, exigindo revisão dos valores e rótulos.

**Recurso proposto:** Linha nomeação–posse–exercício; quadro de licenças; matriz infração–pena–procedimento.

**Rastreio:** N18. QA normativo integral pendente.

### R01 · LEI DO PROCESSO ADMINISTRATIVO

**Destino:** 4.4. **Decisão:** ADAPTAR COM CORREÇÕES.

**Aproveitar:** pp. 4–16: princípios, direitos, instrução, motivação, recursos, competência e decisão.

**Reservar/redistribuir:** Fluxo em cinco etapas é uma síntese didática, não rito universal obrigatório. Diferenciar processo geral e PAD.

**Corrigir ou conferir:** Ampliar âmbito aos Poderes Legislativo e Judiciário federais na função administrativa. Corrigir artigos das alegações finais, reconsideração e a referência inexistente ao art. 2º, XXI.

**Design observado:** p. 6: mapa de princípios é denso; pp. 9–10: fluxo deve separar garantias transversais de etapas.

**Recurso proposto:** Linha com marcos e prazos vinculados ao evento que inicia a contagem.

**Rastreio:** N13. QA normativo integral pendente.

### R16 · 5. PODERES ADMINISTRATIVOS

**Destino:** 5.1; 5.2. **Decisão:** ADAPTAR COM CORREÇÃO CRÍTICA.

**Aproveitar:** pp. 5–14 e 17–23: poderes, discricionariedade, hierarquia, abuso e pares de confusão.

**Reservar/redistribuir:** Detalhes de PAD ligam ao item 4; delegação de competência também liga ao processo, sem confundir com polícia.

**Corrigir ou conferir:** Substituir o texto da p. 15 pelo Tema 532 com todos os seus requisitos. Não estender o precedente a toda empresa privada nem ao Sistema S automaticamente.

**Design observado:** pp. 4, 8, 11, 13 e 17: escolher uma relação por figura; não colorir cada ramo de modo diferente.

**Recurso proposto:** Delegação do poder de polícia por requisitos; excesso de poder/finalidade em dois casos.

**Rastreio:** N19. QA normativo integral pendente.

### R11 · 9. RESPONSABILIDADE CIVIL DO ESTADO

**Destino:** 6.1 a 6.5. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 4–5 e 9–20: dano, nexo, excludentes, omissões e regresso como estrutura de estudo.

**Reservar/redistribuir:** Evitar ampliar atos legislativos e jurisdicionais em bloco desproporcional ao edital; usar apenas o necessário às hipóteses de responsabilidade.

**Corrigir ou conferir:** Excluir responsabilidade automática e a equivalência ação=objetiva/omissão=subjetiva. Refazer exemplos, separar culpa exclusiva de concorrente e condições do nexo.

**Design observado:** pp. 8, 12 e 20: boa oportunidade de trilha causal; p. 18: pirâmide de imunidade sugere escala jurídica inadequada.

**Recurso proposto:** Dano–nexo–imputação; Estado perante vítima versus regresso; omissões por dever de proteção.

**Rastreio:** N20. QA normativo integral pendente.

### R06 · LEI DE IMPROBIDADE ADMINISTRATIVA

**Destino:** 7. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 4–7: sujeitos; pp. 11–19: usar como checklist de assuntos, após reconstruir tipos, sanções, processo e prescrição.

**Reservar/redistribuir:** Retirar o benefício tributário do art. 10-A como quarta categoria vigente. Não excluir a hipótese material de estudo: reenquadrar quando couber e explicar a sucessão normativa.

**Corrigir ou conferir:** Confrontar reforma de 2021 e ADIs julgadas em 2026. Não tratar a violação genérica de princípios como tipo aberto nem manter quatro anos como regra atual universal.

**Design observado:** pp. 10 e 13: árvore e blocos podem funcionar, com classificação e limites corretos; evitar pirâmide que invente hierarquia.

**Recurso proposto:** Matriz arts. 9º/10/11; sanções por tipo; linha temporal de mudanças.

**Rastreio:** N09,N21,N22. QA normativo integral pendente.

### R10 · 8. CONTROLE DA ADMINISTRAÇÃO PÚBLICA

**Destino:** recortes em 2.1 e 9.2. **Decisão:** RECORTAR.

**Aproveitar:** pp. 6–7 e 15: legalidade/mérito e autotutela para atos; trechos de auditoria/controle podem ilustrar 9.2, após contextualização.

**Reservar/redistribuir:** O edital não traz controle da Administração como capítulo geral autônomo. CPI, impeachment, ações judiciais e competências detalhadas do TCU ficam em reserva, salvo vínculo específico demonstrado.

**Corrigir ou conferir:** Não equiparar o mecanismo controle da governança ao programa inteiro de controle externo. Reavaliar classificações e exemplos à luz do recorte de destino.

**Design observado:** p. 14: prévio/concomitante/posterior é uma boa comparação de tempo, sem necessidade de três ilustrações pesadas.

**Recurso proposto:** Governança: liderança–estratégia–controle; figura nova para a relação governança/gestão.

**Rastreio:** Escopo; revisão dirigida pendente. QA normativo integral pendente.

### R07 · LEI DE LICITAÇÕES E CONTRATOS

**Destino:** 10; 10.1 a 10.7. **Decisão:** REESCREVER NÚCLEOS.

**Aproveitar:** pp. 4–15: princípios, modalidades e fases; pp. 17–23: contratos, alterações e fiscalização, após conferência.

**Reservar/redistribuir:** Complementar contratação direta, procedimentos auxiliares, ETP/TR e demais subitens efetivamente exigidos. O sumário do PDF não cobre sozinho o item 10.

**Corrigir ou conferir:** Corrigir vigência, critérios de julgamento e referências. Rever a alegação de solidariedade automática entre gestor/fiscal e não importar limites monetários sem ano.

**Design observado:** pp. 8, 11, 13 e 19: redesenhar como seleção, procedimento ou linha de vigência; cada visual tem uma função diferente.

**Recurso proposto:** Competição viável/inviável; modalidade/critério; linha do contrato com limites e exceções.

**Rastreio:** N23,N24; solidariedade pendente de revisão específica. QA normativo integral pendente.

### R05 · LEI DE ACESSO À INFORMAÇÃO

**Destino:** 11; conexão em 8.3. **Decisão:** ADAPTAR COM CORREÇÕES.

**Aproveitar:** pp. 4–16: transparência, direitos, sigilos, pedidos e recursos; pp. 19–20: formato de revisão.

**Reservar/redistribuir:** Separar a Lei nacional das instâncias/regulamentos próprios do Executivo federal. Não transplantar fluxo CGU para Câmara sem verificar norma aplicável.

**Corrigir ou conferir:** pp. 14–15 alternam dias úteis e contínuos; refazer a contagem. p. 17 mistura sanções de agentes com o regime dos particulares do art. 33.

**Design observado:** pp. 5 e 8: boas relações visuais. O prazo do fluxo deve começar pelo acesso imediato, com 20+10 somente quando cabível.

**Recurso proposto:** Árvore do pedido; linha de prazo; três regimes: classificação, informação pessoal e outros sigilos.

**Rastreio:** N25,N26. QA normativo integral pendente.

### R03 · LEI GERAL DE PROTEÇÃO DE DADOS

**Destino:** 12. **Decisão:** ADAPTAR COM RECONSTRUÇÃO DE FIGURAS.

**Aproveitar:** pp. 4–23 e 27–31: conceitos, bases, direitos, agentes, segurança e crianças como roteiro de conteúdo.

**Reservar/redistribuir:** LGPD permanece no curso por previsão expressa, embora não haja questão principal no lote auditado. Não fabricar selo de alta incidência.

**Corrigir ou conferir:** Atualizar ANPD; separar agentes de tratamento de outros participantes; rever consentimento obrigatório, sanções, anonimização e comunicação de incidentes.

**Design observado:** pp. 5, 8, 10, 13, 16, 18, 22 e 26: inspiração, sem copiar como imagem pronta. Pirâmides podem sugerir hierarquia ou gradação jurídica inexistente.

**Recurso proposto:** Diagrama controlador/operador com titular e encarregado em papéis separados; conjuntos para categorias de dados.

**Rastreio:** N27,N28,N31. QA normativo integral pendente.

### R09 · 7. SERVIÇO PÚBLICO

**Destino:** apenas recortes em 1.2 e 6. **Decisão:** RESERVA COM RECORTES.

**Aproveitar:** Trechos de prestação centralizada/descentralizada podem gerar exemplos em 1.2; responsabilidade do prestador ajuda o item 6.

**Reservar/redistribuir:** O capítulo completo de serviços, PPP e autorizações não está literalmente previsto como unidade autônoma. Não usar prazo de concessão/permissão como tabela universal.

**Corrigir ou conferir:** Expressões como indenização fácil, PPP mais justa e autorização raríssima precisam ser excluídas. Conferir cada regime antes de usar um exemplo.

**Design observado:** pp. 8, 17 e 19: relações visuais interessantes, mas a pirâmide de prazo/risco e as generalizações não devem migrar.

**Recurso proposto:** Para os recortes, figura de titularidade e execução; o restante fica no acervo complementar.

**Rastreio:** Escopo; mérito jurídico não integralmente revisado. QA normativo integral pendente.

### R02 · LEI GERAL DE CONCESSÕES

**Destino:** apenas recortes em 1.2 e 6. **Decisão:** RESERVA COM RECORTES.

**Aproveitar:** Usar concessão/permissão como exemplos de execução delegada e responsabilidade, com remissão ao regime próprio.

**Reservar/redistribuir:** Não transformar Lei 8.987 em unidade obrigatória sob o rótulo Lei 14.133. Detalhes de intervenção, política tarifária e extinção ficam em reserva nesta trilha.

**Corrigir ou conferir:** Conferir redação vigente, alcance de responsabilidade e distinções de modalidades, sem importar dados ou prazos do resumo por analogia.

**Design observado:** pp. 6, 8 e 18: boa estrutura comparativa, mas as camadas não podem sugerir ordem de importância inexistente.

**Recurso proposto:** Recorte de delegação em figura pequena; não produzir infográfico integral de concessões nesta etapa.

**Rastreio:** Escopo; mérito jurídico não integralmente revisado. QA normativo integral pendente.

## Quatro figuras que merecem atenção individual

| Figura ampliada | O que vale preservar | O que deve mudar |
|---|---|---|
| R03, p. 5: pirâmide de dados | Comparação visual imediata e exemplos junto das categorias | Dados sensíveis integram os pessoais, em vez de constituir classe exterior em degrau separado. Anonimização depende do contexto e dos meios razoáveis. Substituir a pirâmide por conjuntos e condições. |
| R03, p. 8: controlador, operador, titular e encarregado | Tentativa de mostrar relações e papéis | As muitas setas sem rótulo não dizem se representam instrução, solicitação ou comunicação. Separar as relações e retirar a legenda “Separação de Poderes”, que pode ser confundida com a estrutura constitucional. Atualizar ANPD. |
| R12, p. 17: funil da proporcionalidade | Sequência adequação–necessidade–ponderação, com uma pergunta em cada etapa | O carimbo “ato válido” e o rodapé prometem validade e eficácia plenas apenas por passar no teste. A proporcionalidade não substitui os demais requisitos de validade. Encerrar com conclusão restrita ao exame de proporcionalidade. |
| R14, p. 15: EP versus SEM | Linhas correspondentes para capital, forma e foro | Reescrever capital com as participações legais e maioria votante, evitar exemplos societários que exijam ressalvas e qualificar a regra de competência judicial. Trocar verde/laranja categóricos por tinta/marcador e reservar vermelho a julgamento de erro. |

Essas decisões são editoriais e gráficas; não foram somadas como novos achados ao inventário de 31 pontos dirigidos. Cada figura final deve ter sua própria revisão de texto, setas, rótulos e exemplos.

## Correções dirigidas antes da migração

Os achados indicam um ponto concreto e a ação necessária. Atualização posterior e erro originário são campos diferentes: nos casos temporais, a data de produção do PDF ainda precisa ser estabelecida. O julgamento histórico de questão de 2025 não será reescrito com regra nova de 2026.

| ID | Documento e página física | Natureza | Ação fundamentada | Fonte |
|---|---|---|---|---|
| N01 | R13, p. 8; 23 | Correção conceitual | Amplo/estrito não se distingue pelo número de Poderes envolvidos. Explicar função política + administrativa versus apenas administrativa; separar o eixo subjetivo/objetivo. | F01,F02 |
| N02 | R13, p. 9; 23 | Correção normativa | Entes federativos são autônomos. A soberania é atributo da República Federativa do Brasil, não de cada município ou estado. | F01 |
| N03 | R13, p. 14–15; 24 | Correção normativa | Órgão não tem personalidade própria; pode possuir inscrição no CNPJ. O cadastro não é teste de personalidade jurídica. | F02,F17 |
| N04 | R13, p. 19–21 | Correção normativa | A lei cria autarquia e autoriza a instituição de empresa pública e SEM. Distinguir fundações públicas de direito público e de direito privado. | F01,F03 |
| N05 | R14, p. 14; 16 | Correção normativa | A Lei 11.101 exclui EP e SEM de seu âmbito. Não ensinar como regra legal vigente que estatais econômicas podem falir. Discussões doutrinárias devem ser identificadas. | F04 |
| N06 | R14, p. 12 | Correção normativa | CPC art. 183 prevê prazo em dobro nas manifestações, com as ressalvas legais. Retirar a regra antiga de quádruplo para contestar. | F05 |
| N07 | R14, p. 21; 25–26 | Correção normativa | A qualificação como agência executiva do art. 51 da Lei 9.649 exige plano estratégico e contrato de gestão, não usar contrato de desempenho como sinônimo automático. | F19 |
| N08 | R12, p. 18 | Correção jurisprudencial | A Súmula 343 do STJ foi cancelada em 2021. Não apresentar conflito vigente com a Súmula Vinculante 5. | F06 |
| N09 | R12; R06, p. 15; 9 | Correção normativa | Imoralidade/ilegalidade não basta, por si, para improbidade. Exigir tipificação e dolo; no art. 11, observar as condutas taxativas e demais requisitos. | F09,F10 |
| N10 | R08, p. 6–7 | Correção conceitual | Reconstruir pelos cinco elementos tradicionais: competência, finalidade, forma, motivo e objeto. Motivo e motivação merecem comparação, sem inventar nova lista nuclear. | F16 |
| N11 | R08, p. 7; 20–21 | Correção normativa e doutrinária | Retirar a tese de que toda incompetência é insanável. Convalidação depende da natureza do vício e dos requisitos legais; competência não exclusiva admite saneamento na classificação usual. | F02,F16 |
| N12 | R08, p. 20 | Correção conceitual | Desvio de finalidade não deve aparecer como vício sanável na matriz tradicional. Reconstruir a tabela inteira para não reproduzir contradição com a própria p. 6. | F16 |
| N13 | R01, p. 4; 9; 13; 17–18 | Correção normativa | Lei 9.784 alcança Legislativo/Judiciário federais na função administrativa; alegações finais estão no art. 44; reconsideração no art. 56, §1º. Não existe inciso XXI no parágrafo único do art. 2º. | F02 |
| N14 | R15, p. 7 | Correção de referência | O concurso para investidura está no art. 37, II, e não no III, que trata da validade do concurso. | F01 |
| N15 | R15, p. 8 | Correção normativa | A exceção de saúde alcança dois cargos ou empregos privativos de profissionais de saúde com profissões regulamentadas, não apenas médicos. | F01 |
| N16 | R15, p. 8; 19 | Correção normativa | Não tratar todo mandato eletivo como hipótese genérica de acumulação. Separar as situações do art. 38, inclusive a condição de horários para vereador. | F01 |
| N17 | R15, p. 9; 19 | Correção conceitual | Promoção não permite ingresso livre em carreira diferente. Explicar desenvolvimento na carreira conforme lei específica e distinguir ascensão inconstitucional. | F18 |
| N18 | R04, p. 25–26; 36 | Atualização temporal | EC 138/2025 alterou professor + técnico/científico para professor + outro de qualquer natureza, observados os demais requisitos. A data de produção do PDF não está comprovada; não chamar a versão anterior de erro original. | F08 |
| N19 | R16, p. 15 | Correção jurisprudencial | Tema 532 permite delegação legal a pessoas de direito privado da indireta que preencham os requisitos da tese; contempla aplicação de multa. A fórmula somente consentimento/fiscalização não traduz o precedente. | F07 |
| N20 | R11, p. 6–8; 15; 22 | Correção jurisprudencial e didática | Eliminar responsabilidade automática e a equivalência absoluta entre omissão e culpa. Há responsabilidade objetiva por descumprimento de dever específico de proteção, como no Tema 592. | F20 |
| N21 | R06, p. 8–10; 20 | Correção normativa | Art. 10-A foi revogado em 2021. Não manter sua categoria como quarto grupo vigente. Reconstituir o enquadramento dos fatos nos tipos aplicáveis. | F09 |
| N22 | R06, p. 16 | Atualização jurisprudencial | STF afastou em 2026 o reinício pela metade do prazo prescricional. Não reproduzir quatro anos como regra atual automática; conferir a tese e sua aplicação temporal. | F10 |
| N23 | R07, p. 3; 24 | Correção normativa | Lei 14.133 entrou em vigor com sua publicação em 01/04/2021. Distinguir vigência, transição e revogação dos regimes anteriores. | F11 |
| N24 | R07, p. 16; 24 | Correção normativa | Art. 33 lista seis critérios, incluindo maior lance no leilão. O PDF anuncia cinco e cita art. 34 como rol. Refazer a matriz modalidade/critério. | F11 |
| N25 | R05, p. 14–15 | Inconsistência de contagem e referência | O texto alterna dias úteis/contínuos e o exemplo usa dias úteis. Corrigir o regime da contagem aplicável e indicar a prorrogação no art. 11, §2º. Acesso imediato vem antes do prazo subsidiário. | F12,F02 |
| N26 | R05, p. 17 | Correção normativa | Separar responsabilidade do agente do art. 32 das sanções do art. 33 para pessoa física/entidade privada vinculada. Não transplantar multa de três salários sem fundamento. | F12 |
| N27 | R03, p. 7; 21–22 | Correção normativa | Agentes de tratamento são controlador e operador. Titular e encarregado têm papéis próprios; o diagrama não pode classificá-los todos como agentes de tratamento. | F13 |
| N28 | R03, p. 4; 28–29 | Correção normativa | Consentimento não é base única para dados sensíveis ou de crianças/adolescentes. Manter hipóteses legais, condições e melhor interesse conforme o caso. | F13,F15 |
| N29 | R13; R14, p. 20; 16 | Correção normativa | Na SEM, a maioria relevante é das ações com direito a voto. Não substituir por maioria obrigatória de todo o capital social. | F03 |
| N30 | R13, p. 20 | Correção factual | Embrapa é empresa pública e foi colocada entre exemplos de SEM. Corrigir por sua lei instituidora; revalidar separadamente as demais empresas citadas. | F22 |
| N31 | R03, p. 24; 29 | Atualização normativa e referência | Lei 15.352/2026 disciplina a Agência Nacional de Proteção de Dados como autarquia especial vinculada ao MJSP. Reescrever a identificação e a atribuição histórica de sua natureza jurídica. | F14 |

Outros pontos são sinais para revisão, não conclusões já encerradas: matriz de autoexecutoriedade; caducidade de atos; responsabilidade solidária de gestor/fiscal; licenças e vantagens de servidores; exemplos atuais de estatais; sanções e incidentes na LGPD; prorrogação dos graus de sigilo; fluxo recursal próprio da Câmara. Não transportar essas afirmações para o produto com aparência de fato conferido.

## A cobertura do edital precisa ser construída

Os dezesseis títulos não equivalem aos doze itens. Há duplicidades em organização e agentes, capítulos em reserva e lacunas relevantes. Modelos de gestão pública e governança não aparecem como resumos dedicados. A ausência de questões no lote não retira conteúdo expresso do edital.

| Leva | Itens principais | Materiais de partida | Complementos necessários |
|---|---|---|---|
| 1 | 1 Fundamentos/organização; 2 Atos; 3 Agentes | R12, R13, R14; R08; R15 e R04 | Responsabilidade do parecerista (2.2), requisição (3.3), vínculos/garantias e atualizações |
| 2 | 4 Disciplinar/processo; 5 Poderes; 6 Responsabilidade | R04 e R01; R16; R11 | Fontes/princípios disciplinares; ritos e normas aplicáveis; jurisprudência por hipótese de responsabilidade |
| 3 | 7 Improbidade; 8 Modelos de gestão; 9 Governança | R06; recortes R14; recortes R10 | Produção dedicada dos itens 8 e 9; revisão das ADIs de 2026; redes, coprodução, valor público, governabilidade e mecanismos |
| 4 | 10 Licitações/contratos; 11 LAI; 12 LGPD | R07; R05; R03 | Subitens de planejamento/ETP/TR e contratação direta; regime da Câmara; ANPD e regulamentação aplicável |

No lote auditado, o item 1 e seus subitens somam 108 questões principais com aderência integral: 3 em 1, 30 em 1.1 e 75 em 1.2. É uma contagem do corpus, não previsão de prova. LGPD não tem questão principal; continua exigida pelo item 12. Uma questão com classificação secundária não deve ser somada novamente como ocorrência principal.

## Como traduzir a estética dos PDFs

| Referência nos PDFs | Decisão de adaptação | Função pedagógica |
|---|---|---|
| Capa preta com marca | Preservar no material de identidade; no tópico, abertura curta com número, título e promessa de aprendizagem | Entrar no conteúdo sem uma tela inteira de capa |
| Barra preta/título amarelo | Faixa de tinta azul-escura com amarelo; no escuro, faixa amarela com texto de tinta noturna escura | Hierarquia consistente e contraste verificado |
| Subtítulo em degradê amarelo | Marcador suave, filete amarelo e rótulo curto | Evitar ruído e manter identidade |
| Cabeçalho preto de tabela | Cabeçalho em tinta no claro; no escuro, superfície suave com destaque e texto claro | Comparar sem perder a leitura |
| Caixa azul de atenção | Fundo papel/suave com filete amarelo; rótulo textual ATENÇÃO | A cor azul fica para tinta/foco, sem inventar categoria por cor |
| Emojis e ícones variados | Ícones lineares consistentes, com legenda; retirar emoji decorativo | Evitar variação de aparência entre dispositivos |
| Etiqueta de probabilidade | Contagem auditada com denominador e recorte, quando útil; sem selo especulativo | Prioridade editorial apoiada em evidência |
| Resumo Relâmpago | Manter, reduzido a regras de decisão e pares essenciais | Revisar sem repetir a aula inteira |
| Possíveis Pegadinhas | Manter como trocas de conceitos com justificativa; exemplos novos identificados | Mostrar exatamente qual palavra muda o julgamento |
| Infográfico ilustrado com texto em pixels | Reconstruir relação em SVG/HTML, com texto selecionável e alternativa textual | Legibilidade, busca, acessibilidade e tema escuro |

As barras pretas não serão copiadas como imagens. O amarelo mantém a associação com a MapasPro; a tinta e as superfícies obedecem ao sistema da plataforma. Verde/vermelho só indicam a resposta certa/errada ou o julgamento explícito de uma afirmação. Não usá-los para pintar conceitos, tipos de entidade, fontes ou graus de importância.

## Tokens e regras de implementação

Tokens conferidos na v17 e empregados na prévia:

| Token | Claro | Escuro |
|---|---|---|
| Papel | `#FBFBF8` | `#14181E` |
| Tinta | `#1B2A41` | `#ECEEF1` |
| Tinta secundária | `#4F5B6B` | `#AEB5BF` |
| Regra | `#D9DCE1` | `#2F343C` |
| Superfície suave | `#F1F2EE` | `#1E232A` |
| Marcador | `#F2C94C` | `#E2BB45` |
| Marcador suave | `#FFF7D6` | `#2E2A1A` |
| Certo | `#2E7D5B` | `#5EBE92` |
| Errado | `#9C2E2E` | `#E27A7A` |
| Foco | `#1B6BB2` | `#7DB8F0` |

Fonte: Atkinson Hyperlegible, regular e negrito, com licença OFL incluída no pacote. Corpo web em 17 px, altura de linha 1,55–1,65, coluna máxima de 560 px e margem lateral de 18 px. O PDF é uma composição para leitura/impressão em A4; não define a largura da tela. O tamanho em pontos do PDF não deve ser copiado para CSS.

Usar 8/12/16/24/32 px como escala de espaço, títulos em sentença, parágrafos curtos e uma ideia visual por bloco. Tabelas de duas ou três colunas quando possível. No celular, uma comparação larga vira cartões por entidade com os mesmos rótulos; não reduzir a fonte até caber. Botões de pelo menos 44 px, foco visível, links descritivos e nenhuma informação dependente só de cor ou hover.

Cada figura precisa de título, relação explícita e legenda textual equivalente. As fontes do conteúdo ficam no fim da seção ou em detalhe acessível, com dispositivo e data de revisão. Não colocar recados de integração, hashes, pendências de QA ou metadados de produção dentro da experiência normal do aluno. Esses campos pertencem ao pacote editorial.

O SVG deve herdar os tokens, manter texto real e ter `title`/`desc`. Não desenhar um raster dentro de uma tag SVG. Pirâmides representam inclusão, níveis ou gradações apenas quando essa relação é verdadeira; uma lista de princípios não se torna hierarquia jurídica porque fica bonita em degraus.

## Estrutura de cada resumo

1. Número e título exatos do tópico, com uma frase sobre o que o aluno precisa distinguir.
2. Conceito e regra central, em poucas linhas.
3. Quadro ou figura que explique a relação mais difícil.
4. Requisitos, limites e exceções junto da regra a que pertencem.
5. Caso concreto curto, identificado como exemplo didático.
6. Troca de conceitos frequente no corpus, com referência auditável quando houver.
7. Resumo Relâmpago e fontes da versão.

O tamanho decorre da complexidade. Não impor o mesmo número de cartões a todos os tópicos. Um resumo de revisão não absorve todo o conteúdo da aula. O campo de cada subitem deve funcionar sozinho; o resumo do pai apenas organiza os filhos. Distinguir citação literal de lei, síntese explicativa e exemplo autoral.

## Imagens propostas ao longo do curso

Estas são indicações concretas de recursos, não uma lista de ilustrações decorativas. A prioridade significa momento de produção, não incidência de prova.

| Item | Recurso | O que deve tornar visível | Formato e cuidado | Momento |
|---|---|---|---|---|
| 1 | Duas lentes da Administração | Quem atua / atividade; amplo / estrito como outro eixo | SVG ou grade HTML; não reduzir ao Executivo | Piloto, produzido |
| 1.1 | LIMPE com situação concreta | Regra, exemplo e limite de cada princípio | HTML; cinco linhas, sem arco-íris | Piloto, produzido |
| 1.2 | Dentro da mesma PJ / pessoa distinta | Desconcentração, descentralização e vínculo | SVG + legenda equivalente | Piloto, produzido |
| 1.2 | Cria versus autoriza | Etapa legal e constituição de entidades | HTML/SVG; separar fundação pública/privada | Piloto, produzido |
| 2.1 | Decisão sobre o ato | Vício, conveniência, possibilidade de convalidação e limites | Fluxo com hipóteses explícitas | Leva 1 |
| 2.2 | Responsabilidade do parecerista | Tipo de parecer, conduta, elemento subjetivo e fonte | Quadro por hipótese; sem regra universal | Leva 1 |
| 3.3–3.4 | Movimentação e investidura | Requisição/cessão/remoção/redistribuição; posse/exercício | Comparação e linha de tempo em peças separadas | Leva 1 |
| 4.2–4.3 | Infração, pena e procedimento | Quem apura, limites da sindicância e PAD | Matriz e fluxo; não fundir ritos | Leva 2 |
| 4.4 | Prazo começa quando? | Evento inicial, duração, exceção e autoridade | Linha de tempo com marcos distintos | Leva 2 |
| 5 | Duas delegações diferentes | Competência administrativa / poder de polícia | Dois quadros, com requisitos do Tema 532 | Leva 2 |
| 6 | Da vítima ao Estado e ao agente | Imputação ao Estado e regresso com dolo/culpa | SVG de relações; não sugerir indenização automática | Leva 2 |
| 7 | Tipos e consequências | Arts. 9º/10/11 e sanções próprias | Matriz, com atualização e requisitos | Leva 3 |
| 8 | Modelos de gestão | Características, problemas e permanências | Comparação; não representar substituição histórica completa | Leva 3 |
| 8.2–8.4 | Rede e valor público | Atores, contribuição, entrega e resultado | Rede pequena + cadeia de valor separada | Leva 3 |
| 9 | Governança e gestão | Direcionar/avaliar/monitorar e executar/entregar | Relações e funções, sem organograma inventado | Leva 3 |
| 10 | Competição e contratação | Dispensa/inexigibilidade e processo de contratação direta | Árvore por requisitos; valores com ano | Leva 4 |
| 10.5–10.7 | Do planejamento à fiscalização | ETP, TR, edital, contrato e acompanhamento | Fluxo com produtos e responsáveis | Leva 4 |
| 11 | Pedido e resposta | Acesso imediato, prazo subsidiário, prorrogação e acesso parcial | Fluxo com as condições ao lado das setas | Leva 4 |
| 12 | Papéis na LGPD | Controlador/operador e canais com titular/encarregado/ANPD | SVG; agentes são só os dois primeiros | Leva 4 |
| 12 | Dados pessoais e sensíveis | Inclusão de sensíveis nos pessoais e anonimização contextual | Conjuntos, evitando pirâmide de valor | Leva 4 |

Não há necessidade identificada de fotografia ou ilustração raster nova no piloto. Para imagens narrativas futuras, produzir uma indicação com local, objetivo, conteúdo obrigatório e legenda; só usar quando ajudar a compreender um caso. Texto jurídico preciso permanece em HTML/SVG selecionável.

## Ponto técnico de integração verificado

Na v17, `vResumoVer()` obtém texto de `extra.resumo` ou do resumo de lote; aplica `paraResumo()` e depois `mdCurso2()`. Essa cadeia é o ponto a ampliar para blocos visuais. Não basta colar HTML/SVG em texto e presumir que será renderizado.

Recomendação de integração futura: adicionar um campo opcional de blocos estruturados, com tipos permitidos, referências e versão; manter o fluxo antigo para tópicos ainda não migrados. Construir os elementos com APIs seguras do DOM e componentes internos. Não admitir HTML/SVG arbitrário de dados externos. Usar ícones/figuras autorais do catálogo por identificador. Namespace `.mp-summary` para impedir que os estilos de outras telas contaminem o resumo.

O arquivo v17 recuperado contém extensões de paleta posteriores ao comentário v0.2. A prévia obedece à decisão expressa de papel/tinta/marcador e C/E, sem herdar automaticamente as demais categorias cromáticas. O conjunto F4 presente na v17 não foi confundido nem substituído pela auditoria separada de 1.321 questões.

## Critério de conclusão por leva

Para cada tópico: conferir os dispositivos efetivamente utilizados; preservar referência histórica quando necessária; revisar cada afirmação de tabela/figura; testar modo claro/escuro, 320/390 px e desktop, ampliação e teclado; confirmar leitura sem cor; verificar os exemplos e manter as questões reais separadas dos inéditos. Na trilha Câmara, a inclusão de questões reais permanece restrita a C/E conforme decisão anterior.

A revisão por modelo distinto prevista no fluxo ainda precisa ser executada; esta entrega prepara o material para isso. A avaliação estética e a decisão de publicação serão feitas sobre os arquivos concretos. A prévia não foi incorporada nem publicada na plataforma.

## Fontes primárias dos achados dirigidos

Consulta em 28/10/2026. Quando o acesso direto ao Planalto foi bloqueado, foram utilizados trechos indexados oficiais e versões institucionais da Câmara, Senado, STF, STJ ou órgãos competentes. O catálogo não declara leitura integral de todos os atos.

- **F01 — Constituição Federal**, arts. 1º, 2º, 18, 37 e 38. [Fonte oficial](https://www4.planalto.gov.br/legislacao/legis-federal/constituicao).
- **F02 — Lei 9.784/1999**, arts. 1º, 2º, 44, 53 a 56 e 66. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/leis/l9784.htm).
- **F03 — Lei 13.303/2016**, arts. 2º a 4º. [Fonte oficial](https://legis.senado.gov.br/norma/602528/publicacao/15636229).
- **F04 — Lei 11.101/2005**, art. 2º, I. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2005/lei/l11101.htm).
- **F05 — Código de Processo Civil**, art. 183. [Fonte oficial](https://www2.camara.leg.br/legin/fed/lei/2015/lei-13105-16-marco-2015-780273-normaatualizada-pl.html).
- **F06 — STJ, Súmula 343**, cancelamento em 28/04/2021, DJe 03/05/2021. [Fonte oficial](https://scon.stj.jus.br/SCON/sumstj/doc.jsp?b=SUMU&h=true&i=1&l=10&livre=%22343%22.num.&ordenacao=-%40NUM&p=false).
- **F07 — STF, Tema 532**, RE 633.782, delegação do poder de polícia. [Fonte oficial](https://portal.stf.jus.br/jurisprudenciaRepercussao/verAndamentoProcesso.asp?classeProcesso=RE&incidente=4005451&numeroProcesso=633782&numeroTema=532).
- **F08 — Emenda Constitucional 138/2025**, art. 37, XVI, b. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc138.htm).
- **F09 — Lei de Improbidade Administrativa**, arts. 1º, 9º a 12 e revogação do art. 10-A. [Fonte oficial](https://planalto.gov.br/ccivil_03/leis/l8429compilada.htm).
- **F10 — STF, Informativo 1225/2026**, ADIs 7.156 e 7.236; resumo artigo por artigo. [Fonte oficial](https://www.stf.jus.br/arquivo/cms/informativoSTF/anexo/Informativo_PDF/Informativo_stf_1225.pdf).
- **F11 — Lei 14.133/2021**, arts. 33 e 194. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm).
- **F12 — Lei de Acesso à Informação**, arts. 11, 32 e 33. [Fonte oficial](https://www2.camara.leg.br/legin/fed/lei/2011/lei-12527-18-novembro-2011-611802-normaatualizada-pl.html).
- **F13 — LGPD, texto compilado**, art. 5º, IX; arts. 11 e 14. [Fonte oficial](https://www.presidencia.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709compilado.htm).
- **F14 — Lei 15.352/2026**, nova denominação e regime da ANPD. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2026/lei/l15352.htm).
- **F15 — ANPD, Enunciado 1/2023**, bases legais para crianças e adolescentes. [Fonte oficial](https://www.gov.br/anpd/pt-br/assuntos/noticias/anpd-divulga-enunciado-sobre-o-tratamento-de-dados-pessoais-de-criancas-e-adolescentes/Enunciado1ANPD.pdf).
- **F16 — Lei da Ação Popular**, art. 2º e parágrafo único. [Fonte oficial](https://www.planalto.gov.br/ccivil_03/leis/l4717.htm).
- **F17 — Receita Federal / Conecta**, cadastro de órgãos sem personalidade jurídica. [Fonte oficial](https://www.gov.br/conecta/catalogo/apis/consulta-cnpj).
- **F18 — STF, Súmula Vinculante 43**, provimento em carreira diversa sem concurso. [Fonte oficial](https://jurisprudencia.stf.jus.br/pages/search/seq-sumula802/false).
- **F19 — Lei 9.649/1998**, art. 51, contrato de gestão de agência executiva. [Fonte oficial](https://portal.mec.gov.br/setec/arquivos/pdf1/LEI9649.pdf).
- **F20 — STF, Tema 592**, responsabilidade por morte de detento. [Fonte oficial](https://portal.stf.jus.br/jurisprudenciaRepercussao/verAndamentoProcesso.asp?classeProcesso=RE&incidente=4645403&numeroProcesso=841526&numeroTema=592).
- **F21 — Decreto-Lei 200/1967**, arts. 4º e 5º, no seu âmbito federal. [Fonte oficial](https://planalto.gov.br/ccivil_03/decreto-lei/del0200.htm).
- **F22 — Lei 5.851/1972**, natureza jurídica da Embrapa. [Fonte oficial](https://www2.camara.leg.br/legin/fed/lei/1970-1979/lei-5851-7-dezembro-1972-357970-normaatualizada-pl.html).
- **F23 — STF, ADI 2.135**, decisão de 06/11/2024 e efeitos prospectivos. [Fonte oficial](https://noticias.stf.jus.br/postsnoticias/stf-valida-emenda-que-flexibilizou-regime-de-contratacao-de-servidores-publicos/).

## Arquivos e continuidade

O pacote contém o inventário com SHA-256 dos originais, o índice das 404 páginas, a triagem, os 31 achados e fontes, os ativos editáveis, a prévia HTML, o PDF e as notas de integração. Os originais e a v17 foram preservados, sem writeback. O índice por página é estrutural; não atribui aprovação jurídica a cada uma das 404 páginas.

Próximo passo operacional: revisão do padrão demonstrado no item 1, seguida da construção dos itens 2 e 3 para fechar a primeira leva. O planejamento das demais levas está definido, sem supor que seus resumos já tenham sido produzidos.

## Verificação de produção da prévia

O PDF final tem oito páginas, com texto selecionável e sem imagens raster. As oito páginas foram inspecionadas visualmente. No HTML isolado, foram verificados 320, 390 e 1.280 px em claro/escuro, ausência de overflow horizontal, troca de tema, abertura de justificativa e ampliação de 200% sem overflow horizontal. Não houve erro JavaScript nesses testes. Navegador de verificação: Chrome Headless Shell 131.0.6778.204 via Playwright. Esses resultados não encerram a revisão normativa independente nem testes da aplicação integrada.
