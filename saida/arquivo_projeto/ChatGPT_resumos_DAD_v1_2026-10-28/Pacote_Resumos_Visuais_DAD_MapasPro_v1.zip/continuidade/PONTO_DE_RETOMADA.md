# Ponto de retomada · 28/10/2026

## Decisões do usuário

Conteúdo e estética MapasPro podem ser aproveitados após QA. Traduzir a estética para o sistema da plataforma v0.2. Usar SVG para relações precisas e indicar novas imagens úteis. Seguir o edital em levas dos itens 1–3, 4–6, 7–9 e 10–12. Começar por triagem dos 16 resumos e uma prévia do primeiro item.

## Concluído nesta entrega

- Inventário dos dois ZIPs: 16 PDFs, 404 páginas.
- Triagem editorial de todos os documentos e índice estrutural por página.
- 31 achados dirigidos, com páginas físicas, natureza e fontes.
- Guia visual com cores reais da v17, adaptação da identidade, componentes, imagens e ordem de produção.
- Piloto do item 1, incluindo 1.1 e 1.2: oito páginas em PDF e oito seções no HTML, duas figuras SVG, texto selecionável, duas fontes OFL incorporadas.
- Cópia da v17 lida apenas como referência; fonte preservada. O renderizador atual do resumo foi identificado, sem patch aplicado.
- QA de produção e revisão visual do executor. A conferência por modelo distinto não foi executada.

## Retomar sem presumir conclusão

1. Incorporar a avaliação estética do piloto quando fornecida pelo usuário.
2. Fazer revisão normativa independente do conteúdo efetivamente selecionado.
3. Produzir item 2 (incluindo responsabilidade do parecerista) e item 3 (incluindo requisição) para completar a primeira leva.
4. Só então prosseguir às demais levas segundo a sequência já definida.
5. Na integração, criar componentes para blocos e manter fallback textual. Não confundir a prévia com a aplicação publicada.

## Cuidados com a evidência

As 404 páginas foram inventariadas e vistas em contato; leitura e conferência jurídica foram dirigidas. Não declarar revisão normativa integral dos dezesseis resumos. O inventário de 31 achados não é contagem exaustiva nem índice de taxa de erro.

Os dados da auditoria anterior permanecem: 1.321 questões; 1.002 integrais; 17 parciais; 302 em reserva; 25 gabaritos oficiais confirmados e 22 C/E tecnicamente selecionáveis. Nesta tarefa não houve novos gabaritos confirmados ou questões importadas.

O F4 da v17 é outro conjunto de dados e não foi atualizado pelo corpus de auditoria. As afirmações na prévia são didáticas inéditas, expressamente identificadas.

## Identidade da referência da plataforma

Arquivo recuperado: `02_v17_template.html.txt`; versão declarada no arquivo: v17, prévia não publicada de 21/10/2026.

Library ID: `libfile_65a74e770c0c8191af47c7c1e36a5bed`.

Seu hash está em `dados/proveniencia.json`. A identidade foi usada para leitura; o arquivo não foi substituído. A maior parte do contexto do projeto LGPD é distinta desta tarefa de Direito Administrativo para a Câmara.
