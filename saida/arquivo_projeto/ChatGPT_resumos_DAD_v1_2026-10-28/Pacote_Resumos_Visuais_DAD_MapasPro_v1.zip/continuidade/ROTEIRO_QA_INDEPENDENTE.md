# Roteiro para revisão independente

Revisar os arquivos concretos desta entrega, registrando o nome do modelo/executor e a versão analisada. Este roteiro não é um resultado de revisão e não concede aprovação.

## Escopo do revisor

1. Conferir o conteúdo do piloto do item 1 e de 1.1/1.2. Identificar extrapolação, omissão relevante para um resumo e afirmação absoluta indevida.
2. Verificar classificação amplo/estrito versus subjetivo/objetivo, autonomia/soberania, função administrativa entre Poderes, personalidade/CNPJ, descentralização/desconcentração, natureza e instituição das entidades, capital das estatais e princípios.
3. Ler as figuras como afirmações jurídicas: o significado das setas e fronteiras deve coincidir com a legenda e não prometer mais que o texto.
4. Conferir os três exemplos inéditos, seus julgamentos e justificativas. Não tratá-los como questões oficiais.
5. Separar correção original de atualização posterior nos 31 achados. Não expandir a conclusão para páginas não conferidas.
6. Avaliar o visual em claro/escuro, celular e desktop, legibilidade, ordem de leitura, contraste, teclado e utilidade de cada figura.
7. Conferir o alinhamento ao edital, especialmente os tópicos que os dezesseis títulos não cobrem.

## Formato do retorno

Para cada achado: arquivo, seção/página, trecho, problema concreto, gravidade, correção proposta, fonte primária e estado (confirmado/depende de verificação). Separar problemas de conteúdo, design, acessibilidade e integração.

Ao concluir, declarar o que foi efetivamente examinado e os limites. Se não encontrou defeito num aspecto, registrar isso sem afirmar conformidade de todo o acervo. Não modificar silenciosamente os originais nem autorizar publicação.
