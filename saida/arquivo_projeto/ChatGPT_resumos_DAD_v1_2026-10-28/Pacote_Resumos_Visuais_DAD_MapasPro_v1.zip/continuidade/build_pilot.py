from pathlib import Path
import json,base64,html,shutil
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Flowable,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor,Color
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT=Path('/workspace/scratch/7d096ccb4e10'); OUT=ROOT/'outputs/resumos-camara-20261028'
E=html.escape

pages=[
dict(id='fundamentos',item='1',kicker='ESTADO, GOVERNO E ADMINISTRAÇÃO',title='Quem decide.\nQuem administra.',intro='Três conceitos próximos, com funções diferentes. Reconheça o sujeito e a atividade antes de julgar a afirmação.',blocks=[
('cards',[
('Estado','Organização política e jurídica da sociedade. Na síntese clássica, reúne povo, território e poder soberano.'),
('Governo','Exerce a direção política: define prioridades e conduz escolhas dentro das competências constitucionais.'),
('Administração Pública','Em sentido subjetivo, identifica a estrutura que atua; em sentido objetivo, a atividade administrativa.')]),
('callout','A diferença que muda a resposta','A República Federativa do Brasil é soberana. União, estados, Distrito Federal e municípios são entes autônomos. Autonomia não é soberania de cada ente.'),
('table',['Poder','Função típica e exemplo administrativo'],[
['Legislativo','Legislar e fiscalizar. Ao adquirir materiais para seu funcionamento, também administra.'],
['Executivo','Predomina a função administrativa. Suas atribuições também incluem direção política.'],
['Judiciário','Predomina a jurisdição. Ao organizar seus serviços e realizar contratações, também administra.']]),
('source','Base: CF, arts. 1º, 2º, 18 e 37; Lei 9.784/1999, art. 1º, §1º.')]),
dict(id='sentidos',item='1',kicker='DUAS PERGUNTAS, DOIS EIXOS',title='Quem atua?\nQual atividade?',intro='Os critérios subjetivo/objetivo e amplo/estrito respondem a perguntas diferentes. Não os confunda com a divisão entre Poderes.',blocks=[
('diagram','lentes'),
('table',['Eixo','Significado'],[
['Subjetivo · quem?','Órgãos, entidades e agentes que desempenham a função administrativa. Também chamado orgânico ou formal.'],
['Objetivo · o quê?','A atividade administrativa: prestar serviços, exercer polícia administrativa, fomentar e outras atuações administrativas. Também chamado material ou funcional.'],
['Amplo','Abrange direção política e atividade administrativa.'],
['Estrito','Abrange a atividade administrativa, sem incluir a direção política.']]),
('callout','Atenção à palavra exclusiva','A função administrativa é predominante no Executivo e também aparece nos demais Poderes. “Estrito” não significa “exclusivo do Executivo”.'),
('example','Mesmo caso, lentes diferentes','“Uma autarquia decide um requerimento.” Autarquia identifica quem atua; decidir o requerimento identifica a atividade.'),
('source','Classificação: síntese doutrinária. Controle do alcance entre Poderes: CF, art. 37; Lei 9.784/1999, art. 1º, §1º.')]),
dict(id='limpe',item='1.1',kicker='PRINCÍPIOS CONSTITUCIONAIS',title='LIMPE, com\nsentido prático.',intro='Os cinco princípios expressos orientam a Administração direta e indireta de todos os Poderes e entes federativos.',blocks=[
('principles',[
('L','Legalidade','A atuação administrativa precisa de fundamento jurídico e deve respeitar o ordenamento.','A vontade pessoal do gestor não substitui a competência legal.'),
('I','Impessoalidade','Atuar para a finalidade pública, com tratamento isonômico e sem promoção pessoal.','Obra pública não é anúncio pessoal da autoridade.'),
('M','Moralidade','Respeitar padrões jurídicos de honestidade, boa-fé e lealdade institucional.','Violação de princípio não gera automaticamente improbidade: é preciso examinar os requisitos legais.'),
('P','Publicidade','Dar transparência e permitir controle, respeitando as hipóteses legais de restrição.','Publicidade é mais ampla que publicação no Diário Oficial.'),
('E','Eficiência','Buscar qualidade e resultados com uso adequado de recursos.','A eficiência deve ser perseguida junto da legalidade; não autoriza dispensar uma exigência legal por preferência pessoal.')]),
('callout','Princípios atuam em conjunto','Uma escolha administrativa precisa reunir fundamento jurídico, finalidade pública e respeito às garantias. Evite usar um único princípio como justificativa para afastar todos os outros.'),
('source','Base: CF, art. 37, caput e §1º. Improbidade: Lei 8.429/1992, arts. 1º e 11; STF, ADIs 7.156 e 7.236.')]),
dict(id='limites',item='1.1',kicker='PRERROGATIVAS E LIMITES',title='Poder para agir.\nDever de respeitar.',intro='O regime administrativo combina instrumentos para realizar fins públicos e limites ao exercício desses poderes.',blocks=[
('cards',[
('Supremacia do interesse público','Na formulação clássica, fundamenta prerrogativas para realizar fins públicos. Seu exercício precisa respeitar a Constituição e os direitos fundamentais.'),
('Indisponibilidade','O administrador gere interesses que não lhe pertencem. Deve observar competências, procedimentos, finalidade e controles previstos no direito.')]),
('table',['Princípio ou garantia','Pergunta para resolver o caso'],[
['Razoabilidade e proporcionalidade','A medida é adequada? Há alternativa menos gravosa? Os ônus se justificam?'],
['Motivação','Quais fatos e fundamentos jurídicos sustentam a decisão?'],
['Segurança jurídica e confiança','Há proteção da boa-fé e das situações consolidadas nas condições legais?'],
['Contraditório e ampla defesa','O interessado pôde conhecer e enfrentar os fundamentos relevantes no procedimento aplicável?'],
['Autotutela','O problema é ilegalidade, conveniência ou defeito sanável? Cada hipótese exige requisitos próprios.']]),
('callout','Anular, revogar e convalidar','Ilegalidade conduz à análise da anulação; conveniência de ato válido, à revogação; defeito sanável, à convalidação. Existem limites, inclusive proteção a terceiros e segurança jurídica. O item 2 desenvolve essas diferenças.'),
('source','Síntese doutrinária e Lei 9.784/1999, arts. 2º, 50 e 53 a 55. Alguns princípios não expressos no caput do art. 37 são expressos nessa lei.')]),
dict(id='organizacao',item='1.2',kicker='ORGANIZAÇÃO ADMINISTRATIVA',title='Dentro da pessoa.\nEntre pessoas.',intro='A personalidade jurídica é a primeira pista para distinguir distribuição interna de transferência de execução.',blocks=[
('diagram','organizacao'),
('table',['Processo','O que acontece'],[
['Centralização','A pessoa política executa a atividade por seus próprios órgãos. Pode haver distribuição interna de competências.'],
['Descentralização','Outra pessoa passa a desempenhar a atividade. Pode ocorrer por entidade da indireta ou, conforme o regime, por colaboração de particular.'],
['Desconcentração','Competências são distribuídas entre órgãos da mesma pessoa jurídica. Pode ocorrer na Administração direta e na indireta.'],
['Concentração','Competências antes distribuídas são reunidas em órgão da mesma pessoa jurídica.']]),
('callout','Hierarquia e vinculação','Na organização interna, há relações hierárquicas nos termos da estrutura. Entre ministério e autarquia vinculada há controle finalístico, dentro da lei, e não hierarquia.'),
('source','Base de organização federal: DL 200/1967, arts. 4º e 5º. Distinção órgão/entidade: Lei 9.784/1999, art. 1º, §2º. Classificações: síntese doutrinária.')]),
dict(id='entidades',item='1.2',kicker='DIRETA E INDIRETA',title='Órgão é estrutura.\nEntidade é pessoa.',intro='A Administração direta atua pelos órgãos dos entes políticos. A indireta reúne entidades com personalidade própria.',blocks=[
('entities',[
('Autarquia','Direito público','Criada por lei específica','Patrimônio e atribuições próprios; vinculação não equivale a subordinação hierárquica.'),
('Fundação pública de direito público','Direito público','Criada por lei; natureza autárquica','Não confundir com a fundação estatal de direito privado.'),
('Fundação pública de direito privado','Direito privado','Instituição autorizada por lei, com constituição própria','Observar sua lei e regime específico; a denominação não decide tudo.'),
('Empresa pública','Direito privado','Instituição autorizada por lei','Capital integralmente público, com as participações admitidas na lei; admite formas societárias diversas.'),
('Sociedade de economia mista','Direito privado','Instituição autorizada por lei','Forma de sociedade anônima; maioria pública das ações com direito a voto, nas condições da lei.')]),
('callout','CNPJ não cria personalidade','Órgãos públicos podem ter inscrição cadastral sem personalidade jurídica própria. Identifique a estrutura legal, e não apenas a existência de CNPJ.'),
('example','Leia o verbo da questão','“Lei cria autarquia” e “lei autoriza a instituição de empresa pública” descrevem técnicas diferentes. A troca de cria por autoriza pode mudar o julgamento.'),
('source','Base: CF, art. 37, XIX; Lei 13.303/2016, arts. 2º a 4º; Lei 9.784/1999, art. 1º, §2º; Receita Federal, orientações sobre CNPJ de órgãos. Fundações: distinção doutrinária conforme natureza instituída.')]),
dict(id='revisao',item='1 · 1.1 · 1.2',kicker='RESUMO RELÂMPAGO',title='Reconheça\nas trocas.',intro='Antes de responder, identifique a pessoa, a atividade e a condição jurídica exigida.',blocks=[
('list',[
'Estado, governo e Administração têm funções conceituais diferentes.',
'Os entes federativos são autônomos; não são cada um soberano.',
'Subjetivo pergunta quem; objetivo pergunta qual atividade.',
'Amplo/estrito é outro eixo: direção política e atividade administrativa.',
'LIMPE alcança direta e indireta, de todos os Poderes.',
'Desconcentração mantém a pessoa; descentralização envolve outra pessoa.',
'Órgão não tem personalidade própria; CNPJ não resolve essa classificação.',
'Autarquia: lei cria. Empresa pública e SEM: lei autoriza a instituição.']),
('judgments',[
('E','“Por pertencer ao Legislativo, a Câmara não exerce função administrativa.”','O órgão também administra sua estrutura e suas contratações.'),
('C','“A desconcentração pode ocorrer dentro de uma autarquia.”','A autarquia é uma pessoa jurídica que pode distribuir competências entre seus órgãos.'),
('E','“Uma pessoa com CNPJ é necessariamente dotada de personalidade jurídica própria.”','O cadastro também alcança estruturas sem personalidade, inclusive órgãos públicos.')]),
('source','Afirmações didáticas inéditas para esta prévia. Não são questões oficiais do CEBRASPE, nem integram o banco de questões reais.')]),
dict(id='fontes',item='1 · 1.1 · 1.2',kicker='FONTES E VERSÃO',title='Revise a regra.\nConfira a fonte.',intro='Síntese de estudo com referência ao dispositivo e às distinções doutrinárias utilizadas.',blocks=[
('refs',[
('Constituição Federal','Arts. 1º, 2º, 18 e 37: Estado, Poderes, autonomia, princípios e criação de entidades.','https://www4.planalto.gov.br/legislacao/legis-federal/constituicao'),
('Lei 9.784/1999','Arts. 1º e 2º; 50 e 53 a 55: função administrativa, órgãos/entidades, garantias, motivação e revisão de atos.','https://www.planalto.gov.br/ccivil_03/leis/l9784.htm'),
('Lei 13.303/2016','Arts. 2º a 4º: autorização e características de empresa pública e SEM.','https://legis.senado.gov.br/norma/602528/publicacao/15636229'),
('Decreto-Lei 200/1967','Arts. 4º e 5º: organização federal, observado seu âmbito de aplicação.','https://planalto.gov.br/ccivil_03/decreto-lei/del0200.htm'),
('Lei 8.429/1992 e STF','Arts. 1º e 11; ADIs 7.156 e 7.236, Informativo 1225/2026: requisitos da improbidade.','https://www.stf.jus.br/arquivo/cms/informativoSTF/anexo/Informativo_PDF/Informativo_stf_1225.pdf'),
('Cadastro de órgãos públicos','Orientação institucional da Receita Federal / Conecta: CNPJ também alcança estruturas sem personalidade.','https://www.gov.br/conecta/catalogo/apis/consulta-cnpj')]),
('p','Conceitos de governo, sentidos da Administração, regime administrativo e classificações organizacionais são sínteses doutrinárias. Não são apresentados como transcrição literal de um artigo de lei.'),
('callout','Escopo deste resumo','Item 1 do edital e subitens 1.1 e 1.2. Este material organiza conceitos para a revisão; os demais tópicos do edital terão resumos próprios.'),
('source','Versão editorial: 28/10/2026. Texto selecionável. Referências primárias conferidas de forma dirigida para os dispositivos utilizados.')])
]
(OUT/'dados/resumo_item_1_blocos.json').write_text(json.dumps({'versao':'1.0-previa','edital':['1','1.1','1.2'],'estado':'Prévia editorial; sem integração/publicação','paginas':pages},ensure_ascii=False,indent=2))

svgs={
'lentes':'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 160" role="img" aria-labelledby="lentes-title lentes-desc"><title id="lentes-title">Duas lentes da Administração</title><desc id="lentes-desc">Quem atua é o critério subjetivo. A atividade exercida é o critério objetivo.</desc><style>.s{fill:var(--soft,#F1F2EE);stroke:var(--rule,#D9DCE1)}.a{fill:var(--marker,#F2C94C)}.t{font-family:Arial,sans-serif;font-size:23px;fill:var(--ink,#1B2A41)}.q{font-family:Arial,sans-serif;font-size:25px;font-weight:bold;fill:#1B2A41}</style><rect class="s" x="1" y="1" width="211" height="158" rx="12"/><rect class="s" x="228" y="1" width="211" height="158" rx="12"/><circle class="a" cx="107" cy="49" r="29"/><circle class="a" cx="334" cy="49" r="29"/><text class="q" x="107" y="58" text-anchor="middle">?</text><text class="q" x="334" y="58" text-anchor="middle">?</text><text class="t" x="107" y="111" text-anchor="middle">Quem atua?</text><text class="t" x="334" y="111" text-anchor="middle">O que faz?</text><text class="t" x="107" y="142" text-anchor="middle">Subjetivo</text><text class="t" x="334" y="142" text-anchor="middle">Objetivo</text></svg>''',
'organizacao':'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 370" role="img" aria-labelledby="org-title org-desc"><title id="org-title">Uma pessoa e pessoas distintas</title><desc id="org-desc">Desconcentração: órgãos A e B dentro da mesma pessoa jurídica. Descentralização: atuação de pessoa distinta; a vinculação não é hierarquia.</desc><style>.s{fill:var(--soft,#F1F2EE);stroke:var(--rule,#D9DCE1);stroke-width:1.5}.b{fill:var(--paper,#FBFBF8);stroke:var(--ink,#1B2A41);stroke-width:1.5}.t{font-family:Arial,sans-serif;font-size:23px;fill:var(--ink,#1B2A41)}.l{stroke:var(--ink,#1B2A41);stroke-width:1.5;fill:none}</style><text class="t" x="220" y="25" text-anchor="middle">Mesma pessoa jurídica</text><rect class="s" x="15" y="42" width="410" height="111" rx="12"/><rect class="b" x="32" y="72" width="157" height="53" rx="7"/><rect class="b" x="251" y="72" width="157" height="53" rx="7"/><text class="t" x="110" y="106" text-anchor="middle">Órgão A</text><text class="t" x="330" y="106" text-anchor="middle">Órgão B</text><path class="l" d="M189 98 H251 M241 91 L251 98 L241 105"/><text class="t" x="220" y="195" text-anchor="middle">Desconcentração</text><text class="t" x="220" y="242" text-anchor="middle">Pessoas distintas</text><rect class="s" x="15" y="260" width="171" height="62" rx="10"/><rect class="s" x="254" y="260" width="171" height="62" rx="10"/><text class="t" x="101" y="300" text-anchor="middle">Pessoa 1</text><text class="t" x="340" y="300" text-anchor="middle">Pessoa 2</text><path class="l" stroke-dasharray="5 5" d="M186 292 H254"/><text class="t" x="220" y="358" text-anchor="middle">Descentralização</text></svg>''',
}
for key,s in list(svgs.items()):
 s=s.replace('font-family:Arial,sans-serif',"font-family:'Atkinson Hyperlegible',Arial,sans-serif")
 for c in ['s','a','t','q','b','l']:
  s=s.replace('.'+c+'{','.mp-'+key+'-'+c+'{').replace('class="'+c+'"','class="mp-'+key+'-'+c+'"')
 svgs[key]=s
 (OUT/'ativos'/f'{key}.svg').write_text(s)

css='''
:root{color-scheme:light;--paper:#FBFBF8;--ink:#1B2A41;--ink-2:#4F5B6B;--rule:#D9DCE1;--soft:#F1F2EE;--marker:#F2C94C;--marker-soft:#FFF7D6;--c:#2E7D5B;--e:#9C2E2E;--focus:#1B6BB2}
:root[data-theme=dark]{color-scheme:dark;--paper:#14181E;--ink:#ECEEF1;--ink-2:#AEB5BF;--rule:#2F343C;--soft:#1E232A;--marker:#E2BB45;--marker-soft:#2E2A1A;--c:#5EBE92;--e:#E27A7A;--focus:#7DB8F0}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;background:var(--paper);color:var(--ink);font-family:'Atkinson Hyperlegible',system-ui,sans-serif;font-size:17px;line-height:1.6}a{color:var(--focus)}button{font:inherit;color:inherit;background:none;cursor:pointer}button:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid var(--focus);outline-offset:4px}.mp-top{max-width:560px;margin:0 auto;padding:24px 18px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid var(--rule)}.mp-brand{font-size:23px;font-weight:700;letter-spacing:-1px}.mp-brand span{background:var(--marker);color:#1B2A41;padding:0 3px}.mp-theme{border:1px solid var(--rule);border-radius:8px;min-height:44px;padding:4px 12px;font-size:15px}.mp-summary{max-width:560px;margin:0 auto;padding:0 18px 110px}.mp-head{padding:28px 0 16px}.mp-eyebrow{font-size:13px;font-weight:700;letter-spacing:1px;color:var(--ink-2)}.mp-head h1{font-size:31px;line-height:1.15;letter-spacing:-.6px;margin:10px 0 12px}.mp-head p:last-child{color:var(--ink-2)}.mp-summary p{margin:0}.mp-index{margin:14px 0 36px;border:1px solid var(--rule);border-radius:8px;padding:0 14px}.mp-index summary{min-height:48px;display:flex;align-items:center;font-weight:700;cursor:pointer}.mp-index ol{padding-left:22px}.mp-index a{display:inline-block;min-height:40px;color:var(--ink)}.mp-section{margin:0 0 40px;padding-bottom:20px;border-bottom:1px solid var(--rule);scroll-margin-top:18px}.mp-bar{margin:0 0 18px;padding:8px 12px;background:#1B2A41;color:#F2C94C;font-size:13px;font-weight:700;letter-spacing:.7px;border-radius:5px}:root[data-theme=dark] .mp-bar{background:var(--marker);color:#14181E}.mp-section h2{font-size:29px;letter-spacing:-.5px;line-height:1.15;margin:0 0 16px}.mp-section .mp-intro{color:var(--ink-2);margin-bottom:22px}.mp-cards{display:grid;gap:12px;margin:16px 0}.mp-card{border:1px solid var(--rule);border-radius:8px;padding:15px}.mp-card h3{font-size:18px;line-height:1.25;margin:0 0 8px}.mp-callout{border-left:4px solid var(--marker);background:var(--marker-soft);padding:14px 16px;margin:20px 0;border-radius:0 7px 7px 0}.mp-callout strong{display:block;margin-bottom:6px}.mp-example{margin:20px 0;padding:14px 0 14px 14px;border-left:2px solid var(--ink)}.mp-label{display:block;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:6px;color:var(--ink-2)}.mp-example strong{display:block;margin-bottom:6px}.mp-table{width:100%;border-collapse:collapse;margin:18px 0;font-size:16px;line-height:1.5}.mp-table caption{text-align:left}.mp-table th{background:var(--ink);color:var(--paper);padding:10px;text-align:left;font-size:14px}.mp-table td{vertical-align:top;padding:12px 10px;border-bottom:1px solid var(--rule)}.mp-table td:first-child{font-weight:700;width:33%}:root[data-theme=dark] .mp-table th{background:var(--soft);color:var(--ink);border-bottom:2px solid var(--marker)}.mp-source{font-size:13px;color:var(--ink-2);margin-top:18px!important;line-height:1.5}.mp-figure{margin:20px 0;padding:16px 10px;background:var(--soft);border-radius:8px}.mp-figure svg{display:block;width:100%;height:auto}.mp-figure figcaption{font-size:14px;color:var(--ink-2);margin-top:12px;padding:0 8px}.mp-principle{display:grid;grid-template-columns:42px minmax(0,1fr);gap:14px;padding:18px 0;border-bottom:1px solid var(--rule)}.mp-letter{background:var(--marker);color:#1B2A41;width:42px;height:42px;display:grid;place-items:center;border-radius:6px;font-size:27px;font-weight:700}.mp-principle h3{margin:0 0 6px;font-size:20px}.mp-principle .mp-limit{margin-top:8px;color:var(--ink-2);font-size:15px}.mp-entity{border:1px solid var(--rule);border-radius:8px;padding:16px;margin:12px 0}.mp-entity h3{font-size:19px;line-height:1.3;margin:0 0 12px}.mp-entity dl{margin:0}.mp-entity dt{font-size:12px;font-weight:700;letter-spacing:.6px;color:var(--ink-2);text-transform:uppercase;margin-top:9px}.mp-entity dd{margin:2px 0 0}.mp-summary ul{padding-left:22px}.mp-summary li{margin:10px 0}.mp-judge{padding:17px 0;border-bottom:1px solid var(--rule)}.mp-judge summary{min-height:44px;cursor:pointer;display:flex;align-items:center;gap:10px;font-weight:700;list-style:none}.mp-judge summary:before{content:'+';font-size:22px}.mp-judge[open] summary:before{content:'−'}.mp-result{display:inline-block;font-size:14px;font-weight:700;border:1px solid currentColor;border-radius:4px;padding:1px 6px;margin-bottom:8px}.mp-result.c{color:var(--c)}.mp-result.e{color:var(--e)}.mp-j-body{padding:12px 0}.mp-ref{padding:15px 0;border-bottom:1px solid var(--rule)}.mp-ref a{font-weight:700;display:inline-block;min-height:40px}.mp-ref p{font-size:15px}.mp-foot{font-size:13px;color:var(--ink-2);padding-top:10px}.mp-nav{position:fixed;bottom:0;left:0;right:0;background:var(--paper);border-top:1px solid var(--rule);z-index:5;padding-bottom:env(safe-area-inset-bottom)}.mp-nav div{max-width:560px;margin:auto;display:flex}.mp-nav a{flex:1;display:flex;align-items:center;justify-content:center;min-height:56px;color:var(--ink);text-decoration:none;font-size:14px;border-top:3px solid transparent}.mp-nav a:first-child{border-top-color:var(--marker)}@media(max-width:360px){.mp-table td,.mp-table th{padding:9px 6px}.mp-head h1{font-size:28px}.mp-section h2{font-size:27px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}@media print{.mp-nav,.mp-theme{display:none}.mp-summary{max-width:100%}.mp-section{break-after:page}}
'''

css=css.replace('.mp-nav a:first-child{border-top-color:var(--marker)}','.mp-nav a[aria-current=location]{border-top-color:var(--marker)}')

def block_html(b):
 kind=b[0]
 if kind=='p':return '<p>'+E(b[1])+'</p>'
 if kind=='source':return '<p class="mp-source">'+E(b[1])+'</p>'
 if kind=='cards':return '<div class="mp-cards">'+''.join('<div class="mp-card"><h3>'+E(t)+'</h3><p>'+E(v)+'</p></div>' for t,v in b[1])+'</div>'
 if kind in ['callout','example']:return '<aside class="mp-'+kind+'">'+('<span class="mp-label">EXEMPLO DIDÁTICO</span>' if kind=='example' else '')+'<strong>'+E(b[1])+'</strong><p>'+E(b[2])+'</p></aside>'
 if kind=='table':return '<table class="mp-table"><thead><tr>'+''.join('<th scope="col">'+E(s)+'</th>' for s in b[1])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+E(c)+'</td>' for c in row)+'</tr>' for row in b[2])+'</tbody></table>'
 if kind=='diagram':return '<figure class="mp-figure">'+svgs[b[1]]+'<figcaption>'+('Observe o sujeito e a atividade em eixos diferentes.' if b[1]=='lentes' else 'Distribuição interna preserva a pessoa. A atuação por outra pessoa exige examinar o regime da descentralização.')+'</figcaption></figure>'
 if kind=='principles':return ''.join('<div class="mp-principle"><span class="mp-letter" aria-hidden="true">'+l+'</span><div><h3>'+E(t)+'</h3><p>'+E(v)+'</p><p class="mp-limit">'+E(lim)+'</p></div></div>' for l,t,v,lim in b[1])
 if kind=='entities':return ''.join('<div class="mp-entity"><h3>'+E(n)+'</h3><dl><dt>Personalidade</dt><dd>'+E(p)+'</dd><dt>Criação / instituição</dt><dd>'+E(c)+'</dd><dt>Distinção essencial</dt><dd>'+E(d)+'</dd></dl></div>' for n,p,c,d in b[1])
 if kind=='list':return '<ul>'+''.join('<li>'+E(t)+'</li>' for t in b[1])+'</ul>'
 if kind=='judgments':return ''.join('<details class="mp-judge"><summary>'+E(t)+'</summary><div class="mp-j-body"><span class="mp-result '+a.lower()+'">'+('CERTO' if a=='C' else 'ERRADO')+'</span><p>'+E(why)+'</p></div></details>' for a,t,why in b[1])
 if kind=='refs':return ''.join('<div class="mp-ref"><a href="'+E(u,quote=True)+'" target="_blank" rel="noopener">'+E(t)+'</a><p>'+E(loc)+'</p></div>' for t,loc,u in b[1])
 raise ValueError(kind)

parts=[]
for p in pages:
 parts.append('<section class="mp-section" id="'+p['id']+'"><div class="mp-bar">'+E(p['item'])+' · '+E(p['kicker'])+'</div><h2>'+E(p['title']).replace('\n','<br>')+'</h2><p class="mp-intro">'+E(p['intro'])+'</p>'+''.join(block_html(b) for b in p['blocks'])+'</section>')
fragment='<article class="mp-summary"><header class="mp-head"><p class="mp-eyebrow">CÂMARA 2026 · DIREITO ADMINISTRATIVO</p><h1>Estado, governo e Administração Pública</h1><p>Resumo do item 1 · princípios e organização administrativa</p></header><details class="mp-index"><summary>Neste resumo</summary><ol>'+''.join('<li><a href="#'+p['id']+'">'+E(p['kicker'].capitalize())+'</a></li>' for p in pages)+'</ol></details>'+''.join(parts)+'<footer class="mp-foot">MapasPro · Direito Administrativo · Prévia editorial de 28/10/2026</footer></article>'
fontcss=''
for f,w in [('AtkinsonHyperlegible-Regular.ttf',400),('AtkinsonHyperlegible-Bold.ttf',700)]:fontcss+='@font-face{font-family:"Atkinson Hyperlegible";font-weight:'+str(w)+';font-style:normal;font-display:swap;src:url(data:font/ttf;base64,'+base64.b64encode((OUT/'fontes'/f).read_bytes()).decode()+') format("truetype")}\n'
themejs='''const root=document.documentElement;const btn=document.getElementById('mp-theme');function setTheme(t){root.dataset.theme=t;btn.textContent=t==='dark'?'Modo claro':'Modo escuro';btn.setAttribute('aria-pressed',String(t==='dark'));}setTheme(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');btn.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));const navs=Array.from(document.querySelectorAll('.mp-nav a'));function syncNav(){const y=window.scrollY+100;let chosen=0;['fundamentos','limpe','organizacao'].forEach((id,i)=>{if(document.getElementById(id).offsetTop<=y)chosen=i});navs.forEach((a,i)=>{if(i===chosen)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current')})}window.addEventListener('scroll',syncNav,{passive:true});syncNav();'''
doc='<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>MapasPro · Resumo do item 1 · Prévia</title><style>'+fontcss+css+'</style></head><body><header class="mp-top"><div class="mp-brand">mapas<span>pro</span></div><button type="button" class="mp-theme" id="mp-theme" aria-pressed="false">Modo escuro</button></header>'+fragment+'<nav class="mp-nav" aria-label="Seções do resumo"><div><a href="#fundamentos">Fundamentos</a><a href="#limpe">Princípios</a><a href="#organizacao">Organização</a></div></nav><script>'+themejs+'</script></body></html>'
doc=doc.replace('.mp-nav a:first-child{border-top-color:var(--marker)}','.mp-nav a[aria-current=location]{border-top-color:var(--marker)}')
(OUT/'Previa_Resumo_Item_1_MapasPro_v1.html').write_text(doc)
(OUT/'integracao/resumo_item_1_fragmento.html').write_text(fragment)
(OUT/'integracao/resumo_item_1.css').write_text(css)

# Composição PDF independente da tela; mesmos blocos editoriais da prévia.
fontdir=OUT/'fontes'
pdfmetrics.registerFont(TTFont('Atkinson',str(fontdir/'AtkinsonHyperlegible-Regular.ttf')))
pdfmetrics.registerFont(TTFont('AtkinsonBold',str(fontdir/'AtkinsonHyperlegible-Bold.ttf')))
pdfmetrics.registerFontFamily('Atkinson',normal='Atkinson',bold='AtkinsonBold')
INK=HexColor('#1B2A41');PAPER=HexColor('#FBFBF8');MUTED=HexColor('#4F5B6B');MARK=HexColor('#F2C94C');SOFT=HexColor('#F1F2EE');RULE=HexColor('#D9DCE1');MSOFT=HexColor('#FFF7D6')
styles={
 'body':ParagraphStyle('body',fontName='Atkinson',fontSize=11.2,leading=15.2,textColor=INK,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Atkinson',fontSize=9,leading=12,textColor=MUTED,spaceAfter=7),
 'title':ParagraphStyle('title',fontName='AtkinsonBold',fontSize=30,leading=31.7,textColor=INK,spaceAfter=12),
 'intro':ParagraphStyle('intro',fontName='Atkinson',fontSize=12,leading=16.2,textColor=MUTED,spaceAfter=13),
 'cardtitle':ParagraphStyle('cardtitle',fontName='AtkinsonBold',fontSize=12,leading=15,textColor=INK,spaceAfter=5),
 'table':ParagraphStyle('table',fontName='Atkinson',fontSize=10.3,leading=14,textColor=INK),
 'tablehead':ParagraphStyle('tablehead',fontName='AtkinsonBold',fontSize=10,leading=13,textColor=PAPER),
 'bar':ParagraphStyle('bar',fontName='AtkinsonBold',fontSize=9.5,leading=12,textColor=MARK),
}
def para(s,sty='body'):return Paragraph(s,styles[sty])
WIDTH=A4[0]-88

class Diagram(Flowable):
 def __init__(self,key):Flowable.__init__(self);self.key=key;self.width=WIDTH;self.height=116 if key=='lentes' else 152
 def draw(self):
  c=self.canv;w=self.width;h=self.height;c.setFillColor(SOFT);c.roundRect(0,0,w,h,8,fill=1,stroke=0)
  c.setStrokeColor(RULE);c.setLineWidth(.8)
  if self.key=='lentes':
   for x,t,s in [(15,'Quem atua?','Critério subjetivo'),(w/2+8,'O que faz?','Critério objetivo')]:
    ww=w/2-24;c.setFillColor(PAPER);c.roundRect(x,15,ww,86,6,fill=1,stroke=0);c.setFillColor(MARK);c.circle(x+ww/2,78,9,fill=1,stroke=0);c.setFillColor(INK);c.setFont('AtkinsonBold',16);c.drawCentredString(x+ww/2,49,t);c.setFont('Atkinson',11);c.drawCentredString(x+ww/2,28,s)
  else:
   c.setFont('AtkinsonBold',11);c.setFillColor(INK);c.drawString(15,136,'DESCONCENTRAÇÃO');c.drawString(w/2+10,136,'DESCENTRALIZAÇÃO')
   c.setFillColor(PAPER);c.roundRect(14,42,w/2-28,76,6,fill=1,stroke=0)
   for x,t in [(26,'Órgão A'),(125,'Órgão B')]:
    c.setFillColor(SOFT);c.roundRect(x,64,77,30,4,fill=1,stroke=0);c.setFillColor(INK);c.setFont('Atkinson',11);c.drawCentredString(x+38,75,t)
   c.setStrokeColor(INK);c.line(104,79,122,79);c.line(116,83,122,79);c.line(116,75,122,79)
   for x,t in [(w/2+16,'Pessoa 1'),(w/2+136,'Pessoa 2')]:
    c.setFillColor(PAPER);c.roundRect(x,64,90,45,6,fill=1,stroke=0);c.setFillColor(INK);c.setFont('Atkinson',11);c.drawCentredString(x+45,82,t)
   c.setDash(3,3);c.line(w/2+106,86,w/2+136,86);c.setDash()
   c.setFillColor(MUTED);c.setFont('Atkinson',10);c.drawCentredString(w/4,22,'Mesma personalidade jurídica');c.drawCentredString(3*w/4,22,'Pessoas distintas')

def card(title,txt,kind='normal'):
 inside=[para(E(title),'cardtitle'),para(E(txt))]
 tab=Table([[inside]],colWidths=[WIDTH]);tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),MSOFT if kind=='callout' else SOFT if kind=='example' else PAPER),('BOX',(0,0),(-1,-1),.7,RULE),('LINEBEFORE',(0,0),(0,0),3,MARK if kind=='callout' else INK if kind=='example' else RULE),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),3)]));return [tab,Spacer(1,10)]
def block_pdf(b):
 k=b[0];arr=[]
 if k in ['p','source']:return [para(E(b[1]),'small' if k=='source' else 'body')]
 if k=='cards':
  for t,v in b[1]:arr+=card(t,v)
 if k in ['callout','example']:arr+=card(('EXEMPLO · ' if k=='example' else '')+b[1],b[2],k)
 if k=='table':
  rows=[[para(E(x),'tablehead') for x in b[1]]]+[[para(('<b>'+E(x)+'</b>') if j==0 else E(x),'table') for j,x in enumerate(row)] for row in b[2]]
  tab=Table(rows,colWidths=[WIDTH*.29,WIDTH*.71],hAlign='LEFT');tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('LINEBELOW',(0,1),(-1,-1),.6,RULE)]));arr+=[tab,Spacer(1,12)]
 if k=='diagram':arr+=[Diagram(b[1]),Spacer(1,14)]
 if k=='principles':
  for letter,title,txt,lim in b[1]:
   a=Table([[para('<b>'+letter+'</b>','title'),[para(E(title),'cardtitle'),para(E(txt)),para(E(lim),'small')]]],colWidths=[46,WIDTH-46]);a.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(0,0),MSOFT),('LEFTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.5,RULE)]));arr+=[a,Spacer(1,7)]
 if k=='entities':
  rows=[[para('Entidade','tablehead'),para('Personalidade e instituição','tablehead'),para('Distinção essencial','tablehead')]]
  for n,p,c,d in b[1]:rows.append([para('<b>'+E(n)+'</b>','table'),para(E(p)+'<br/>'+E(c),'table'),para(E(d),'table')])
  tab=Table(rows,colWidths=[WIDTH*.26,WIDTH*.32,WIDTH*.42]);tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,1),(-1,-1),.5,RULE)]));arr+=[tab,Spacer(1,11)]
 if k=='list':
  for i,t in enumerate(b[1]):arr.append(para('<b>'+str(i+1).zfill(2)+'</b> · '+E(t)))
 if k=='judgments':
  for a,t,why in b[1]:
   label='CERTO' if a=='C' else 'ERRADO';col='#2E7D5B' if a=='C' else '#9C2E2E';arr+=[KeepTogether([para('<font color="'+col+'"><b>'+label+'</b></font> · '+E(t)),para(E(why),'small'),Spacer(1,5)])]
 if k=='refs':
  for t,loc,u in b[1]:arr+=[KeepTogether([para('<b>'+E(t)+'</b>'),para(E(loc),'small'),para('<link href="'+E(u,quote=True)+'" color="#1B6BB2">Consultar fonte oficial</link>','small'),Spacer(1,3)])]
 return arr

def header(c,doc):
 c.saveState();w,h=A4;c.setFillColor(PAPER);c.rect(0,0,w,h,fill=1,stroke=0);c.setFillColor(INK);c.setFont('AtkinsonBold',13);c.drawString(44,h-32,'mapaspro');c.setFillColor(MARK);c.rect(113,h-32,25,3,fill=1,stroke=0);c.setFillColor(MUTED);c.setFont('Atkinson',9);c.drawRightString(w-44,h-30,'CÂMARA 2026 · DIREITO ADMINISTRATIVO');c.setStrokeColor(RULE);c.line(44,40,w-44,40);c.setFont('Atkinson',8.5);c.drawString(44,26,'Resumo do item 1 · Prévia editorial · 28/10/2026');c.drawRightString(w-44,26,f'{doc.page:02d}');c.restoreState()
story=[]
for i,p in enumerate(pages):
 if i:story.append(PageBreak())
 bar=Table([[para(E(p['item'])+' · '+E(p['kicker']),'bar')]],colWidths=[WIDTH]);bar.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),INK),('LEFTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
 story+=[bar,Spacer(1,17),para(E(p['title']).replace('\n','<br/>'),'title'),para(E(p['intro']),'intro')]
 for b in p['blocks']:story+=block_pdf(b)
pdf=OUT/'Previa_Resumo_Item_1_MapasPro_v1.pdf'
SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=57,bottomMargin=52,title='MapasPro · Resumo do item 1 · Direito Administrativo',author='MapasPro',pageCompression=1).build(story,onFirstPage=header,onLaterPages=header)
print(json.dumps({'html_bytes':len(doc.encode()),'pdf':str(pdf),'secoes':len(pages)}))
