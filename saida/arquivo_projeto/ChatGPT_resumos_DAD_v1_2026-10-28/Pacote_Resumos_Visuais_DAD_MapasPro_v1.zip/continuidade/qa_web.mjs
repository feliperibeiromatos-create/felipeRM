import {chromium} from 'playwright';
import fs from 'node:fs';
const dir='/workspace/scratch/7d096ccb4e10';
const out=dir+'/outputs/resumos-camara-20261028';
const qa=dir+'/work/resumos_camara_v1/qa';
const browser=await chromium.launch({headless:true,executablePath:'/tmp/mapaspro-chrome-qa/chrome-headless-shell-linux64/chrome-headless-shell',args:['--no-sandbox']});
const page=await browser.newPage({reducedMotion:'reduce'});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('file://'+out+'/Previa_Resumo_Item_1_MapasPro_v1.html');await page.evaluate(()=>document.fonts.ready);
const checks=[];
for(const width of [320,390,1280]){
 await page.setViewportSize({width,height:900});
 for(const theme of ['light','dark']){
  await page.evaluate(t=>{setTheme(t)},theme);
  const measure=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,width:innerWidth,doc:document.documentElement.scrollWidth,font:getComputedStyle(document.body).fontFamily,sections:document.querySelectorAll('.mp-section').length,svg:document.querySelectorAll('svg').length,bodyText:document.body.innerText.length}));
  checks.push({width,theme,...measure});
  if(width===390||width===1280)await page.screenshot({path:qa+`/web_${width}_${theme}.png`,fullPage:false});
 }
}
await page.setViewportSize({width:390,height:844});
await page.evaluate(()=>{setTheme('light');document.getElementById('organizacao').scrollIntoView()});await page.waitForTimeout(100);
await page.screenshot({path:qa+'/web_organizacao_390.png'});
await page.evaluate(()=>document.getElementById('revisao').scrollIntoView());
await page.locator('.mp-judge summary').first().click();
const opened=await page.locator('.mp-judge[open]').count();
await page.screenshot({path:qa+'/web_revisao_390.png'});
await page.evaluate(()=>{setTheme('light');scrollTo(0,0)});
await page.locator('#mp-theme').click();
const themeToggle=await page.evaluate(()=>document.documentElement.dataset.theme==='dark'&&document.getElementById('mp-theme').getAttribute('aria-pressed')==='true');
await page.setViewportSize({width:640,height:1000});await page.evaluate(()=>document.body.style.zoom='2');
const zoomOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
await page.evaluate(()=>document.body.style.zoom='1');
const noExternalRequests=(await page.locator('img').count())===0;
await browser.close();
const report={checks,errors,themeToggle,opened,zoomOverflow,noRasterImages:noExternalRequests,passed:checks.every(c=>!c.overflow)&&errors.length===0&&themeToggle&&opened===1&&!zoomOverflow};
fs.writeFileSync(qa+'/qa_web.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
