# Integração proposta · Resumo do item 1

Este diretório é um kit de referência, não um patch já aplicado à plataforma.

## Ponto verificado na v17

`vResumoVer()` lê `extra.resumo` ou `lote.resumo`, formata por `paraResumo()` e renderiza por `mdCurso2()`. O novo campo deve ser opcional e manter essa rota como fallback para tópicos não migrados. Não presumir que inserir SVG bruto no campo textual funcionará.

## Blocos e componentes

O JSON `dados/resumo_item_1_blocos.json` contém oito seções editoriais ligadas a 1, 1.1 e 1.2. Seus tipos atuais são `p`, `source`, `cards`, `callout`, `example`, `table`, `diagram`, `principles`, `entities`, `list`, `judgments` e `refs`.

Na implementação, converter para um esquema explícito com `tipo`, `id`, `item_edital`, `conteudo`, `fontes` e `versao`, e validar cada tipo antes da renderização. As tuplas do JSON desta prévia são um formato de autoria, não um contrato de API estabilizado.

Criar elementos com `textContent` para texto, estruturas internas para tabelas e catálogo fechado para figuras. Não aceitar HTML/SVG arbitrário de dados externos. As duas figuras em `ativos/` são conteúdo autoral do protótipo; podem virar componentes internos com identificadores estáveis.

Separar o resumo do pai dos filhos: item 1 apresenta o mapa de navegação, 1.1 recebe princípios e 1.2 organização. O protótipo reúne os três para permitir avaliar a linguagem visual em uma leitura. Ao migrar, não duplicar integralmente todo o conteúdo em todos os campos.

## Estilos

`resumo_item_1.css` é a folha completa da prévia isolada. Antes de integrar, extrair apenas as regras `.mp-*`; os tokens de `:root`, `body`, `a`, `button` e os resets já pertencem à aplicação e não devem ser duplicados cegamente. Reutilizar tokens e fonte da plataforma. Não importar cabeçalho, seletor de tema ou barra de navegação adicionais no interior do campo Resumo.

`resumo_item_1_fragmento.html` permite ver a estrutura pretendida. É HTML autoral estático, não conteúdo para colar no campo textual sem revisar o renderizador. A prévia autônoma incorpora as fontes OFL para leitura sem dependência de rede; a aplicação pode reutilizar sua estratégia de fonte existente.

## Testes necessários no arquivo integrado

- Resumo textual antigo continua funcionando.
- Resumos novos são abertos pelo tópico certo, inclusive retorno ao curso e ao painel.
- Tema da aplicação é respeitado, sem um segundo seletor dentro do resumo.
- Sessões, respostas, navegação e eventos existentes não mudam por efeito do novo componente.
- Nenhuma questão real, dado do usuário ou contador é substituído pelo JSON de demonstração.
- Testes de largura, teclado, leitura ampliada e contraste são repetidos na composição real.

A aprovação da estética do protótipo não encerra esses testes nem substitui QA normativo independente.
