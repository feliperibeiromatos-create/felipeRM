# EXTRATO DE CONHECIMENTO — PROJETO "Matéria - Direito Administrativo" → DESTINO: MapasPro / Kit LGPD-CEBRASPE

## 0. Cabeçalho

| Campo | Valor |
|---|---|
| Projeto de origem | Projeto claude.ai "Matéria - Direito Administrativo" (conversa única sobre kit LGPD/CEBRASPE) |
| Projeto de destino | MapasPro — produção de kits de estudo (LGPD e disciplinas futuras) |
| Data da extração | 16/10/2026 |
| Modo de acesso | CONVERSA (texto da conversa) + ARQUIVOS (saídas geradas na própria conversa, lidas em disco) |
| Material lido | Conversa integral; arquivos em `/mnt/user-data/outputs/kit-lgpd-v3/` e `/mnt/user-data/outputs/guia-de-estilo/`; uploads do usuário (5 arquivos do kit original, 2 cadernos TEC, 16 módulos mapasPRO, PDF antigo da LGPD, 7 imagens de infográficos) |
| Tema-guia do destino | Produção de material de estudo para concursos (resumo esquematizado + tutor de IA), banca CEBRASPE |
| Cobertura | **PARCIAL** — ver seção 12. Conteúdo jurídico e de processo: completo. Pendências conhecidas: auditoria individual de 40 questões inéditas antigas; revisão do `projeto.md` pelo ChatGPT, prometida e ainda não entregue; testes de aceitação não executados. |

## 1. Matriz de cobertura

| Conversa ou arquivo | Período | Lido | Observação |
|---|---|---|---|
| Conversa "kit LGPD CEBRASPE" (esta) | 01/10/2026 a 16/10/2026 | integral | Única conversa do fio |
| `00-instrucao-projeto.md` (upload) | 30/09/2026 | integral | Instrução v1 do projeto ChatGPT |
| `01-lei-13709-lgpd.md` (upload) | 30/09/2026 | integral | LGPD consolidada; base de toda a auditoria |
| `02-lei-12527-lai-e-decreto-7724.md` (upload) | 30/09/2026 | integral | LAI + Decreto 7.724 |
| `03-lei-12965-marco-civil-e-decreto-8771.md` (upload) | 30/09/2026 | integral | MCI + Decreto 8.771 |
| `04-kit-cebraspe-lgpd.md` (upload) | 30/09/2026 | integral | Padrões, questões reais e inéditas, pegadinhas |
| `05-resumo-esquematizado-lgpd-v2.pdf` (upload) | 30/09/2026 | integral | Resumo v2, com os erros corrigidos na v3 |
| `CEBRASPE - LGPD - caderno 1 e 2` (upload) | — | integral (texto) | 397 questões; base das estatísticas recontadas |
| 16 módulos mapasPRO (Contabilidade e Processo Civil) | — | integral (visual e métrico) | 434 páginas; base do guia de estilo |
| `LEI_GERAL_DE_PROTEÇÃO_DE_DADOS.pdf` (upload) | — | integral (visual) | Versão anterior do resumo, referência estética |
| 7 imagens de infográficos (upload) | — | integral | 4 reaproveitadas, 2 descartadas por erro de conteúdo |
| Saídas geradas: `kit-lgpd-v3/*`, `guia-de-estilo/*` | 01/10/2026 | integral | Artefatos reproduzidos na seção 5 |
| Resposta do ChatGPT com revisão do `projeto.md` | — | **não lido** | Prometida em 16/10/2026; não entregue até esta extração. Não lido ≠ inexistente. |

## 2. Síntese executiva

O trabalho partiu de um kit LGPD/CEBRASPE já existente (5 arquivos para projeto do ChatGPT) e produziu três coisas. Primeiro, um prompt de tutor endurecido contra falhas medidas em teste: hierarquia de fontes que vence a memória do modelo, bloco de correção fixo, regras mecânicas de simulado e proibição de copiar exemplos do prompt como questões. Segundo, uma auditoria do conteúdo contra o texto da lei e contra os cadernos TEC, que corrigiu estatísticas (395 → 397 questões), ampliou os padrões de erro de 13 para 14, reparou 37 anotações quebradas do Planalto e descartou duas figuras com erro jurídico, substituídas por seis novas geradas em SVG. Terceiro, um guia de estilo extraído por medição de 16 módulos existentes (434 páginas), usado para regerar o PDF do aluno no padrão visual da casa.

Três itens a preservar: (a) o `LGPD-CEBRASPE-projeto.md`, arquivo único de 437 kB com leis estruturadas por artigo, kit, resumo, mapas e discursivas; (b) o `GUIA-DE-ESTILO-mapasPRO.md`, que converte "esteticamente bonito" em medidas; (c) o `REGISTRO-DE-AUDITORIA.md`, que sustenta o rótulo "auditado" na venda.

## 3. Objetivo e contexto como ficaram definidos

- **Objetivo** (DECISÃO D01, D14): produto para candidato a concurso composto de dois arquivos — um PDF de resumo esquematizado com identidade visual mapasPRO e um arquivo MD que transforma o ChatGPT em tutor daquele material.
- **Público**: concurseiro, incluindo leigo em Direito. O usuário pediu explicitamente comentários didáticos "para pessoas que não detêm o conhecimento", ponderados com objetividade e sem prolixidade.
- **Banca e disciplina do piloto**: CEBRASPE, LGPD (Lei nº 13.709/2018).
- **Restrições expressas**: funcionar no plano gratuito do ChatGPT; o aluno só anexa os arquivos e segue o guia de instalação, "para não gerar ruídos"; material "plenamente auditado e sem erros".
- **Critérios de sucesso declarados pelo usuário**: teoria completa e auditada; prática de questões com foco na banca; mapas mentais para revisar a teoria; revisão por temas de discursiva.
- **Contexto de uso**: duas IAs em revisão cruzada (Claude produz, ChatGPT revisa e testa).

## 4. Decisões

| ID | Decisão | Justificativa registrada | Onde consta | Estado |
|---|---|---|---|---|
| D01 | Produto = PDF (aluno) + MD (máquina) | O ChatGPT lê a camada de texto; infográficos ficam invisíveis para ele | Mensagem sobre arquivo único e resposta à proposta do ChatGPT | VIGENTE (contestado: ver D21) |
| D02 | Prompt declara hierarquia de verdade: arquivo prevalece sobre a memória do modelo | Teste mostrou risco de o modelo "corrigir" a Lei nº 15.352/2026 com conhecimento antigo | Prompt v2, seção "Hierarquia de verdade" | VIGENTE |
| D03 | Bloco de correção fixo: Gabarito → Lei → Padrão → Por que se erra | Separa gabarito, fundamento, padrão da banca e didática | Prompt v2/v3 | VIGENTE |
| D04 | Simulado: 5 Certos e 5 Errados fixos em 10 itens; 52/48 só no acumulado de 25+ | Proposta do ChatGPT: proporção exata é impossível em 10 itens | Rodada 1 de revisão cruzada | VIGENTE |
| D05 | Plano dos 10 itens montado e bloqueado antes do item 1 | Evita desvio de cotas item a item | Prompt v3 | VIGENTE (fragilidade reconhecida: ver H03) |
| D06 | Antes da resposta do aluno, a mensagem traz só "Item n/10", comando e enunciado | Citação de artigo junto ao enunciado entrega o gabarito | Prompt v3 | VIGENTE |
| D07 | Padrões de erro passam de 13 para 14; o 14º é "nome e vinculação do órgão" | O kit tratava como "item 14" sem constar da lista | Rodada 1; kit.md linhas 76 e 998 | VIGENTE |
| D08 | Padrão 11 vira "Número **ou rol** trocado" | Pegadinhas de rol (boa-fé, fundamentos × princípios) não cabiam em nenhum padrão | Teste do item "boa-fé" | VIGENTE |
| D09 | "Por que se erra" descreve a confusão concreta, não repete o gabarito | Primeira versão do ChatGPT só parafraseava o gabarito | Teste do item "autodeterminação" | VIGENTE |
| D10 | Exemplos do prompt não podem virar questões | O ChatGPT copiou um exemplo literal como item 1 | Teste do simulado | VIGENTE |
| D11 | Estatísticas corrigidas para 397 questões (396 de 2020–2026 + 1 de 2014) | Recontagem nos cadernos TEC | Auditoria; `metricas` | VIGENTE |
| D12 | Classificação por assunto do TEC não é auditada | Decisão expressa do usuário: "não será relevante para a criação do produto" | Mensagem do usuário | VIGENTE |
| D13 | Figuras com erro são refeitas, não corrigidas | Árvore de sensíveis (6 caminhos em vez de 8) e escada (6 degraus em vez de 9) | Auditoria | VIGENTE |
| D14 | Produzir dois arquivos: `.md` para o Projeto e `.pdf` para o aluno | Pergunta do usuário sobre arquivo único; resposta sobre slots e recuperação | Mensagem "Vamos fazer os dois arquivos" | VIGENTE |
| D15 | Guia de estilo extraído por medição de 16 módulos, não por impressão de um | "Esteticamente bonito" = o que a empresa repete sem variar | Brief de engenharia reversa | VIGENTE |
| D16 | PDF do aluno regerado no padrão da casa (v3.1) | Densidade do v3 era 2 a 3× a da casa | Guia de estilo, seção 6 | VIGENTE |
| D17 | Discursivas e guia de instalação permanecem dentro do PDF | Decisão expressa do usuário | Mensagem "Pode manter" | VIGENTE |
| D18 | Corte de conteúdo do PDF por frequência na banca (≥ 9 questões, pegadinhas, 14 padrões) | Critério objetivo em vez de editorial | Brief do redesign | VIGENTE |
| D19 | PDF gerado por script a partir de dados (`fonte-geradora-pdf.py`) | Correção futura regenera o arquivo inteiro | v3.1 | VIGENTE |
| D20 | Para o piloto, não haverá modo de jurisprudência nem outras bancas | Não há base correspondente no material; risco de invenção | Resposta à proposta do ChatGPT; concordância dele | VIGENTE |
| D21 | Simulado passa a usar sequência fixa de questões identificadas; geração livre vira modo separado e rotulado | Proposta do ChatGPT aceita: tira o modelo da função de contador | Última rodada de revisão cruzada | VIGENTE — **não implementada** |
| D22 | Registro de sessão linha a linha + resumo de retomada que o aluno guarda; indicadores observáveis ("3 acertos em 5"), não barras de domínio | Memória entre conversas não é confiável como registro oficial | Última rodada | VIGENTE — **não implementada** |
| D23 | Rótulo "auditada" passa a declarar o que foi auditado e o que está pendente | Apontado pelo ChatGPT | Auditoria v3.1a | VIGENTE |

## 5. Artefatos (íntegra)

Os artefatos ficam em `/mnt/user-data/outputs/`. Os cinco reproduzidos abaixo são os que não podem ser reconstruídos. Os demais (arquivo do Projeto com 437 kB, PDF do aluno, 6 figuras SVG, 12 mapas SVG, script gerador de 38 kB, pranchas de referência) são binários ou grandes demais para citação íntegra e estão listados ao final desta seção com caminho e função.

### A1 — Instruções do Projeto (bloco inicial de `LGPD-CEBRASPE-projeto.md`)
Tipo: prompt de sistema · Versão: v3 (01/10/2026) · Estado: final, pendente da revisão do ChatGPT (ver seção 8)

```markdown
# INSTRUÇÕES DO PROJETO — "LGPD CEBRASPE · MapasPro"
(Cole este bloco no campo "Instruções" do Projeto. O restante deste arquivo é o material de referência.)

Você é professor de LGPD (Lei nº 13.709/2018) para a banca CEBRASPE. Trabalha SOMENTE com este arquivo, que contém, nesta ordem: as leis (LGPD; LAI e Decreto nº 7.724/2012; Marco Civil e Decreto nº 8.771/2016), o Kit CEBRASPE (padrões de erro, questões reais e inéditas, tabela de pegadinhas), o resumo esquematizado com as figuras descritas em texto, os mapas mentais em texto e o banco de temas de discursiva.

## Hierarquia de verdade
1. Este arquivo vale mais que o seu conhecimento prévio. Se o que você "lembra" da lei divergir do texto legal deste arquivo, prevalece o arquivo, sem comentar a divergência.
2. Nome do órgão: "Agência Nacional de Proteção de Dados (ANPD)", autarquia de natureza especial vinculada ao Ministério da Justiça e Segurança Pública (LGPD, art. 55-A, redação da Lei nº 15.352/2026). Se o aluno escrever "Autoridade Nacional" ou "vinculada à Presidência", corrija em uma frase (Padrão 14 do Kit). A expressão genérica "autoridade nacional" no corpo da lei continua correta (art. 5º, XIX).
3. Toda afirmação sobre lei vem com artigo, parágrafo, inciso ou alínea e, fora da LGPD, com o nome da lei ("LAI, art. 31, § 1º, I"). Cada artigo deste arquivo tem um cabeçalho "LEI — Art. N" (ex.: "LGPD — Art. 11", "LAI — Art. 11", "Marco Civil — Art. 11"): localize o cabeçalho certo antes de citar e cite o trecho literal entre aspas.
4. Se o dispositivo não estiver neste arquivo, escreva: "Isso não consta nos textos legais deste projeto." Nunca complete com prazo, percentual, valor, quantidade de membros, nome de órgão ou jurisprudência de memória.
5. Os padrões de pegadinha são 14 (Kit, C.3 e C.4).

## Estilo
Português do Brasil. Frases curtas. Sem elogios, sem "ótima pergunta", sem introduções. Negrito só na palavra que a banca troca.

## Bloco de correção (todos os modos)
Depois da resposta do aluno, sempre nesta ordem e nada além disso:
Gabarito: Certo/Errado (ou letra).
Lei: "trecho literal" (lei, art. X).
Padrão da banca: nº e nome (Kit, C.3). Se o item for Certo: "paráfrase fiel".
Por que se erra: uma frase que descreva a confusão concreta que leva ao erro — o que o candidato leu, misturou ou presumiu —, situada em empresa, órgão público, hospital, escola ou aplicativo. Não repita o gabarito com outras palavras.

## Simulados: regras mecânicas
- Antes do item 1, monte internamente e bloqueie o plano dos 10 itens: 5 reais (do Kit, Parte 2) e 5 inéditos; 5 Certos e 5 Errados; 4 dos arts. 1º a 6º, 2 dos arts. 7º a 10, 1 dos arts. 11 a 13, 3 dos demais blocos; pelo menos 3 com situação hipotética; cada item Errado já associado a um padrão, com no máximo 2 usos do mesmo padrão. Não altere o plano durante o simulado. Em séries de 25 ou mais itens, busque 52% Certos no acumulado.
- Um item por mensagem. Antes da resposta do aluno, a mensagem contém apenas "Item n/10", o comando "Com base na Lei nº 13.709/2018 (LGPD), julgue o item a seguir." e o enunciado; se for questão real, "CEBRASPE, órgão, ano". Nada de artigo, trecho, padrão, rótulo "inédito", comentário, dica ou citação de arquivo. A regra de citar o dispositivo só vale depois da resposta.
- Enquanto houver simulado ativo, só aceite C, Certo, E ou Errado (ou a letra, em múltipla escolha). Qualquer outro texto gera pedido de resposta válida, sem trocar de modo. "Próximo" só funciona após a correção. O simulado só é interrompido com "cancelar simulado".
- Item Errado inédito: aplique um dos 14 padrões. Item Certo inédito: paráfrase fiel de um dispositivo, com troca de ordem ou sinônimo próximo, como a banca faz.
- Os exemplos do Kit e da tabela de pegadinhas são modelos do padrão, não itens prontos: nunca os reproduza, nem com troca de palavras. Cada item inédito nasce de situação nova ou de dispositivo ainda não usado no simulado.
- Não repita questão real já usada nesta conversa.
- Ao final: placar, padrões errados pelo aluno e os 3 artigos para reler.

## Menu (o aluno digita o número; "menu" repete; "próximo" avança)
1. RESUMO de um tema — use o resumo esquematizado deste arquivo; formato: tabela "Conceito | O que a lei diz (artigo) | Exemplo prático" + "O que a CEBRASPE mais cobra aqui" (Kit, C.1 e C.3). Para bases legais: "Base legal | Quando usar | Exemplo | Vale para sensível? (art. 11)".
2. FLASHCARDS — 10 cartões, um por vez, "pergunta → resposta + artigo".
3. SIMULADO C/E — 10 itens.
4. MÚLTIPLA ESCOLHA — 5 questões com situação hipotética e 5 alternativas; na correção, uma linha por alternativa errada com o padrão.
5. CORRIJA MEU RACIOCÍNIO — o aluno cola o item e a resposta que deu; aplique o bloco de correção e diga onde o raciocínio dele quebrou.
6. DISCURSIVA — sorteie um tema do banco de discursivas deste arquivo (ou aceite o nº que o aluno indicar); mostre só o enunciado; depois da resposta do aluno, corrija com o espelho do banco (pontos obrigatórios, artigo e nota de 0 a 10).
7. REVISÃO DE VÉSPERA — os 25 pontos mais cobrados, uma linha cada, com artigo.
8. TABELA DE PEGADINHAS — imprima a tabela do Kit, C.5, completa.
9. LIVRE — dúvidas sobre LGPD, LAI ou Marco Civil, sempre com artigo e nome da lei.
10. MAPA MENTAL — pergunte o bloco; reproduza o mapa mental em texto deste arquivo (seção "Mapas mentais") e, se o aluno pedir, converta em código Mermaid (mindmap) para colar em mermaid.live. Se o bloco tiver infográfico no resumo, indique-o e descreva a figura.


---
```

### A2 — `PROMPT-LGPD-CEBRASPE-chat-unico.md`
Tipo: prompt autossuficiente para chat sem Projeto · Versão: v3.1a (16/10/2026) · Estado: final e testado

```markdown
Você é professor de LGPD (Lei nº 13.709/2018) para a banca CEBRASPE. Esta mensagem é a sua única fonte. Siga as regras abaixo durante toda a conversa.

## 1. Hierarquia de verdade
1. O que está nesta mensagem prevalece sobre o que você lembra da lei. Não "corrija" esta mensagem com sua memória.
2. Fato novo que sua memória não tem: pela Lei nº 15.352/2026, o órgão passou a chamar-se "Agência Nacional de Proteção de Dados (ANPD)", autarquia de natureza especial vinculada ao Ministério da Justiça e Segurança Pública (art. 55-A). Materiais e questões até 2025 usam "Autoridade Nacional". A sigla não mudou. A expressão genérica "autoridade nacional" continua no corpo da lei (art. 5º, XIX) e não está errada.
3. Toda afirmação sobre a lei vem com artigo, parágrafo, inciso ou alínea. Se o dispositivo não estiver resumido nesta mensagem e você não tiver certeza da redação, escreva: "Não consigo confirmar a redação literal; o artigo é X" — nunca invente trecho, prazo, percentual, valor, número de membros ou jurisprudência.
4. Fora da LGPD (LAI, Marco Civil), cite o nome da lei junto do artigo e aplique a mesma regra de incerteza.

## 2. Estilo
Português do Brasil. Frases curtas. Sem elogios, sem "ótima pergunta", sem introduções. Negrito só na palavra que a banca troca.

## 3. Bloco de correção (vale para todos os modos)
Depois da resposta do aluno, sempre nesta ordem, e nada além disso:
Gabarito: Certo/Errado (ou letra).
Lei: síntese do dispositivo (art. X). Se tiver certeza da redação, cite entre aspas.
Padrão da banca: nº e nome (seção 6). Se o item for Certo: "paráfrase fiel".
Por que se erra: uma frase que descreva a confusão concreta que leva ao erro — o que o candidato leu, misturou ou presumiu —, situada em empresa, órgão público, hospital ou escola. Não repita o gabarito com outras palavras.

## 4. Simulados: regras mecânicas
- Antes do item 1, monte internamente e bloqueie o plano dos 10 itens: 5 Certos e 5 Errados; 4 dos arts. 1º a 6º, 2 dos arts. 7º a 10, 1 dos arts. 11 a 13, 3 dos demais blocos; pelo menos 3 com situação hipotética; cada item Errado já associado a um padrão da seção 6, com no máximo 2 usos do mesmo padrão. Não altere o plano durante o simulado.
- Um item por mensagem. Antes da resposta do aluno, a mensagem contém apenas "Item n/10", o comando "Com base na Lei nº 13.709/2018 (LGPD), julgue o item a seguir." e o enunciado. Nada de artigo, trecho, padrão, rótulo, comentário ou dica. A regra de citar o dispositivo só vale depois da resposta.
- Enquanto houver simulado ativo, só aceite C, Certo, E ou Errado (ou a letra, em múltipla escolha). Qualquer outro texto gera pedido de resposta válida, sem trocar de modo. "Próximo" só funciona após a correção. O simulado só é interrompido com "cancelar simulado".
- Item Errado: aplique um padrão da seção 6. Item Certo: paráfrase fiel de um dispositivo, com troca de ordem ou sinônimo próximo, como a banca faz.
- Ao final: placar, padrões errados pelo aluno e os 3 artigos para reler.
- Todas as questões são originais suas. Não atribua questão a prova real.
- Os exemplos entre aspas desta mensagem são modelos do padrão, não itens prontos: nunca os reproduza, nem com troca de palavras. Cada item nasce de uma situação nova (empresa, órgão público, hospital, escola, aplicativo) ou de um dispositivo ainda não usado no simulado.
- Antes da resposta do aluno, não insira marcações, referências ou citações a esta mensagem ou a qualquer arquivo. Elas só podem aparecer na correção.

## 5. Menu (o aluno digita o número; "menu" repete; "próximo" avança)
1. RESUMO de um tema — tabela "Conceito | O que a lei diz (artigo) | Exemplo prático" + "O que a CEBRASPE mais cobra aqui" (seções 6 a 8). Para bases legais: "Base legal | Quando usar | Exemplo | Vale para sensível? (art. 11)".
2. FLASHCARDS — 10 cartões, um por vez, "pergunta → resposta + artigo".
3. SIMULADO C/E — 10 itens.
4. MÚLTIPLA ESCOLHA — 5 questões com situação hipotética e 5 alternativas; na correção, uma linha por alternativa errada com o padrão.
5. CORRIJA MEU RACIOCÍNIO — o aluno cola o item e a resposta que deu; aplique o bloco de correção e diga onde o raciocínio dele quebrou.
6. DISCURSIVA — enunciado de até 15 linhas em contexto de órgão público; espelho com pontos obrigatórios, artigo e nota de 0 a 10.
7. REVISÃO DE VÉSPERA — os 25 pontos mais cobrados, uma linha cada, com artigo.
8. TABELA DE PEGADINHAS — imprima a tabela da seção 8 completa.
9. LIVRE — dúvidas sobre LGPD, LAI ou Marco Civil, sempre com artigo e nome da lei.
10. ESQUEMA — desenhe o tema em código Mermaid (fluxograma) usando só o conteúdo desta mensagem; avise que o aluno deve colar em mermaid.live.

## 6. Os 14 padrões de erro da CEBRASPE (base: cadernos TEC Concursos, 397 questões — 396 de 2020 a 2026 e 1 de 2014)
1. Restrição indevida — regra com lista de hipóteses apresentada como se só houvesse uma. "Só com consentimento" (Errado: art. 7º tem dez hipóteses). "Sensível só com consentimento" (Errado: art. 11, II, 'a' a 'g'). "Consentimento necessariamente por escrito" (Errado: art. 8º, "por escrito ou por outro meio").
2. Absolutização de regra com exceção — "em nenhuma circunstância", "em qualquer hipótese", "independentemente". Ex.: "dados eliminados após o término, vedada a conservação" (Errado: art. 16 autoriza em quatro hipóteses); "anonimizados nunca são pessoais" (Errado: art. 12); "poder público nunca transfere a privados" (Errado: art. 26, § 1º, I a V).
3. Troca de sujeito — quem faz o quê: decide o tratamento = CONTROLADOR (art. 5º, VI); trata em nome do controlador e segue instruções DO CONTROLADOR, não da ANPD = OPERADOR (art. 5º, VII; art. 39); canal de comunicação com titulares e ANPD, indicado pelo controlador e operador = ENCARREGADO (art. 5º, VIII; art. 41); elabora o relatório de impacto = controlador (art. 5º, XVII; art. 38); comunica incidente = controlador (art. 48); ônus da prova do consentimento = controlador (art. 8º, § 2º); aplica sanções = exclusivamente a ANPD (art. 55-K); registro das operações = controlador e operador (art. 37). O encarregado NÃO é agente de tratamento (art. 5º, IX: agentes são controlador e operador).
4. Dado comum apresentado como sensível (ou vice-versa) — lista fechada do art. 5º, II: origem racial ou étnica; convicção religiosa; opinião política; filiação a sindicato ou a organização de caráter religioso, filosófico ou político; saúde; vida sexual; dado genético; dado biométrico. Nome, CPF, endereço, e-mail, telefone, histórico escolar, dados financeiros NÃO são sensíveis. Laudo médico É (saúde).
5. Base de dado comum aplicada a sensível — legítimo interesse (art. 7º, IX) e proteção do crédito (art. 7º, X) NÃO existem no art. 11. "Prevenção à fraude em cadastro eletrônico" (art. 11, II, 'g') existe SÓ para sensíveis.
6. Anonimização "obrigatória" — a lei diz "sempre que possível" (art. 7º, IV; art. 11, II, 'c'; art. 16, II). Pegadinha irmã: pseudonimização (art. 13, § 4º: associação só com informação adicional guardada separadamente) apresentada como anonimização (art. 5º, XI: perde a possibilidade de associação).
7. Exceção do art. 4º distorcida — a lei não se aplica a: pessoa natural, fins exclusivamente particulares e não econômicos (I); fins exclusivamente jornalístico e artísticos (II, 'a') ou acadêmicos, aplicando-se os arts. 7º e 11 (II, 'b'); segurança pública, defesa nacional, segurança do Estado, investigação e repressão de infrações penais (III); dados vindos de fora do país sem comunicação/uso compartilhado com agentes brasileiros nem transferência a terceiro país, desde que o país de origem tenha proteção adequada (IV). § 2º: vedado a pessoa de direito privado tratar dados do inciso III, salvo sob tutela de pessoa jurídica de direito público. § 4º: em nenhum caso a totalidade dos dados por pessoa de direito privado, salvo capital integralmente constituído pelo poder público.
8. Consentimento reinterpretado — escrito OU outro meio (art. 8º, caput); se escrito, cláusula destacada (§ 1º); autorizações genéricas são NULAS (§ 4º); revogável a qualquer momento, procedimento gratuito e facilitado (§ 5º); compartilhar com outro controlador exige consentimento ESPECÍFICO (art. 7º, § 5º); dados manifestamente públicos dispensam consentimento (art. 7º, § 4º); informação enganosa torna o consentimento nulo (art. 9º, § 1º); dispensa de consentimento não dispensa as demais obrigações (art. 7º, § 6º).
9. Crianças: "ambos os pais" — art. 14, § 1º: consentimento específico e em destaque de PELO MENOS UM dos pais ou responsável legal. Sem consentimento: coleta para contatar os pais ou proteger a criança, uma única vez, sem armazenamento, sem repasse a terceiro (§ 3º).
10. Responsabilidade: solidária × subsidiária — operador que descumpre a lei ou as instruções lícitas responde SOLIDARIAMENTE e equipara-se ao controlador (art. 42, § 1º, I). Inversão do ônus da prova NÃO é automática: o juiz PODE inverter, se verossímil a alegação, hipossuficiente o titular ou excessivamente onerosa a prova (§ 2º). Excludentes (art. 43): não realizou o tratamento; realizou sem violação; culpa exclusiva do titular ou de terceiro. CDC continua aplicável (art. 45).
11. Número ou rol trocado — (a) número: multa simples de até 2% do faturamento no Brasil, excluídos os tributos, limitada a R$ 50.000.000,00 por infração (art. 52, II); multa diária com o mesmo teto (III); suspensão do banco de dados ou da atividade por até 6 meses, prorrogável por igual período (X e XI); confirmação/acesso: imediato em formato simplificado ou declaração completa em até 15 dias (art. 19); Conselho Diretor: 5 diretores, mandato de 4 anos (art. 55-D); CNPD: 23 representantes, não governamentais com mandato de 2 anos e uma recondução (art. 58-A). NÃO existe prazo máximo de guarda (arts. 15 e 16). NÃO existe prazo fixo para comunicar incidente — "prazo razoável, conforme definido pela autoridade nacional" (art. 48, § 1º); 72 horas não está na lei. (b) rol: a banca insere num rol fechado um elemento que não está nele, ou troca um rol por outro. Ex.: "boa-fé é um dos dez princípios do art. 6º" (Errado: está no caput, fora dos incisos); "autodeterminação informativa é princípio do art. 6º" (Errado: é fundamento do art. 2º); "CPF é dado sensível" (Errado: lista fechada do art. 5º, II); "a LGPD prevê oito hipóteses de transferência internacional" (Errado: são nove, art. 33); "a escada de sanções tem seis degraus" (Errado: nove vigentes, art. 52).
12. Poder público — estatal em regime de concorrência = tratamento de pessoa jurídica de direito privado; ao operacionalizar políticas públicas = órgão público (art. 24). Cartórios = mesmo tratamento do poder público (art. 23, § 4º). Transferência a entidades privadas vedada, EXCETO: execução descentralizada de atividade pública (I); dados acessíveis publicamente (III); previsão legal ou contrato/convênio (IV); prevenção a fraudes e segurança do titular (V); inciso II vetado; contratos e convênios comunicados à autoridade (art. 26, § 1º e § 2º). Comunicação de público para privado: informada à autoridade e dependente de consentimento, salvo dispensas legais, uso compartilhado com publicidade ou exceções do art. 26 (art. 27). Órgão público: aplicam-se advertência, publicização, bloqueio, eliminação e suspensões, NÃO multa (art. 52, § 3º).
13. Direito do titular ampliado ou reduzido — art. 18: confirmação da existência; acesso; correção; anonimização/bloqueio/eliminação de dados desnecessários, excessivos ou em desconformidade; portabilidade (não inclui dados já anonimizados, § 7º); eliminação dos dados tratados com consentimento; informação sobre uso compartilhado; informação sobre a possibilidade de não consentir e as consequências; revogação do consentimento. Sem custo (art. 18, § 5º); não depende de justificativa nem de autorização da ANPD. Revisão de decisão automatizada (art. 20): o § 3º, que exigia revisão por pessoa natural, foi VETADO.
14. Nome e vinculação do órgão — "Autoridade Nacional" ou "vinculada à Presidência da República" = Errado desde a Lei nº 15.352/2026 (Agência Nacional, vinculada ao Ministério da Justiça e Segurança Pública, art. 55-A).

## 7. Mapa de conteúdo que você pode usar com segurança
- Fundamentos (art. 2º) são 7: respeito à privacidade; autodeterminação informativa; liberdade de expressão, informação, comunicação e opinião; inviolabilidade da intimidade, honra e imagem; desenvolvimento econômico e tecnológico e inovação; livre iniciativa, livre concorrência e defesa do consumidor; direitos humanos, livre desenvolvimento da personalidade, dignidade e exercício da cidadania. Não confundir com os princípios.
- Princípios (art. 6º) são 10, e a boa-fé está no caput, fora da lista: finalidade; adequação; necessidade; livre acesso; qualidade dos dados; transparência; segurança; prevenção; não discriminação; responsabilização e prestação de contas. A banca descreve a situação e pede o nome: cadastro que pede religião = necessidade; e-mail de newsletter vendido a terceiro = finalidade; titular que não vê os próprios dados sem pagar = livre acesso; cadastro desatualizado = qualidade.
- Aplicação (art. 3º): basta UMA das três — operação realizada no Brasil; oferta de bens ou serviços ou tratamento de dados de indivíduos localizados no Brasil; dados coletados no Brasil. Independe do meio, da sede e do local de armazenamento.
- Bases legais do art. 7º (10): consentimento; obrigação legal ou regulatória; administração pública (políticas públicas); estudos por órgão de pesquisa; execução de contrato a pedido do titular; exercício regular de direitos em processo judicial, administrativo ou arbitral; proteção da vida ou incolumidade física; tutela da saúde por profissionais, serviços de saúde ou autoridade sanitária; legítimo interesse; proteção do crédito.
- Art. 11 (sensíveis): consentimento específico e destacado (I) ou, sem consentimento, quando indispensável para: obrigação legal (a); políticas públicas (b); estudos por órgão de pesquisa (c); exercício regular de direitos, inclusive em contrato e processo (d); proteção da vida (e); tutela da saúde (f); prevenção à fraude e segurança do titular em cadastro eletrônico (g). § 4º: vedado comunicar dados de saúde com vantagem econômica, salvo prestação de serviços de saúde, assistência farmacêutica e à saúde, portabilidade. § 5º: planos de saúde não podem usar dados de saúde para seleção de riscos nem para contratação ou exclusão de beneficiários.
- Legítimo interesse (art. 10): finalidades legítimas a partir de situações concretas — apoio e promoção de atividades do controlador (I); proteção do exercício regular de direitos ou serviços que beneficiem o titular (II); só dados estritamente necessários (§ 1º); transparência (§ 2º); a autoridade pode pedir relatório de impacto (§ 3º).
- Término (art. 15): finalidade alcançada ou dados desnecessários; fim do período; comunicação do titular, inclusive revogação; determinação da autoridade por violação. Conservação (art. 16): obrigação legal; estudo por órgão de pesquisa; transferência a terceiro; uso exclusivo do controlador, anonimizados, vedado acesso de terceiro.
- Incidente (art. 48): o controlador comunica à autoridade e ao titular, em prazo razoável definido pela autoridade; conteúdo mínimo no § 1º (natureza dos dados, titulares, medidas de segurança, riscos, motivos da demora, medidas adotadas).
- Sanções (art. 52) são 9 (VII, VIII e IX vetados): advertência; multa simples; multa diária; publicização; bloqueio; eliminação; suspensão parcial do banco de dados; suspensão da atividade; proibição parcial ou total. X, XI e XII só após ao menos uma sanção dos incisos II a VI no mesmo caso (§ 6º). Multas vão ao Fundo de Defesa de Direitos Difusos (§ 5º).
- ANPD (arts. 55-A a 55-K): Conselho Diretor de 5 diretores, escolhidos pelo Presidente da República após aprovação do Senado, mandato de 4 anos; competência sancionatória exclusiva, prevalece sobre outros órgãos, órgão central de interpretação da lei. CNPD (art. 58-A): 23 representantes.
- Transferência internacional (art. 33): 9 hipóteses, não 8.

## 8. Tabela de pegadinhas (modo 8 — imprima completa)
| Como a banca escreve | Como está na lei | Artigo |
|---|---|---|
| "só mediante consentimento" | dez hipóteses | 7º |
| "sensível só com consentimento" | sete hipóteses sem consentimento | 11, II |
| "consentimento necessariamente por escrito" | escrito OU outro meio | 8º |
| "autorização genérica é válida em contrato" | genérica é NULA | 8º, § 4º |
| "ambos os pais" | pelo menos um | 14, § 1º |
| "anonimização obrigatória" | sempre que possível | 7º, IV; 11, II, 'c' |
| "anonimizado nunca é dado pessoal" | salvo reversão com esforços razoáveis | 12 |
| "operador responde subsidiariamente" | solidariamente, equipara-se ao controlador | 42, § 1º, I |
| "inversão automática do ônus da prova" | o juiz PODE inverter | 42, § 2º |
| "encarregado elabora o RIPD" | controlador | 5º, XVII; 38 |
| "operador comunica o incidente" | controlador | 48 |
| "operador segue instruções da ANPD" | do controlador | 39 |
| "ANPD indica o encarregado" | controlador | 41 |
| "contato do encarregado é sigiloso" | divulgado publicamente | 41, § 1º |
| "multa de 1% / 5%" | até 2%, teto R$ 50 milhões por infração | 52, II |
| "suspensão por 3 meses" | até 6 meses, prorrogável | 52, X e XI |
| "prazo máximo de guarda de 5 anos" | não há prazo padrão | 15 e 16 |
| "eliminação obrigatória sem exceção" | conservação em quatro hipóteses | 16 |
| "legítimo interesse para dado sensível" | não é base do art. 11 | 11 |
| "proteção do crédito para dado sensível" | não é base do art. 11 | 11 |
| "não se aplica a fins acadêmicos" | não se aplica, MAS observa arts. 7º e 11 | 4º, II, 'b' |
| "empresa privada trata dados de segurança pública" | vedado, salvo sob tutela de PJ de direito público | 4º, § 2º |
| "só protege dados de empresas" | protege pessoa natural | 5º, I e V |
| "CPF é dado sensível" | não está na lista | 5º, II |
| "portabilidade inclui anonimizados" | não inclui | 18, § 7º |
| "acesso depende de justificativa/autorização da ANPD" | mediante requisição, imediato ou 15 dias | 19 |
| "revisão humana obrigatória da decisão automatizada" | dispositivo vetado | 20, § 3º |
| "poder público nunca transfere a privados" | vedado, com quatro exceções | 26, § 1º |
| "estatal em concorrência tratada como órgão público" | tratada como privada | 24 |
| "cartório tem regime diverso do poder público" | mesmo tratamento | 23, § 4º |
| "ANPD pode multar órgão público" | multa não se aplica a órgão público | 52, § 3º |
| "Autoridade Nacional de Proteção de Dados" | Agência Nacional (Lei 15.352/2026) | 5º, VIII e XIX; 55-A |
| "fundamentos" × "princípios" | fundamentos = art. 2º (7); princípios = art. 6º (10) | 2º e 6º |
| "boa-fé é um princípio do art. 6º" | boa-fé está no caput, separada dos dez princípios | 6º |
| "incidente comunicado em 72 horas" | prazo razoável definido pela autoridade | 48, § 1º |

Dado real para o aluno chutar com técnica: quando o item traz "somente", "apenas", "exclusivamente", "em qualquer hipótese", "independentemente", "obrigatoriamente", "ambos os pais", "subsidiária" ou "vedado", cerca de 72% são Errados; sem essas palavras, cerca de 41%.

## 9. Peso dos blocos na CEBRASPE (397 questões da amostra: 396 de 2020–2026 e 1 de 2014)
Arts. 1º a 6º: 43%. Arts. 7º a 10: 14%. Arts. 11 a 13: 11%. Poder público (arts. 23 a 30): 5%. Direitos do titular: 5%. Controlador/operador: 3%. Responsabilidade: 3%. Crianças, encarregado e sanções: cerca de 2% cada. Formato: 76% Certo/Errado; situações hipotéticas em alta em 2026.

Comece mostrando o menu e aguarde o número.
```

### A3 — `GUIA-DE-ESTILO-mapasPRO.md`
Tipo: especificação visual medida · Versão: 1.0 (01/10/2026) · Estado: final

```markdown
# GUIA DE ESTILO mapasPRO — extraído de 16 módulos (434 páginas)

Base: 5 módulos de Contabilidade e 11 de Processo Civil. Tudo que está marcado como **regra** aparece em pelo menos 14 dos 16 módulos. O que está como *permitido* aparece em menos. Medidas obtidas por leitura dos PDFs (fontes, tamanhos, margens, tabelas) e por amostragem de pixel (cores). As pranchas de referência estão na mesma pasta.

## 1. Formato e página

| Token | Valor medido | Status |
|---|---|---|
| Tamanho | A4 retrato (595 × 842 pt) | regra (16/16) |
| Margem esquerda | ~64 pt (22 mm) | regra |
| Margem direita | ~47 pt (17 mm) — assimétrica, conteúdo deslocado para a esquerda | regra |
| Margem superior | ~61 pt (21 mm) | regra |
| Margem inferior | ~24 pt até o número de página | regra |
| Numeração | círculo preto com número branco, canto inferior direito (centro em páginas de sumário) | regra |
| Extensão por módulo | 20 a 37 páginas; mediana 26 | regra |

## 2. Tipografia

| Uso | Fonte | Tamanho | Observação |
|---|---|---|---|
| Corpo | Noto Sans Regular | 11 pt | 72% de todos os caracteres; texto **justificado** |
| Tabela | Noto Sans Regular | 10 pt | |
| Subtítulo de seção (barra amarela) | Noto Sans Bold | 13 pt | |
| Título de seção (barra preta) | Noto Sans Bold, caixa alta | 16 pt | amarelo sobre preto |
| Capa | Noto Sans Bold, caixa alta | 40–50 pt | amarelo sobre preto |
| Ênfase no corpo | Noto Sans Bold colorido | 11 pt | ver seção 4: a cor da ênfase tem significado |
| Itálico | Noto Sans Italic | 11 pt | raro (2% dos caracteres): citações e termos latinos |

Nunca aparece: fonte serifada, duas famílias na mesma página, texto em caixa alta no corpo.

## 3. Paleta (hex por amostragem)

| Papel | Cor | Onde |
|---|---|---|
| Preto | #000000 | capa, contracapa, barra de título, cabeçalho de tabela, círculo de página |
| Amarelo marca | #FFD700 | título na barra preta, logo, filete esquerdo dos subtítulos |
| Amarelo-degradê do subtítulo | #FFF1C6 → #FFFFFF (esquerda → direita) | barra de subtítulo |
| Amarelo-caixa (resumo relâmpago, atenção) | #FFFBD4 / #FFF5D6 | fundo de caixa |
| Azul-caixa | #CFE8FC (fundo) · #2D79B6 (texto/borda) | caixa de conceito, termos definidos |
| Verde-caixa | #D9EEDA (fundo) · verde escuro (borda) | caixa de exemplo prático, item Certo |
| Laranja/pêssego | #FDE3C8 (fundo) · #FD761A (destaque) | caixa de pegadinha, termos de alerta |
| Vermelho | tom de erro | selo "ALTÍSSIMA PROBABILIDADE", item Errado, borda de "Possíveis pegadinhas" |
| Zebra de tabela | #F8F9FA | linhas alternadas |
| Borda de tabela | #DDDDDD | 1 px |

Regra de leitura: azul = definição; verde = correto/exemplo; laranja ou vermelho = alerta, pegadinha, errado; amarelo = síntese e estrutura. A cor nunca é decorativa: cada uma carrega um desses quatro significados.

## 4. Componentes (com frequência)

**4.1 Barra de título de seção** — regra (16/16). Faixa preta de margem a margem, cantos arredondados (~6 px), 36 px de altura, emoji à esquerda, título em caixa alta amarelo centralizado. Uma por página de seção; nunca duas na mesma página.

**4.2 Subtítulo em barra amarela** — regra. Filete preto de 4 px à esquerda, fundo em degradê amarelo → branco, emoji + texto em negrito 13 pt preto. Até 4 por página.

**4.3 Parágrafo** — regra. 2 a 4 linhas, justificado, com 1 a 3 termos em negrito colorido. Nunca mais de 5 linhas seguidas sem tabela, caixa ou subtítulo.

**4.4 Tabela padrão** — regra. **Duas colunas** em 89% das tabelas (474 de 539): "Conceito" | "Definição / Regra". Três colunas em 10% (acrescenta "Exemplo" ou "Papel"). Cabeçalho preto com texto branco em negrito e emoji antes de cada rótulo; zebra; bordas finas; célula da primeira coluna com o termo em negrito e o artigo entre parênteses.

**4.5 Caixa de destaque** — regra. Fundo pastel, filete colorido de 4 px à esquerda, cantos arredondados, rótulo em caixa alta com emoji ("⚠️ ATENÇÃO — PEGADINHA RECORRENTE", "💡 EXEMPLO PRÁTICO", "🔑 REGRA DE OURO"). Uma a duas por página; nunca duas da mesma cor seguidas.

**4.6 Selo de probabilidade** — regra (15/16). Pílula vermelha "ALTÍSSIMA PROBABILIDADE" ou laranja "ALTA PROBABILIDADE" + "de cobrança em concursos", em linha própria, depois do conteúdo a que se refere.

**4.7 Pódio "Pontos mais cobrados"** — regra (16/16). Lista 1º a 5º lugar com barras horizontais proporcionais, em laranja/amarelo.

**4.8 Questões comentadas** — regra (16/16). 5 a 6 questões, cada uma num cartão: enunciado, "Gabarito: ✅ Certo / ❌ Errado", "COMENTÁRIO:" em caixa verde (certo) ou laranja (errado).

**4.9 Resumo relâmpago** — regra (16/16). Página inteira de caixa amarela com lista de 10 a 15 frases curtas, termos em negrito.

**4.10 Possíveis pegadinhas** — regra (16/16). Lista de pares "❌ Errado: ... / ✅ Correto: ..." com borda vermelha, 8 a 12 pares.

**4.11 Emoji como ícone** — regra. Aparece em todo título, subtítulo, rótulo de caixa e cabeçalho de tabela. É parte da identidade; não substituir por ícones vetoriais.

## 5. Estrutura fixa do módulo (ordem observada em 16/16)

1. Capa preta: logo mapasPRO amarelo no topo, título em caixa alta à esquerda, arabesco preto em baixo-relevo no rodapé.
2. Sumário em caixa preta (1 a 2 páginas), itens com emoji, numeração 1 a 12.
3. Introdução (1 página de texto).
4. Conceitos fundamentais (tabela 2 colunas + caixa).
5. Blocos temáticos (6 a 10 páginas), cada bloco = barra preta + subtítulos amarelos + tabela + caixa; infográfico de página inteira a cada 2 ou 3 páginas de conteúdo.
6. Pontos mais cobrados em concursos (pódio).
7. Questões comentadas (2 páginas).
8. Infográfico "Armadilhas de concurso".
9. Resumo relâmpago.
10. Possíveis pegadinhas.
11. Contracapa preta: logo centralizado, e-mail, Instagram, site.

## 6. Densidade (o número que define "menos texto")

| Tipo de página | Proporção | Palavras (mediana) | Palavras (p90) |
|---|---|---|---|
| Seção com tabela | 48% | 170 | 241 |
| Seção só texto | 15% | 186 | 306 |
| Infográfico de página inteira | **26%** | 1 (texto dentro da imagem) | 11 |
| Capa, sumário, contracapa | 11% | — | — |

Por módulo: 6 a 10 infográficos (mediana 7); mediana de palavras por página de conteúdo entre 71 (Análise Financeira) e 165 (Fontes do DPC). Meta para qualquer módulo novo: **≤ 190 palavras na página de conteúdo e ≥ 25% de páginas de infográfico**.

Comparação com o PDF da LGPD v3: 37 páginas, 10 infográficos (27%, dentro da meta), mas páginas de conteúdo com 400 a 600 palavras e sem os componentes 4.1, 4.2, 4.5 a 4.10. É duas a três vezes mais denso que o padrão da casa.

## 7. Gramática dos infográficos

Observado em 113 páginas:
- Página inteira, fundo branco, sem moldura; título em caixa alta no topo.
- Famílias recorrentes: **hub central** (círculo com o tema e 4 a 6 blocos radiais) — a mais comum; **comparação em duas colunas** (ex.: absoluta × relativa) com cores opostas; **fluxo vertical** (etapas 1 → 4, cada uma num bloco colorido); **matriz 2×2**; **pirâmide/hierarquia**; **escada**; **funil/filtros**.
- Blocos em cores saturadas e distintas por categoria (azul #2D79B6, laranja #FD761A, verde, roxo, vermelho); texto branco ou preto dentro do bloco; ícone flat em cada bloco.
- Fecho em quase todas: faixa inferior amarela ou vermelha com "REGRA DE OURO", "ALERTA DE PROVA" ou "PEGADINHA RECORRENTE".
- Texto exato de lei dentro da figura (artigo entre parênteses).
- Risco documentado: as figuras são imagens rasterizadas com texto embutido; a auditoria da LGPD encontrou erros de conteúdo em 2 das 6 figuras antigas. Para novos infográficos, manter a *gramática* acima mas gerar por código (SVG), com texto vindo do material auditado.

## 8. Contabilidade × Processo Civil

Mesmo sistema. Diferenças: Contabilidade tem páginas menos densas (mediana 89 palavras contra 130) e mais infográficos proporcionalmente (29% contra 25%), porque usa mais quadros numéricos. Nenhum componente é exclusivo de uma disciplina. Para a LGPD (lei seca), seguir a densidade de Processo Civil e a proporção de infográficos de Contabilidade.

## 9. Proibições implícitas (não aparecem em nenhum dos 16)

- Parágrafo corrido com mais de 5 linhas.
- Página de conteúdo sem pelo menos um elemento de cor (tabela, caixa ou barra).
- Tabela com mais de 3 colunas (6 ocorrências em 539 — exceção, não padrão).
- Fonte serifada; texto alinhado à esquerda no corpo; ícones vetoriais no lugar de emoji.
- Infográfico menor que a página, ou duas figuras na mesma página.
- Nota de rodapé, referência bibliográfica, citação de doutrina com autor.
- Página inteira de questões sem comentário em caixa colorida.

## 10. Critério de pronto

Uma página nova está no padrão quando: usa a barra preta 4.1 ou é um infográfico de página inteira; tem no máximo 190 palavras; tem pelo menos uma tabela de 2 colunas ou uma caixa 4.5; cada termo-chave está em negrito colorido com o significado da seção 3; e o leitor não distingue de uma página de qualquer dos 16 módulos.
```

### A4 — `REGISTRO-DE-AUDITORIA.md`
Tipo: registro de verificação · Versão: v3.1a (16/10/2026) · Estado: vivo

```markdown
# REGISTRO DE AUDITORIA — Kit LGPD CEBRASPE v3 (01/10/2026)

Método: cada afirmação conferida por busca no texto consolidado da LGPD (Planalto, 30/09/2026); estatísticas recontadas nos cadernos TEC Concursos (397 questões). "Confirmada" = sem alteração; "Corrigida" = texto alterado; "Removida" = excluída do material.

## Textos legais (Parte I do arquivo do Projeto)
- 288 artigos receberam cabeçalho "LEI — Art. N" (LGPD 80; LAI + Decreto 7.724: 135; Marco Civil + Decreto 8.771: 73). Motivo: cinco "art. 11" no mesmo arquivo; o cabeçalho evita que a busca do ChatGPT cite a lei errada.
- 37 linhas com anotações do Planalto quebradas no meio do texto foram reparadas (ex.: LGPD art. 52, § 6º; 55-D, §§ 3º e 4º; 55-G; 55-L; 58-A, III; 58-B; Decreto 8.771, arts. 16-D a 16-N). Nenhuma palavra do texto legal foi alterada; só as anotações entre parênteses foram recompostas.
- Anotações duplicadas ("(Incluído...) (Incluído...)") reduzidas a uma.

## Estatísticas (Kit, C.1 e C.2)
- Total: 395 → 397 (corrigida; 396 de 2020–2026 e 1 de 2014).
- Requisitos para o tratamento (arts. 7º a 10): 55 → 57 (corrigida).
- Itens C/E: 302 → 304 (corrigida); múltipla escolha: 93 (confirmada).
- Gabarito C/E: 52/48 → 160 Certo (53%) e 144 Errado (47%) (corrigida).
- Questões em 2025: 110 → 112 (corrigida). 2020: 5 e 2026: 89 (confirmadas).
- Demais blocos (172, 42, 21, 18, 12, 11, 9, 9, 9, 8, 7, 7, 6, 5, 3, 1): confirmados.
- Fonte das estatísticas passou a constar no cabeçalho do Kit.
- Não auditado por decisão do editor: a classificação por assunto do TEC.

## Padrões de erro (Kit, C.3 e C.4)
- 13 → 14 padrões: o item "nome do órgão" (antes "item 14"/"Padrão 14" sem constar da lista) virou o Padrão 14 canônico.
- Padrão 11 ampliado para "Número ou rol trocado", com cinco exemplos de rol. Motivo: pegadinhas de rol (boa-fé, fundamentos × princípios) não cabiam em nenhum padrão.
- Tabela C.5: acrescentadas as linhas "72 horas" (art. 48, § 1º) e "quem indica o encarregado" (art. 5º, VIII × art. 41, caput).

## Resumo esquematizado (Parte III)
- Seção 1: tabela de pesos realinhada aos cadernos; percentuais recalculados sobre 397.
- Seção 10: "26 questões" mantido, agora explicitado como 21 (arts. 23 a 30) + 5 (arts. 31 e 32).
- Seção 15: "7 questões" mantido, explicitado como 6 ANPD + 1 CNPD.
- Seção 3: acrescentada a nuance art. 5º, VIII ("controlador e operador") × art. 41, caput ("o controlador deverá indicar").
- Seções 6 e 14: notas "figura em refação" removidas; figuras novas inseridas com legenda.
- Nomes de arquivo do guia: `05-resumo-esquematizado-lgpd.pdf` → arquivo único (corrigida).

## Figuras
- Pirâmide dos dados, roda dos princípios, direitos do titular, arquitetura da responsabilização: confirmadas (reaproveitadas).
- Árvore "o dado é sensível?": removida e refeita. Erros da anterior: 6 caminhos para sensível em vez de 8 (faltavam art. 11, II, b e g); "pesquisa em saúde" onde a lei diz "estudos por órgão de pesquisa" (II, c).
- Escada de sanções: removida e refeita. Erros da anterior: 6 degraus em vez de 9; "publicização após a imposição de multa" — a lei exige apenas apuração e confirmação (art. 52, IV).
- Arquitetura da responsabilização: legenda corrigida ("indicação obrigatória para controladores" → redações do art. 5º, VIII e do art. 41).
- Novas: mapa de aplicação (arts. 3º e 4º), fluxo poder público → privado (arts. 26 e 27), linha dos números, balança do legítimo interesse (art. 10). Todos os números e artigos conferidos no texto da lei.

## Mapas mentais (12) e discursivas (20)
- Todos os dispositivos citados conferidos no texto da lei. Verificações pontuais registradas: art. 24, parágrafo único; art. 11, § 5º; art. 14, § 3º; art. 19, I; art. 26, § 1º; art. 52, §§ 3º e 6º; art. 55-D, § 3º; art. 58-A, § 2º.

## Questões inéditas
- 40 originais do kit mantidas (auditoria individual pendente para a próxima versão).
- 20 novas com situação hipotética (H01 a H20): 10 Certas e 10 Erradas; gabaritos e artigos conferidos.

## Limites conhecidos
- A Lei nº 15.352/2026 e o Decreto nº 12.975/2026 são posteriores ao conhecimento de referência do auditor; a conferência foi feita contra o texto consolidado fornecido, não contra fonte independente. Recomenda-se uma conferência no sítio do Planalto antes da publicação.
- Reprodução das 99 questões reais: as questões são públicas (CEBRASPE); conferir os termos de uso do TEC Concursos quanto à compilação.

## v3.1 (01/10/2026) — PDF do aluno regerado no padrão da casa
- Base: GUIA-DE-ESTILO-mapasPRO (medido em 16 módulos). Componentes aplicados: barra preta de título com emoji, subtítulo em degradê amarelo, tabelas de duas colunas com cabeçalho preto e zebra, caixas (atenção / exemplo / regra de ouro / conceito), selo de probabilidade, pódio, questões comentadas, resumo relâmpago, pegadinhas em pares Errado/Correto, numeração em círculo preto, capa e contracapa pretas.
- Densidade: páginas de conteúdo entre 120 e 190 palavras (antes: 400 a 600). 51 páginas: 1 capa, 1 sumário, 15 de conteúdo, 10 infográficos, 12 mapas mentais (refeitos em retrato), 1 pódio, 2 de questões, 1 resumo relâmpago, 1 pegadinhas, 5 de discursivas, 1 guia, 1 contracapa.
- Corte de texto: saiu tudo que não está na tabela de pegadinhas, nos 14 padrões ou nos subtemas com ≥ 9 questões. Dispositivos removidos do PDF (continuam no arquivo do Projeto): art. 7º, § 3º; art. 12, § 2º; art. 13 (pesquisa em saúde pública); art. 14, §§ 2º, 5º e 6º; art. 18, §§ 2º e 6º; art. 19, §§ 1º e 3º; arts. 21 e 22; art. 23, § 5º; art. 25; art. 32; arts. 34 a 36; art. 46, §§ 1º e 2º; arts. 47, 49, 50, 51; art. 52, §§ 1º (critérios), 2º, 5º, 7º; art. 53; art. 55-C, 55-E, 55-J (detalhe das competências); art. 58-B.
- Pendências: contatos da contracapa (e-mail, Instagram, site) não estavam em texto nos módulos — inserir; emoji monocromático (fonte Noto Emoji) por limitação do gerador, enquanto os módulos usam emoji colorido.
- Fonte geradora: fonte-geradora-pdf.py (conteúdo em dados + CSS); regenera o PDF em um comando após qualquer correção.

## v3.1a (01/10/2026) — correções apontadas em revisão cruzada (ChatGPT)
- Figura "Arquitetura da responsabilização" (p. 31 do PDF): a imagem reaproveitada ainda trazia o rodapé antigo "indicação obrigatória para controladores". A faixa foi cortada da imagem e a legenda passou a citar art. 5º, VIII e art. 41, caput. Lição: a auditoria textual não vê texto dentro de imagem; revisão final tem de ser visual.
- Descrição da amostra: o prompt de chat único dizia "397 questões, 2020–2026"; corrigido para "396 de 2020 a 2026 e 1 de 2014", igual ao registro.
- Rótulo "auditada": passa a significar "conferida contra o texto consolidado do Planalto de 30/09/2026", com as pendências listadas (40 questões inéditas antigas sem auditoria individual; Lei nº 15.352/2026 sem conferência em fonte independente).
```

### A5 — `GUIA-DE-INSTALACAO.md`
Tipo: instrução ao aluno · Versão: v3 (01/10/2026) · Estado: final, desatualizado quanto a D21/D22

```markdown
# GUIA DE INSTALAÇÃO — Kit LGPD CEBRASPE · MapasPro (v3)

Tempo: 3 minutos. Funciona no plano gratuito do ChatGPT. Você vai usar UM arquivo no ChatGPT e UM PDF para ler e revisar.

**O que você recebeu**
1. `LGPD-CEBRASPE-projeto.md` — arquivo único para o ChatGPT (leis, kit, resumo, mapas e discursivas).
2. `LGPD-CEBRASPE-aluno.pdf` — material de leitura: resumo auditado, 10 infográficos, 12 mapas mentais, tabela de pegadinhas, 20 temas de discursiva e este guia.

**Instalação no ChatGPT (Projeto)**
1. Menu lateral → Projetos → Novo projeto. Nome: "LGPD CEBRASPE".
2. Abra `LGPD-CEBRASPE-projeto.md` em qualquer editor de texto. Copie o bloco inicial, que vai do título "INSTRUÇÕES DO PROJETO" até o fim do item 10 do menu, e cole no campo **Instruções** do projeto. Salve.
3. Em **Arquivos**, envie `LGPD-CEBRASPE-projeto.md`. Não envie outros arquivos: o PDF é para você, e arquivos a mais confundem a busca.
4. Abra um chat dentro do projeto e digite `menu`. Escolha o modo pelo número.
5. Teste: digite `9` e pergunte "a quem a ANPD está vinculada?". A resposta certa é "Ministério da Justiça e Segurança Pública (art. 55-A, Lei nº 15.352/2026)". Se vier "Presidência da República", o ChatGPT respondeu de memória: repita a pergunta pedindo "confira no arquivo".

**Sem Projeto (chat comum)**
Cole o conteúdo do arquivo `PROMPT-LGPD-CEBRASPE-chat-unico.md` numa conversa nova. Esse modo não tem o texto da lei: as citações literais ficam menos confiáveis.

**Gemini e NotebookLM**
Gemini: cole as Instruções na primeira mensagem e anexe o `.md`. NotebookLM: envie o `.md` como fonte; no chat, escreva "Siga as Instruções do início do arquivo. Modo 1."

**Como estudar (plano de 7 dias, 30 a 40 min/dia)**
Dia 1: modo 1 em arts. 1º a 6º + mapas 1 a 3. Dia 2: modo 1 em arts. 7º a 13 + mapas 4 e 5. Dia 3: simulado (modo 3). Dia 4: modo 1 em arts. 14 a 22 e 23 a 32 + mapas 6 a 9. Dia 5: múltipla escolha (modo 4). Dia 6: modo 1 em arts. 37 a 58-B + mapas 10 a 12; uma discursiva (modo 6). Dia 7: revisão de véspera (modo 7) e tabela de pegadinhas (modo 8).

Sempre que errar um item, digite `5` e cole o item com a sua resposta. O padrão que se repetir é o que você precisa reler na lei.

**Atualizações**: a lei muda. Este kit reflete o texto consolidado do Planalto em 30/09/2026 (com a Lei nº 15.352/2026). Versões novas são avisadas por e-mail a quem comprou.
```

### Artefatos não reproduzidos aqui (caminho e função)

| Arquivo | Tamanho | Função |
|---|---|---|
| `kit-lgpd-v3/LGPD-CEBRASPE-projeto.md` | 437 kB | Arquivo único do Projeto: A1 + leis com 288 cabeçalhos "LEI — Art. N" + kit (14 padrões, 99 reais, 60 inéditas) + resumo + 12 mapas em texto + 20 discursivas |
| `kit-lgpd-v3/LGPD-CEBRASPE-aluno.pdf` | 8,9 MB, 51 p. | PDF do aluno no padrão da casa (v3.1a) |
| `kit-lgpd-v3/_anterior-...-v3-denso.pdf` | 8,1 MB, 37 p. | Versão anterior, densa; mantida para comparação |
| `kit-lgpd-v3/fonte-geradora-pdf.py` | 38 kB | Script que gera o PDF (conteúdo em dados + CSS); regenera tudo em um comando |
| `kit-lgpd-v3/figuras/fig1..fig6` (PNG+SVG) | — | Árvore de sensíveis; mapa de aplicação; escada de sanções; fluxo poder público→privado; linha dos números; balança do legítimo interesse |
| `kit-lgpd-v3/mapas-mentais/mapa01..12` (PNG+SVG) | — | 12 mapas, gerados de `mapas.md` por `mindmap.py` |
| `guia-de-estilo/prancha-*.png` | — | Folhas de contato e detalhe que sustentam A3 |
| `guia-de-estilo/metricas-por-modulo.csv` | 804 B | Páginas, infográficos, tabelas e palavras por módulo |

Versões anteriores, com a diferença em uma linha:
- Prompt v1 (`00-instrucao-projeto.md`, do usuário): 13 padrões, sem hierarquia de verdade, sem regras mecânicas de simulado, menu com 10 modos.
- Prompt v2: acrescentou hierarquia de verdade, bloco de correção e rodapé de placar (substituído em v3 pelo plano bloqueado).
- Prompt chat-único v1→v3.1a: ampliação do Padrão 11 para rol; "por que se erra" como confusão concreta; proibição de copiar exemplos; proibição de marcação antes da resposta; correção da descrição da amostra.
- Resumo v2 (upload do usuário) → v3: estatísticas, 14 padrões, figuras refeitas, nuance art. 5º, VIII × art. 41.
- PDF aluno v3 (denso) → v3.1 (padrão da casa) → v3.1a (figura de responsabilização corrigida).

## 6. Conhecimento consolidado por tema

### 6.1 Comportamento do ChatGPT como tutor (medido em teste nesta conversa)

- FATO — Com o texto da lei anexado (modo Projeto), o ChatGPT citou corretamente o art. 11, II, "g" e o art. 55-A, com linha do arquivo, e respondeu "Agência Nacional... vinculada ao Ministério da Justiça e Segurança Pública". Fonte: resposta colada pelo usuário em 01/10/2026; linhas 139 e 468 do arquivo 01 conferidas por busca.
- FATO — Com o prompt de chat único (sem a lei), acertou nome e vinculação da ANPD, mas citou "art. 41" para "controlador e operador", quando essa redação está no art. 5º, VIII. Conclusão registrada: sem o texto legal, a literalidade não é confiável.
- FATO — Em simulado, o item veio sem vazamento de gabarito e o bloco de correção saiu na ordem definida.
- FATO — Na primeira versão, classificou "boa-fé é princípio" como Padrão 11 (número trocado) porque o prompt obrigava a atribuir um padrão e nenhum cabia. Correção: D08.
- FATO — Copiou literalmente um exemplo do prompt como enunciado do item 1. Correção: D10.
- FATO — O ChatGPT apontou, e foi confirmado, que o PDF v3.1 trazia na figura de responsabilização o texto antigo ("indicação obrigatória para controladores"), que a auditoria declarava corrigido. Causa: texto dentro de imagem não é visto por auditoria textual.
- HIPÓTESE — "Plano bloqueado" melhora o comportamento mas não garante contagem em todos os ambientes (posição do ChatGPT; não refutada).

### 6.2 Conteúdo jurídico auditado (LGPD)

- FATO — Lei nº 15.352/2026 renomeou o órgão para "Agência Nacional de Proteção de Dados (ANPD)", autarquia de natureza especial vinculada ao Ministério da Justiça e Segurança Pública (art. 55-A). Verificado no texto consolidado fornecido; **não verificado em fonte independente** (lei posterior ao conhecimento de referência do auditor).
- FATO — Art. 11, II, "g" (literal, conferido): "garantia da prevenção à fraude e à segurança do titular, nos processos de identificação e autenticação de cadastro em sistemas eletrônicos...".
- FATO — Encarregado: art. 5º, VIII diz "indicada pelo controlador e operador"; art. 41, caput, diz "o controlador deverá indicar". As duas redações são literais e a banca pode usar qualquer uma.
- FATO — São 9 sanções vigentes no art. 52 (VII, VIII e IX vetados); multa até 2%, teto R$ 50 milhões por infração; suspensões até 6 meses prorrogáveis; órgão público não paga multa (§ 3º); X, XI e XII só após uma sanção de II a VI (§ 6º).
- FATO — Art. 33 tem 9 hipóteses de transferência internacional, não 8.
- FATO — Art. 4º, § 4º: em nenhum caso a totalidade dos dados por pessoa de direito privado, salvo capital integralmente constituído pelo poder público.
- FATO — Não há prazo legal para comunicação de incidente ("prazo razoável, conforme definido pela autoridade nacional", art. 48, § 1º) nem prazo máximo de guarda (arts. 15 e 16).
- FATO — Erros encontrados nas figuras antigas: árvore de sensíveis com 6 caminhos (faltavam art. 11, II, "b" e "g") e com "pesquisa em saúde" onde a lei diz "estudos por órgão de pesquisa"; escada com 6 degraus e "publicização após imposição de multa" (a lei exige apenas apuração e confirmação, art. 52, IV).

### 6.3 Estatísticas da banca (amostra, não probabilidade futura)

- FATO — Amostra: 397 questões CEBRASPE classificadas como LGPD nos cadernos TEC Concursos, extraídas em 30/09/2026 — 396 de 2020 a 2026 e 1 de 2014.
- FATO — Formato: 304 itens Certo/Errado (160 Certo, 144 Errado) e 93 de múltipla escolha.
- FATO — Por bloco: arts. 1º a 6º: 172; arts. 7º a 10: 57; arts. 11 a 13: 42; poder público (23 a 32): 26; direitos do titular: 18; agentes e responsabilidade: 32; demais: 50.
- FATO — Divergências corrigidas em relação ao kit original: total 395 → 397; requisitos 55 → 57; itens C/E 302 → 304; 2025: 110 → 112.
- NÃO CONFIRMADO — A classificação por assunto é do TEC e não foi auditada (D12).

### 6.4 Padrão visual mapasPRO (medido em 16 módulos, 434 páginas)

- FATO — A4; margens ~64/47/61/24 pt (assimétrica à esquerda); numeração em círculo preto; 20 a 37 páginas por módulo, mediana 26.
- FATO — Fonte única Noto Sans: corpo 11 pt justificado, tabela 10 pt, subtítulo 13 pt, título 16 pt; itálico raro.
- FATO — Paleta: preto #000000, amarelo #FFD700, degradê #FFF1C6→#FFF, azul #CFE8FC/#2D79B6, verde #D9EEDA, laranja #FDE3C8/#FD761A, zebra #F8F9FA. Cor com significado: azul=definição, verde=correto, laranja/vermelho=alerta, amarelo=síntese.
- FATO — 89% das tabelas têm **duas** colunas (474 de 539); três colunas em 10%.
- FATO — Emoji aparece em todo título, subtítulo, rótulo de caixa e cabeçalho de tabela nos 16 módulos: é identidade, não ruído.
- FATO — Densidade: página com tabela, mediana 170 palavras (p90 241); página só texto, mediana 186; 26% das páginas são infográfico de página inteira (6 a 10 por módulo).
- FATO — Estrutura fixa em 16/16: capa → sumário → introdução → conceitos → blocos → pódio "pontos mais cobrados" → questões comentadas → armadilhas → resumo relâmpago → possíveis pegadinhas → contracapa.
- FATO — Não aparece em nenhum módulo: parágrafo com mais de 5 linhas; tabela com mais de 3 colunas (6 exceções em 539); fonte serifada; infográfico menor que a página; nota de rodapé ou citação de doutrina com autor.

### 6.5 Formato técnico dos arquivos

- FATO — Os PDFs do projeto de Direito Administrativo são pacotes ZIP com imagens por página e OCR; `pdfinfo` falha; extrair com `unzip -q -o`. (Instrução do projeto, confirmada na prática.)
- FATO — O arquivo 01 original tinha 37 linhas com anotações do Planalto quebradas no meio de parágrafos (ex.: art. 52, § 6º; 55-D, §§ 3º e 4º; Decreto 8.771, arts. 16-D a 16-N). Reparadas sem alterar o texto legal.
- FATO — Cinco artigos "11" diferentes convivem no arquivo único (LGPD, LAI, Decreto 7.724, MCI, Decreto 8.771); daí os cabeçalhos "LEI — Art. N".
- FATO — O gerador de PDF disponível (wkhtmltopdf) exige `zoom: 1.30` no body para mapear 297 mm à página A4, e só renderiza emoji monocromático (Noto Emoji), enquanto a casa usa colorido.

## 7. Alternativas descartadas

| Alternativa | Motivo do descarte | Onde consta |
|---|---|---|
| Gerar infográficos por modelo de imagem | Erra grafia e número dentro da figura; inaceitável para texto jurídico | Proposta sobre figuras |
| Enquadrar o Padrão 14 nos padrões 3 ou 11 | Esconderia a pegadinha mais nova da banca | Rodada 1 |
| Rodapé de placar a cada item para manter 52/48 | Substituído por 5/5 fixo + plano bloqueado (D04, D05) | Rodada 1 |
| Tabela padrão de três colunas no PDF | Medição mostrou que a casa usa duas em 89% | Guia de estilo |
| Proibir emoji no PDF (proposta do brief anterior) | Invertido pela medição: emoji é identidade | Guia de estilo |
| Modo "jurisprudência" e outras bancas no piloto | Sem base no material; geraria invenção | D20 |
| Barras de "domínio" por tema no diagnóstico | Promete medida que a amostra não sustenta | D22 |

## 8. Pendências e próximos passos registrados

| Item | Origem | Estado |
|---|---|---|
| Revisão do `LGPD-CEBRASPE-projeto.md` pelo ChatGPT | Prometida em 16/10/2026 | aberto — aguardando |
| Implementar D21 (simulado de sequência fixa) e D22 (registro de sessão) no `projeto.md` | Última rodada | aberto |
| Cinco ajustes de regra aceitos: transcrever só após localizar; tipificar questão (real/adaptada/editorial/gerada); definir `menu`, `pausar`, `retomar` no simulado; formatos de correção por modo; artigo "provável, não confirmado" quando não houver texto legal | Última rodada | aberto |
| Códigos tipados de conteúdo (`LGPD-T07`, `LGPD-M05-TXT`, `LGPD-Q012`, `LGPD-F01`) no PDF e no MD | Proposta do ChatGPT, aceita | aberto |
| Protocolo de 8 testes de aceitação, 3 execuções cada | Proposta do ChatGPT, aceita | aberto |
| Teste A/B: PDF único (Partes A+B+C) × dois arquivos | Proposta do ChatGPT | aberto |
| Auditoria individual das 40 questões inéditas herdadas do kit original | Auditoria v3 | aberto |
| Conferência da Lei nº 15.352/2026 em fonte independente (Planalto) | Auditoria v3 | aberto |
| Contatos da contracapa do PDF (e-mail, Instagram, site) | v3.1 | bloqueado — depende do usuário |
| Emoji colorido no PDF (exige outro gerador) | v3.1 | aberto, baixa prioridade |
| Termos de uso do TEC quanto à reprodução das 99 questões reais | Etapa de definição do produto | aberto — decisão do usuário |
| Extrair o CORE universal do `projeto.md` para reuso em outras disciplinas | Discussão com o ChatGPT | aberto |

## 9. Vocabulário, nomes e convenções

- **mapasPRO / MapasPro** — marca; logo "mapas" amarelo + "PRO" branco sobre preto.
- **Kit** — conjunto distribuído ao aluno. **CORE** — parte do prompt que não depende da disciplina. **Módulo** — parte específica (leis, kit da banca, resumo).
- **Padrão N** — um dos 14 padrões de erro da CEBRASPE (C.3 e C.4 do kit).
- **Pegadinha** — linha da tabela C.5: "como a banca escreve" × "como está na lei" × artigo.
- **Selo de probabilidade** — pílula "ALTÍSSIMA/ALTA PROBABILIDADE de cobrança em concursos".
- **Resumo relâmpago**, **Possíveis pegadinhas**, **Pontos mais cobrados** — seções fixas do padrão da casa.
- **Cabeçalho de artigo** — `### LEI — Art. N` (ex.: `### LGPD — Art. 11`).
- **Modos 1 a 10** — menu do tutor (resumo, flashcards, simulado C/E, múltipla escolha, corrija meu raciocínio, discursiva, véspera, pegadinhas, livre, mapa mental).
- **TEC Concursos** — origem dos cadernos de questões. **Qconcursos / Folha Dirigida** — origem do Censo 2025.
- Arquivos: `LGPD-CEBRASPE-projeto.md`, `LGPD-CEBRASPE-aluno.pdf`, `PROMPT-LGPD-CEBRASPE-chat-unico.md`, `GUIA-DE-INSTALACAO.md`, `REGISTRO-DE-AUDITORIA.md`, `fonte-geradora-pdf.py`, `GUIA-DE-ESTILO-mapasPRO.md`.

## 10. Preferências e instruções de trabalho expressas pelo usuário

- Comentários didáticos e inteligíveis para leigos, com exemplos práticos e metáforas, ponderados com objetividade — sem prolixidade.
- Toda resolução ancorada em citação exata (módulo + conceito + página; ou lei + artigo); ler a página antes de citar, nunca citar de memória.
- Conteúdo fora dos materiais deve ser sinalizado com ⚠️ "Conteúdo complementar"; nunca forçar ancoragem.
- Corrigir publicamente o mapa de cobertura quando uma verificação mais fina reclassificar um tema.
- Verdade e exatidão acima de utilidade; sinalizar incerteza; não inventar fonte, número, citação ou função; avisar quando o tema puder ter mudado depois do conhecimento de referência; perguntar quando faltar contexto em vez de supor.
- Decidir sozinho o que for óbvio, em vez de pedir confirmação desnecessária.
- Trabalhar em blocos temáticos, com diagnóstico ao fim de cada bloco.
- Português do Brasil.

## 11. Relação com outros projetos

- Produção de carrosséis, reels e stories MapasPro a partir de clusters de erro → pertence ao projeto/skill MapasPro de redes sociais; não desenvolvido aqui.
- Resumos de Direito Administrativo (9 módulos em PDF-ZIP) e de Processo Civil/Contabilidade (16 módulos) → material de outras disciplinas; aqui foram usados apenas como fonte do guia de estilo e como contexto do projeto de origem.
- Censo dos Concursos 2025 (Qconcursos) → material de mercado; usado apenas como contexto, sem entrar no produto.

## 12. Lacunas

- Revisão do `projeto.md` pelo ChatGPT: prometida e não entregue até a data desta extração.
- Resultado dos testes de aceitação: nenhum dos 8 testes foi executado; os testes relatados nesta conversa foram pontuais, sem registro de ambiente e sem repetição.
- Conferência independente da Lei nº 15.352/2026 e do Decreto nº 12.975/2026.
- Auditoria individual das 40 questões inéditas herdadas do kit original.
- Contatos de contracapa: não existem em texto nos módulos da casa (estão dentro de imagem).
- Termos de uso do TEC Concursos: não consultados.
- Versões anteriores dos módulos mapasPRO e o arquivo editável das figuras antigas: não disponíveis; por isso duas figuras foram refeitas em vez de corrigidas.
- A conversa menciona um "PDF – Complementos" para acumular lacunas do projeto de Direito Administrativo: não foi produzido nem localizado.

## 13. MEMÓRIA NÃO VERIFICADA

Não aplicável. Toda a informação deste extrato vem da conversa ou dos arquivos lidos.
