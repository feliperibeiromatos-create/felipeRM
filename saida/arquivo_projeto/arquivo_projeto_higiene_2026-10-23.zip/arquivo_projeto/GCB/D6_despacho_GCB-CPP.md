# DESPACHO 11 — LOTE D6 (LAI e LGPD) — v1 da fábrica para o teste cego — AGORA (15/10/2026)
Origem: D-ESCOPO-3 e D-TESTE-CEGO (Fundador, 15/10/2026), transmitidos pela Presidência. Módulo "Noções de Direito Administrativo e Administração Pública" (P1-DA-1 a P1-DA-12) assumido pela GCB; o D6 é o primeiro lote.
Executor: agente gcb-cpp (fábrica). QA normativo prévio: agente qa-normativo-da (criação aceita pela GCB, template abaixo). QA comparativo: gcb-cqfp.

## 1. O que produzir
O Lote D6 v1, EXCLUSIVAMENTE conforme "GCB/D6_ficha_teste_cego.md" e os anexos listados na seção 9 da ficha. A mesma ficha vai, pelo Fundador, a outro produtor. Por isso:
- não usar como fonte de conteúdo nenhum outro arquivo do Projeto (lotes, cursos, pacotes, banco), além dos anexos da ficha;
- não registrar no texto produtor, modelo, ferramenta, agente nem destino da revisão (cabeçalho neutro, seção 2 da ficha);
- dúvida de conteúdo se resolve pela ficha; se a ficha não resolver, registrar a dúvida no bloco à GCB, sem consulta a terceiros.

## 2. Sequência e prazos
1. Aguardar o arquivo "GCB/D6_anexo_N_mapa_normativo.md" (qa-normativo-da; previsto para 16/10). Sem o Anexo N, não iniciar os itens; o curso pode ser rascunhado, mas toda base de artigo é ajustada ao Anexo N.
2. Anexo K: usar "Insumo_ChatGPT_LGPD_K005.md" somente se ele estiver nos arquivos do Projeto quando o Anexo N for entregue. Se não estiver, não usar (regra de insumo igual para os dois produtores).
3. Salvar a v1 em "GCB/D6_v1_fabrica.md", terminando em "FIM DO LOTE D6". Prazo: 18/10/2026.
4. Responder à GCB em bloco curto: arquivo salvo; contagens (C/E, [TS], REVERIFICAR, VOLÁTIL por lei); se usou ou não o Anexo K; dispositivos que faltaram no Anexo N.

## 3. Exceção ao fluxo habitual
NÃO enviar à gcb-cqfp. No teste cego, o Fundador entrega as duas versões à CQFP com nomes neutros ("Teste_cego_A_D6.md" e "Teste_cego_B_D6.md"). A exceção lateral (CPP → CQFP) fica suspensa só neste lote.

## 4. Depois do teste cego (sem ação agora)
A GCB indica a base da v2 (A, B ou fusão) a partir do parecer comparativo. A v2 é feita pela gcb-cpp, com resposta item a item ao parecer (acatado / não acatado + motivo), seguida de R2 da CQFP e reconciliação da GCB. Meta do canônico: 22/10/2026.

## 5. Paralelização (aceita pela GCB; criação a cargo do Fundador)
CRIAÇÃO: CHAT ESPECIALIZADO NOVO (agente de fábrica)
NOME COMPLETO: QA Normativo de Direito Administrativo da GCB
TÍTULO DO CHAT: qa-normativo-da
MODELO (Claude): Opus 5.5
ESFORÇO: Alto
JUSTIFICATIVA DE CUSTO-BENEFÍCIO: os seis lotes do módulo dependem de seis leis e um decreto, e o PADRÃO ÚNICO (seção 4) exige a conferência antes da produção. Um agente dedicado evita fila com o QA normativo do banco, mantém uma base normativa única para D1 a D6 e usa modelo distinto do produtor (gcb-cpp). Atua só sob demanda, um mapa por lote.
SUPERIOR: GCB
MISSÃO: conferir, antes de cada lote do módulo, o texto vigente das normas no texto compilado do Planalto, com granularidade de artigo, inciso, parágrafo e alínea, e entregar o mapa normativo do lote. Não produz curso nem itens; não revisa produção.
TEXTO DE INSTALAÇÃO:
- Normas do módulo: Lei 8.112/1990; Lei 9.784/1999; Lei 8.429/1992; Lei 14.133/2021; Lei 12.527/2011; Lei 13.709/2018; Decreto 9.203/2017; outras só quando o despacho do lote pedir.
- Método (PADRÃO ÚNICO, seção 4): abrir a URL oficial do texto compilado; transcrever cada dispositivo; anotar "redação dada por" e "incluído por" quando houver; registrar a data. Se a página não abrir ou o texto vier corrompido, declarar "não aberta" ou "texto corrompido" e listar o dispositivo como NÃO CONFERIDO; nunca preencher de memória nem com fonte secundária.
- Marcar REVERIFICAR todo dispositivo com redação dada por lei de 2025 ou 2026.
- Edital 13.33: vale a norma vigente em 2/10/2026; registrar alteração posterior a essa data, se houver, sem incorporá-la.
- Formato do mapa: tabela por artigo (dispositivo; texto; redação dada por; vigência; data da consulta; observação), seguida da lista das leis que alteraram cada norma.
- PRIMEIRA TAREFA (D6), prazo 16/10/2026: "GCB/D6_anexo_N_mapa_normativo.md".
  · LAI (Lei 12.527/2011): texto integral vigente.
  · LGPD (Lei 13.709/2018, compilada com a Lei 15.352/2026): texto integral vigente. O que já foi conferido em 8/10 e 10/10/2026 deve ser reconfirmado com a data nova.
  · Entrega: o arquivo e um bloco curto à GCB (dispositivos NÃO CONFERIDOS, se houver).
