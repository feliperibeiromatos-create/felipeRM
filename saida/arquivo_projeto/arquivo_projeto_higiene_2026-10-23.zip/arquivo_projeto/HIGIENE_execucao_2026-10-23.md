# HIGIENE DO PROJETO — REGISTRO DE EXECUÇÃO (23/10/2026)
Base: HIGIENE_Projeto_lista_v1 (Presidência, 22/10/2026), aprovada pelo Fundador em 22/10. Executor: sessão Cowork (Claude), por ordem do Fundador em 23/10/2026.

## O que foi feito
1. Inventário do Projeto em 23/10, antes da execução: 92 documentos de texto + 16 uploads PDF (20 entradas, 4 nomes duplicados) = 108, igual à base da lista.
2. Cruzamento nome a nome da lista com os paths reais: 0 divergências. Grupo A = 22 docs de texto + 9 PDFs; grupos B1/B3/B4/B5/B6 = 70 docs de texto; B2 = 7 PDFs.
3. Backup dos 70 docs de texto em saida/arquivo_projeto/ (este pacote), cópia byte a byte do conteúdo devolvido pela ferramenta Projects, conferida por script (MANIFESTO_backup_2026-10-23.md traz tamanho e SHA-256 de cada um). Três cópias intermediárias feitas por subagente divergiam do original (GCE_BIP_retorno.md, GBQ/pacote_v1_gatilhoA_GBQ.md, claude/diag30_selecao_para_revisao.json) e foram substituídas pelo conteúdo exato antes do zip.
4. Exclusão dos 70 docs de texto no Projeto, grupo por grupo (B1 15, B3 18, B4 12, B5 23, B6 2). Todas confirmadas pela ferramenta.
5. Verificação final: restam no Projeto exatamente os 22 docs de texto do grupo A; base de conhecimento caiu de 1.647.128 para 596.085 bytes.

## O que NÃO foi feito (limites da ferramenta) — pendente do Fundador
- B2 (7 PDFs de 2007/2012): a ferramenta Projects não exclui uploads de PDF e devolve só o texto extraído, não o arquivo original. O texto está em B2_pdfs_2007_2012_texto_extraido/. Para preservar os PDFs originais, baixar pela interface do Projeto; a exclusão deles também é pela interface.
- Passo C.1/C.2 da lista (push pendente; confirmar cada arquivo no git da fábrica): esta sessão não tem acesso ao repositório felipeRM (403). Substituído pelo backup completo deste pacote, a ser commitado em saida/arquivo_projeto/ antes de descartar o zip.
- Renomear Estado_Canonico_Camara_2026_v61_2026-10-20.md para Estado_Canonico_Camara_2026.md: fica para quando a Secretaria publicar o "Estado atual" curto, como prevê a lista.

## Regra daqui em diante (seção D da lista) — vigente
Entra no Projeto: edital, Estado atual, padrão único, limites da Presidência de Ciclo, instruções datadas, última versão de cada lote canônico, provas e padrões oficiais. Não entra: pacote.json, versões anteriores, insumos, pareceres, despachos, relatórios, material de outros projetos. Toda substituição de canônico apaga a versão anterior no Projeto (a anterior fica no git).
