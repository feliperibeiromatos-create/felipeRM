# MANIFESTO — backup dos documentos excluídos do Projeto (HIGIENE v1, D-HIGIENE)
Gerado em 2026-10-23 (America/Sao_Paulo) pela sessão Cowork, antes de qualquer exclusão.
Origem: documentos de texto do Projeto claude.ai 'Plataforma - Tutor de IA' (Câmara 2026), lidos pela ferramenta Projects.
Fidelidade: cada arquivo é cópia byte a byte do conteúdo devolvido pela ferramenta (conferido por script; 3 cópias intermediárias divergentes foram substituídas pelo conteúdo exato).
Destino sugerido na fábrica: saida/arquivo_projeto/ (commit antes de apagar no Projeto).

| grupo | path no Projeto | bytes | sha256 |
|---|---|---|---|
| B1 | GBQ/pacote_v1_auto.json | 410923 | e01b5f6085c75de0bbe57349414cf6c4b0ddaf14c3fcb10786117215935e63db |
| B1 | GBQ/pacote_v1_fabrica.json | 541533 | d318382639ee24ecbfa09efd9c44edf930427e594274ae3e59dd611c16607cbe |
| B1 | GBQ/pacote_v1_2_fabrica.json | 618673 | f46ed9f8e43db76aaeb96eda0b2924028fb7145c048c5eb0189396c9f67304fe |
| B1 | GBQ/pacote_v1_QA_auto.md | 87034 | c227f60cab3b5526c965ad1d96a6745504ee8ecf3aac1e5dd49c4ea064723b76 |
| B1 | GBQ/pacote_v1_relatorio_auto.md | 7462 | 51c97e5194d6e91e8a75185dff4190093e56040ef5046d2b46213f0f36139840 |
| B1 | GBQ/pacote_v1_gatilhoA_GBQ.md | 1834 | c70b17a8ea017cf5f4cf8f3b52511e58a83f23a037e6663b786c36322d084b05 |
| B1 | GBQ/pacote_v1_2_relatorio_fabrica.md | 94852 | 7baececd7443f11c9866c82dcad5e5ee86e5f182aa9e071178cf022b778a7057 |
| B1 | GBQ/pacote_v1_2_gatilhoA_GBQ.md | 3988 | 05fcedb899d3d372db4afe3e04bd9edfe89f7949fd1e6636991c556545955522 |
| B1 | GBQ/pacote_fabrica_conferencia_GBQ.md | 5748 | 3303b9936051181c7bd2e11d90aa17989f9e87cfa51f8a313c2571331bc7ff78 |
| B1 | GBQ/pacote_fabrica_gatilhoA_GBQ.md | 3420 | 7b3440469b434a7624fba9975fde1bf86c42d48c8ffa7f5d778906de4bbf9781 |
| B1 | GBQ/CSC-S_Conferencia_pacote_v1.md | 3881 | f582f46d921a36cd92db445a60942366048a39b77a756276e2c0815dfaaef92b |
| B1 | GBQ/CSC-S_Conferencia_pacote_fabrica_v1.md | 14629 | 07f36027b2f02ca445642c23b9b334dd2cfd80d556df65d25e9745b84d616d63 |
| B1 | GBQ/CSC-S_Protocolo_Calibracao_v1.md | 11209 | eca63dda769d11a37cc4ecb449cb22ae5fbba7bebcd00f98a89a355de3befd83 |
| B1 | GBQ/CSC-S_Protocolo_Calibracao_v1.1.md | 11040 | f49ab301b59bd3c4a2c9f6f5bf08df6aaed34fa4ffbfcd06183116691461b36a |
| B1 | GBQ/banco.csv | 106445 | 969c0bfd7ff03c108b19137b78fbce45fc6f7b13ea93266aa5a0b56e3bd5f841 |
| B3 | GCE_Lote1C_v1_CPP.md | 9067 | fad4d55af42c2082f7e2c212c8e0b2e1cb074ae3cd93920cb28f815c44fbc758 |
| B3 | GCE_Lote2_v1_CPP.md | 43908 | edcfe64b5222fdf4e75a5d2c102defc0d57c6bb76dec97938b22004c9438bc49 |
| B3 | GCE_Lote3_v1_CPP.md | 48928 | 519591834a8d1cf44c911b760b6d16af7bd002294bc07c5f1f083b7ae39d92d8 |
| B3 | GCB/Lote5_insumo_A_RECONCILIADO_piloto_ClaudeCode.md | 32046 | 2c3a9b32cc35c485adfdf3587d79bf73e661a68efc3861e3c4daa17ffcfc59aa |
| B3 | GCB/Lote5_insumo_B_Presidencia_v1_producao.md | 27817 | 01e97789768e71534ba9e463eeb2c46c7a786839b26db42461f67d8e4b44b907 |
| B3 | GCB/Lote5_parecer_QA_comparativo_CQFP.md | 11287 | e9f7bfe5593c6cc5dcfbddd55aa9eec5b8fb740e86135cc22bb7bdb5bb47c2cc |
| B3 | GCB/Lote4C_parecer_QA_R1_CQFP.md | 7932 | 594848365190b1293d11751ddc27f46d9b8cb5d401077cf2a2a7c0302600549c |
| B3 | GCB/Lote5C_parecer_QA_R1_CQFP.md | 6732 | cc733e6aba5e98ae478ca727d7acf44f2a96a80087e5f7c12b0496809deab637 |
| B3 | GCB/Lote6a_parecer_QA_R1_auto.md | 33064 | bb8c48f935d0fa9ab8a231321bb75758400f5a6e11cd52c4a302cd5d11a5453b |
| B3 | GCB/Lote6b_parecer_QA_R1_auto.md | 39495 | 68ed5c0bd699ff6b43ce0e0c6094c5304372df822c3f63810db91f81fcb55361 |
| B3 | GCB/Conferencia_ACONFIRMAR_Lote4_CQFP.md | 14390 | 8a6baa3577f868192192e5d56183ca0734de1c7c7e1415ac1460e20c77b0a4a1 |
| B3 | GCB/Conferencia_v3_Lotes4e5_CQFP.md | 6509 | c82b6118a26e5d70890b7d0162acbd987480ebedb581beacca683213e5df135e |
| B3 | GCB/Lotes6_conferencia_CQFP.md | 9262 | 190177c0ccbfdff22d5ae5099bcd94ab2d7db96e43bc9902c960a5af85979472 |
| B3 | GCB/Lotes6_especificacao_PRES-S.md | 6172 | ebd90c97370499a8b90901c8bc5c85b7fd5ef8ce65268dd45a0987a55e604fc2 |
| B3 | GCB/lote6_conferencia.md | 29632 | 68c0f3532936b23629fa48cf914e6680da9a708c491cf3061610253dc0aea382 |
| B3 | GCB/lote6_reconciliacao.md | 11157 | efbf010f80baeba06020a777a86faaedf7c53e9c6ddbd7110f46287b905b9180 |
| B3 | claude/GCE_erratas_reconciliacao_2026-10-10.md | 7481 | 1faf010d1b625ed3c8776ac214cf5ef74fab3607f9f2103569f28f1bc248b526 |
| B3 | claude/GCE_EXEC-02_conferencia_auto.md | 2873 | 9c0e1107fe143ffd41ab7efb7ee984e503b1bf47dcbe9d18c697e3522a4a7c78 |
| B4 | GCB/Despachos_pendentes_GCB-CPP.md | 31869 | df91f792a034dc88bf48b39616461c7ebe89e45a839844d6b61ee82a009727b3 |
| B4 | GCE_Despachos_pendentes_GCE.md | 22120 | b4493af5d25ef5410915efba3920f134f27fbccd08183bb695ef32c64ec30c33 |
| B4 | GCB/D6_despacho_GCB-CPP.md | 4578 | d6cd2d5bcc85add6a7587890b2ee044a7b46ab13557ed919e8226c1379c39919 |
| B4 | GCB/D6_ficha_teste_cego.md | 12556 | 1572e8c7d25ecee76f31ee69ea3eeec989119d33bd3c347b755c65f74ff85ca3 |
| B4 | GCE_BIP_retorno.md | 16441 | c36ced712d59ad85e75999feacc545bc3851320db1497ab6bba6399bde5c8c9b |
| B4 | GCE_BIP_retorno_v2.md | 36543 | b17c7d7f5b974a18bb7e82e35eb843f8a37573f192b726af64c54b2130506ba7 |
| B4 | GCE_ItensReais_P9_GCE.md | 6929 | 07d549f7ae282ef589a67520514c588bc1e572f2e181d5a8aead4c9fec83bc13 |
| B4 | claude/GBQ_Registro_AUTORAL_Lotes4e5.md | 203 | f45a230d42c8851b5deb8f58f4bd48528996ce5292a52bcecd6a41f4cd4c1ab0 |
| B4 | claude/GBQ_Registro_AUTORAL_v2.md | 7702 | c8e6c4758edb55cc5f03545e0431349ef162b653c97697f763eaaf06e3520660 |
| B4 | claude/GBQ_Registro_AUTORAL_v3.md | 12700 | ea75efde4b286515db03d086ce1fc761c27dfdebb1694721360f54095a9663f9 |
| B4 | Fundador_Fila_Presidencia.md | 35742 | b19d37dda3b27f453fde3b2a56f63a1a4e497a60699c1e6ba9da1e4abd8b9b48 |
| B4 | fabrica_estilo_banca_v1.md | 1001 | a94a471fdc00172841861b418887a086acf61ee02690a5a8784f30d193b90eb3 |
| B5 | claude/EXEC_Protocolo_Executora_Automatizada.md | 2183 | 62331e231be61691378be2a6d522c324d3ad847c9c56f642f19393f5851819b1 |
| B5 | claude/FABRICA_Protocolo_Autonomia_v1.md | 33202 | b7ed0f33fd9973bff5cdbbbd5d333713d0b579caa514d597fd68dc28565257c5 |
| B5 | claude/ORDENS_FABRICA_encomenda_v15_2026-10-18.md | 12472 | 01ac5ec2329c787411f494f1446e9babc5aeb8caae31fd951d43eea2acc018c4 |
| B5 | claude/ORDEM_DA_FORMATO_2026-10-19.md | 2385 | 45787385d9b816e2975f07adf205d56ecb153d18cb8f64a07cb4752be2041985 |
| B5 | claude/ESPEC_curso_DA_formato_v1_2026-10-19.md | 6701 | 7eeb0c4b9b465799cde75c7bab9036405d3f0e60484214c77cd9f55b8634bd1d |
| B5 | claude/PLANO_v15_quatro_abas_2026-10-18.md | 11708 | 1de63485ac8c06453d0c76c72a36541eaea84f7fc8e13682a4c391a02e276b57 |
| B5 | claude/REGISTRO_v14_resposta_auditorias_2026-10-18.md | 5171 | 948a9810213fc06f43b9e49df3c7e20802c56c57cb683d2468e19f95f7c99fa9 |
| B5 | claude/REGISTRO_v15_previa_2026-10-18.md | 6806 | a01b03a701919098720da6aa22a50439df0c4613b2fb38814ea30e506860cd48 |
| B5 | claude/REGISTRO_v15_1_revisao_design_2026-10-18.md | 6375 | 57e3ac9fef6d510c40d22a2f41e2fd494e6f16dc58c844861685248e81422434 |
| B5 | claude/REGISTRO_v15_5_DA_laboratorio_2026-10-19.md | 3057 | 86f04d88b015e840e8c6c9ce79aab23133072a06c006315dd0d7e3eb78f473fc |
| B5 | claude/ROTEIRO_entrada_pacote_Fabrica_2026-10-18.md | 7208 | f11c114cc696576133938225f2fc5c79c085f9389e8f1f9d858bb4cb93cc7d7b |
| B5 | claude/INVENTARIO_marcas_producao_v1.9_2026-10-18.md | 9196 | 3a5469b0227bb54be0d793306b5d5a9df9b654632f2a11462bf8e93922bf8d84 |
| B5 | claude/ONBOARDING_Fase1_relatorio_2026-10-18.md | 4163 | 7694bcc5fa491e81ee3c787f0698937f9c79c6879fb2b019cb82dfc961b01820 |
| B5 | claude/ONBOARDING_Fase2_relatorio_2026-10-18.md | 3382 | 0e9563218bfb31913749685b6e4b4047eb73a4765cdb24a770ee38e28e91bb8d |
| B5 | claude/DPE-01_designer-plataformas-estudo_v0.2.md | 9282 | e07b90fa369c70319c58e163eece3a330bd525a26619d9fddaf2eec9f1ffec3c |
| B5 | claude/DPE-01_execucao-1_2026-10-18.md | 7639 | 6f8d3d8bc42259394de47a9c28dd3500730e2c8f9133b4d1b72a331240e4464a |
| B5 | claude/DPE-02_prompt_explicar-escolha_v0.1.md | 4373 | 076bcee996cb7568269cd41b36aa400166d8f5d6a220373a77a4f85a1d04b580 |
| B5 | claude/diag30_final.json | 612 | 0de84bb09770968b29580b3488dd6cec7a2316520ee9a86f8c9bbc5b0e8d5e7a |
| B5 | claude/diag30_selecao_para_revisao.json | 53236 | 0ab3e4933b522040867f57dc15833d000a0770c122da32225a8c1ad3cc7dd58d |
| B5 | claude/diag30_selecao_v2_vigente.json | 46557 | 486ab3ea539e5c4eb6357f67a2b79dc90585666cad13fd41aadc40d2745b39cd |
| B5 | claude/kit_pacote/checa_pacote.py | 15513 | d2cfd2f7269010afea598106ec787c042d834db8240063309bfe681a068afa59 |
| B5 | claude/kit_pacote/embute_pacote.py | 1578 | 7d394da1c70dbd4bbc939909f783ebb73383ff667aef7d89a1c2ccdd9a139c27 |
| B5 | claude/kit_pacote/regressao_pacote.py | 12534 | 336919741994c706a4db13d961c351a80ab86a22e2da53578de8c33fc26ec8cb |
| B6 | EXTRATO-MAPASPRO-LGPD-CEBRASPE.md | 70296 | 833b801a54ed1e4e8305b380056c374e4c50faa16868f724b4a530e1a2b3b9d4 |
| B6 | mapaspro-pacote-contexto-completo-2026-10-04.md | 63856 | 05400278fb4fc2dc6ce08a05746700b741ca4f09eab256a069eda1169b0e38a4 |

## B2 — PDFs de 2007/2012 (7 arquivos)
A ferramenta Projects devolve apenas o TEXTO extraído dos PDFs, não os bytes originais. O texto está em B2_pdfs_2007_2012_texto_extraido/. Os PDFs originais devem ser baixados pela interface do Projeto antes da exclusão (que também só pode ser feita pela interface).
- Gab_Taquigrafo.pdf.texto.txt — 1763 bytes — sha256 2f35c38dfdc0c9c8563d4ab0b6a39eb7565b59781b89cdfefc5ab91786e82b4d
- Gab_TecLegislativa.pdf.texto.txt — 1815 bytes — sha256 d3ac5ae0797b78d8646a6550a14465a57e69323396f1bee7690b70458b0b2762
- Gab_Tipo 22_ObjPratica_Taquigrafo.pdf.texto.txt — 1784 bytes — sha256 c5f14819a901cfa370a6a9c74aed6a8fedee2598464396008674621c2872a783
- Gabarito-M13-tipo-1-Folha-1.pdf.texto.txt — 593 bytes — sha256 613f9789ab09e3ca0abcda67a92eb418f5ca9c920d04fffb12e5d8eca8f35e74
- LEIA-ME.txt — 319 bytes — sha256 d6817e173a81cfb3c87aabc372498bb2dc3ccafe45eddcca32f6d3596d80a413
- Prova-M13-Tipo-001.pdf.texto.txt — 70937 bytes — sha256 ad4ecf982c676b9e3b1631e9fef0aac94d3f23b1508174fcb048f82acda77d4b
- ProvaDisc-M13-Tipo-001 Taquigrafo.pdf.texto.txt — 70937 bytes — sha256 ad4ecf982c676b9e3b1631e9fef0aac94d3f23b1508174fcb048f82acda77d4b
- Prova_Taquigrafo.pdf.texto.txt — 25008 bytes — sha256 e97c1fe8d22bbbcd9558e212fd68a9ed21619be95350c3fb7da9efc05cd63a42

Total dos 70 documentos de texto: 2858292 bytes.
