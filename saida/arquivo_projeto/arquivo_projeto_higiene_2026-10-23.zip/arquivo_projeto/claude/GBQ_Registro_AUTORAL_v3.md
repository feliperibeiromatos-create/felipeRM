# GBQ — REGISTRO DE ITENS AUTORAL — v3 (12/10/2026; rev. 13/10: R4 ajustada, R5 revogada, R6 fechada, Lote 4 v3.4)
Emitido pela GBQ. Substitui a v2 (claude/GBQ_Registro_AUTORAL_v2.md), que fica como histórico. Incorpora os Lotes 6a e 6b (canônicos desde 10/10; D-ESCOPO-2 mantida pelo Fundador em 12/10).
Não reproduz enunciados; só metadados para montagem, conferência e calibração. O texto e o gabarito comentado estão nos arquivos de origem.
Tabelas geradas por script a partir da v2 (já conferida 150/150 contra o pacote da EXEC) e dos d-G dos Lotes 6a/6b; contagens dos Lotes 6 iguais às da conferência da GCB-CQFP (GCB/Lotes6_conferencia_CQFP.md) e às recontadas pela Secretaria.

## Fontes
| Lote | Arquivo de origem | Errata que prevalece |
|---|---|---|
| 1 | GCE_Lote1_v2_CPP.md (Q01–Q20) | GCE_Lote1_consolidacao_GCE.md |
| 1-C | GCE_Lote1C_v2_CPP.md (Q21–Q30) | GCE_Lote1C_consolidacao_GCE.md |
| 2 | GCE_Lote2_v2_CPP.md | GCE_Lote2_consolidacao_GCE.md |
| 3 | GCE_Lote3_v2_CPP.md | GCE_Lote3_consolidacao_GCE.md (Parte D) |
| 4 | GCB/Lote4_v3_canonica_GCB-CPP.md (v3.4; D-LOTE4-V34 e D-LOTE4-FONTE: a do Projeto é a canônica; itens e gabaritos iguais aos da v3.3) | — |
| 4-C | GCB/Lote4C_v1_GCB-CPP.md (v1.1) | — |
| 5 | GCB/Lote5_v3_canonica_GCB-CPP.md (v3.1) | — |
| 5-C | GCB/Lote5C_v1_GCB-CPP.md (v1.1) | — |
| 6a | GCB/Lote6a_v2_producao_auto.md (Parte 3/3) | conferência GCB-CQFP de 12/10 |
| 6b | GCB/Lote6b_v2_producao_auto.md (Parte 3/3) | errata A-6b-1 / T-17 — vista; A-6b-1 conferida (gcb-cqfp, Rodada 2; confirmada na Tarefa B da GBQ-CSC-S); textual, sem mudança de gabarito (R6 fechada) |

## Regras de elegibilidade (GBQ, D1)
- R0 (nova). Subitem SEMPRE com prefixo de prova (P1- ou P2-). Com os itens 1–4 de TI, os números colidem (P1-4.1 = backup e malware; P2-4.1 = LGPD em sistemas de transcrição e IA). Subitem sem prefixo é VIOLAÇÃO de forma.
- R1. VOLÁTIL: só simulado diagnóstico; inapto a simulado final até a reverificação de 4 a 8/1/2027. Lista: L1-Q14, Q16, Q18, Q19; L4-15; A5-14 a A5-17; 6A-01, 6A-09, 6A-10, 6A-14, 6A-15 (14).
- R1-N. REVERIFICAR (normativo): mesmo tratamento do R1 (L3-Q21).
- R2. L4-11 nunca no mesmo simulado que o item real TRF6 2024, Cargo 2, nº 81 (BQ-0010).
- R3. Itens reais NÃO entram neste registro e não se contam duas vezes; fonte canônica = banco (D-DEDUP-P9). Vale para TRF6 2024, Cargo 2, itens 70–76 (Lote 3, Parte D) e 96 e 98 (Lote 6b, seção de itens reais).
- R4. D-ADERENCIA. Decisão de mérito da GBQ, 12/10: os itens TRF6 70–76 (BQ-0002 a BQ-0008) são aderência PARCIAL. Motivo: o P2-4.1 é "LGPD e proteção de dados em sistemas de transcrição e IA", e os itens julgam LGPD geral no Judiciário. Também é parcial o uso compartilhado com o P1-6. Os itens TRF6 96 e 98 (BQ-0011 e BQ-0012) são DIRETA ao P1-4 ("Conceitos gerais de segurança e governança digital"), conforme o banco (D-BANCO-TI-1-4, 10/10). Isso substitui o mapeamento "parcial ao 4.1" do Lote 6b. Os AUTORAL são de aderência direta por construção.
- R5 — REVOGADA em 12/10 (GBQ, D1). O BACKLOG de "conferência visual humana" dos itens TRF6 96 e 98 fica fechado. Há duas leituras independentes do gabarito definitivo oficial com o mesmo resultado (96 = E; 98 = C): a da Presidência, em 7/10, e a da GCB-CQFP, em 12/10 (GCB/Lotes6_conferencia_CQFP.md). A CQFP conferiu também o ponto de julgamento no caderno oficial. Os dois itens (BQ-0011 e BQ-0012) são CEBRASPE_ANALOGA, DIRETA ao P1-4, aptos a simulado diagnóstico e final (D1-a, ratificada pela Presidência em 12/10, D-PACOTE-V11).
- R6 — FECHADA em 13/10. A errata A-6b-1 e a T-17 são textuais: sem mudança de gabarito, [TS], VOLÁTIL ou contagem (GCB/lote6_reconciliacao.md). O pacote da fábrica (v1.1) confere 30/30 com as linhas 6A/6B desta v3 em gabarito e subitem.
- Pacote: GBQ/pacote_v1_fabrica.json (v1.1) é canônico como conjunto de dados (D-PACOTE-V11, Presidência, 12/10), sem certificar a fidelidade textual nem ser edição do estudante. Condição D1-c: o SIM-1 não é aplicado antes da normalização dos comandos.
- D-83-SIMULADO: simulado final antes de 08/01/2027 sai sem item de P1-8.3.

## Totais
| Lote | Prova | Itens | C | E | [TS] | [TS] com gab. C | VOLÁTIL / REVERIF. | Aptos a final |
|---|---|---|---|---|---|---|---|---|
| L1 | P2 | 20 | 10 | 10 | 10 | 4 | 4 | 16 |
| L1C | P2 | 10 | 4 | 6 | 5 | 2 | 0 | 10 |
| L2 | P2 | 30 | 15 | 15 | 15 | 7 | 0 | 30 |
| L3 | P2 | 30 | 16 | 14 | 15 | 6 | 1 | 29 |
| L4 | P1 | 20 | 10 | 10 | 10 | 5 | 1 | 19 |
| 4C | P1 | 10 | 5 | 5 | 5 | 2 | 0 | 10 |
| A5 | P1 | 20 | 10 | 10 | 10 | 4 | 4 | 16 |
| 5C | P1 | 10 | 5 | 5 | 5 | 2 | 0 | 10 |
| 6A | P1 | 15 | 7 | 8 | 8 | 2 | 5 | 10 |
| 6B | P1 | 15 | 7 | 8 | 8 | 3 | 0 | 15 |
| TOTAL | — | 180 | 89 | 91 | 91 | 37 | 15 | 165 |
| subtotal P1 | P1 | 90 | 44 | 46 | 46 | 18 | 10 | 80 |
| subtotal P2 | P2 | 90 | 45 | 45 | 45 | 19 | 5 | 85 |

## Cobertura por subitem (aptos a final / total)
P2-1.1 4/4 · P2-1.2 4/4 · P2-1.3 4/4 · P2-1.4 5/5 · P2-1.5 4/4 · P2-1.6 2/3 · P2-1.7 2/3 · P2-1.8 1/3 · P2-2.1 4/4 · P2-2.2 4/4 · P2-2.3 4/4 · P2-2.4 4/4 · P2-2.5 4/4 · P2-2.6 3/3 · P2-2.7 4/4 · P2-2.8 3/3 · P2-3.1 4/4 · P2-3.2 4/4 · P2-3.3 4/4 · P2-3.4 4/4 · P2-4.1 4/5 · P2-4.2 5/5 · P2-4.3 4/4
P1-1 7/10 · P1-2 1/1 · P1-2.1 4/4 · P1-3 3/5 · P1-4.1 4/4 · P1-4.2 3/3 · P1-4.3 3/3 · P1-5.1 16/16 · P1-5.2 5/5 · P1-5.3 4/5 · P1-6 4/4 · P1-7.1 4/4 · P1-8.1 3/3 · P1-8.2 12/12 · P1-8.3 0/4 · P1-8.4 7/7
ALERTAS:
- P1-8.3: sem item apto a simulado final até janeiro.
- P2-1.8: 1 só item apto (L1-Q20).
- P1-2: 1 só item (6B-01).
- P1-4 (governança digital): 0 itens (R-5 do 6b, BACKLOG).
- P1-3: 3 aptos de 5 (6A-14 e 6A-15 VOLÁTEIS).

## Lote 1 (P2 1.1–1.8)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| L1-Q01 | E | P2-1.1 |  |  |
| L1-Q02 | E | P2-1.1 | TS |  |
| L1-Q03 | E | P2-1.2 |  |  |
| L1-Q04 | C | P2-1.2 | TS |  |
| L1-Q05 | C | P2-1.3 |  |  |
| L1-Q06 | E | P2-1.3 | TS |  |
| L1-Q07 | E | P2-1.4 |  | errata E1 (texto) |
| L1-Q08 | C | P2-1.4 | TS | errata E2 (texto) |
| L1-Q09 | C | P2-1.4 |  |  |
| L1-Q10 | C | P2-1.5 |  |  |
| L1-Q11 | C | P2-1.5 | TS | errata E3 (texto) |
| L1-Q12 | E | P2-1.6 |  |  |
| L1-Q13 | E | P2-1.6 | TS |  |
| L1-Q14 | C | P2-1.6 |  | VOLÁTIL |
| L1-Q15 | C | P2-1.7 |  |  |
| L1-Q16 | E | P2-1.7 | TS | VOLÁTIL |
| L1-Q17 | C | P2-1.7 | TS |  |
| L1-Q18 | C | P2-1.8 |  | VOLÁTIL |
| L1-Q19 | E | P2-1.8 | TS | VOLÁTIL |
| L1-Q20 | E | P2-1.8 | TS |  |

## Lote 1-C (P2 1.1–1.5)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| L1C-Q21 | E | P2-1.1 | TS |  |
| L1C-Q22 | E | P2-1.1 |  |  |
| L1C-Q23 | C | P2-1.2 |  | errata E3 (texto) |
| L1C-Q24 | C | P2-1.2 | TS |  |
| L1C-Q25 | E | P2-1.3 |  |  |
| L1C-Q26 | E | P2-1.3 | TS | errata E1 (comentário) |
| L1C-Q27 | C | P2-1.4 | TS |  |
| L1C-Q28 | E | P2-1.4 | TS | discriminação baixa (NB5) |
| L1C-Q29 | C | P2-1.5 |  |  |
| L1C-Q30 | E | P2-1.5 |  |  |

## Lote 2 (P2 2.1–2.8)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| L2-Q01 | E | P2-2.1 | TS |  |
| L2-Q02 | C | P2-2.1 |  |  |
| L2-Q03 | E | P2-2.1 |  |  |
| L2-Q04 | C | P2-2.1 | TS |  |
| L2-Q05 | C | P2-2.2 |  |  |
| L2-Q06 | E | P2-2.2 | TS |  |
| L2-Q07 | E | P2-2.2 |  |  |
| L2-Q08 | C | P2-2.2 | TS |  |
| L2-Q09 | E | P2-2.3 | TS |  |
| L2-Q10 | C | P2-2.3 |  |  |
| L2-Q11 | E | P2-2.3 |  |  |
| L2-Q12 | C | P2-2.3 | TS |  |
| L2-Q13 | C | P2-2.4 |  |  |
| L2-Q14 | E | P2-2.4 | TS |  |
| L2-Q15 | C | P2-2.4 |  |  |
| L2-Q16 | E | P2-2.4 |  |  |
| L2-Q17 | C | P2-2.5 | TS |  |
| L2-Q18 | E | P2-2.5 | TS |  |
| L2-Q19 | C | P2-2.5 |  |  |
| L2-Q20 | E | P2-2.5 |  |  |
| L2-Q21 | E | P2-2.6 | TS |  |
| L2-Q22 | C | P2-2.6 |  |  |
| L2-Q23 | C | P2-2.6 | TS |  |
| L2-Q24 | E | P2-2.7 | TS |  |
| L2-Q25 | C | P2-2.7 |  |  |
| L2-Q26 | E | P2-2.7 |  |  |
| L2-Q27 | C | P2-2.7 | TS |  |
| L2-Q28 | C | P2-2.8 | TS |  |
| L2-Q29 | E | P2-2.8 | TS |  |
| L2-Q30 | E | P2-2.8 |  |  |

## Lote 3 (P2 3.1–4.3)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| L3-Q01 | C | P2-3.1 |  |  |
| L3-Q02 | E | P2-3.1 | TS |  |
| L3-Q03 | E | P2-3.1 |  |  |
| L3-Q04 | C | P2-3.1 | TS |  |
| L3-Q05 | C | P2-3.2 |  |  |
| L3-Q06 | E | P2-3.2 | TS |  |
| L3-Q07 | E | P2-3.2 |  |  |
| L3-Q08 | C | P2-3.2 | TS |  |
| L3-Q09 | C | P2-3.3 |  |  |
| L3-Q10 | E | P2-3.3 | TS |  |
| L3-Q11 | E | P2-3.3 |  |  |
| L3-Q12 | C | P2-3.3 | TS |  |
| L3-Q13 | C | P2-3.4 |  |  |
| L3-Q14 | E | P2-3.4 | TS |  |
| L3-Q15 | E | P2-3.4 |  |  |
| L3-Q16 | C | P2-3.4 | TS |  |
| L3-Q17 | C | P2-4.1 |  | normativo |
| L3-Q18 | E | P2-4.1 | TS | normativo |
| L3-Q19 | C | P2-4.1 | TS | normativo |
| L3-Q20 | E | P2-4.1 | TS | normativo; errata E3 (comentário) |
| L3-Q21 | C | P2-4.1 |  | normativo; REVERIFICAR 4–8/1/2027 |
| L3-Q22 | C | P2-4.2 |  | normativo |
| L3-Q23 | E | P2-4.2 | TS | normativo |
| L3-Q24 | E | P2-4.2 |  | normativo |
| L3-Q25 | C | P2-4.2 | TS | normativo |
| L3-Q26 | C | P2-4.2 |  |  |
| L3-Q27 | C | P2-4.3 |  | normativo |
| L3-Q28 | E | P2-4.3 | TS | normativo |
| L3-Q29 | E | P2-4.3 | TS | normativo |
| L3-Q30 | C | P2-4.3 |  | normativo |

## Lote 4 (P1 5.1–5.3, 6)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| L4-01 | C | P1-5.1 | TS |  |
| L4-02 | E | P1-5.1 | TS |  |
| L4-03 | E | P1-5.1 | TS |  |
| L4-04 | C | P1-5.1 | TS |  |
| L4-05 | C | P1-5.1 |  |  |
| L4-06 | E | P1-5.1 | TS |  |
| L4-07 | C | P1-5.2 |  |  |
| L4-08 | E | P1-5.2 | TS |  |
| L4-09 | E | P1-5.2 |  |  |
| L4-10 | C | P1-5.2 | TS |  |
| L4-11 | C | P1-5.2 |  | R2 |
| L4-12 | C | P1-5.3 | TS |  |
| L4-13 | E | P1-5.3 |  |  |
| L4-14 | C | P1-5.3 |  |  |
| L4-15 | E | P1-5.3 |  | VOLÁTIL |
| L4-16 | E | P1-5.3 | TS |  |
| L4-17 | C | P1-6 | TS | normativo |
| L4-18 | E | P1-6 |  | normativo |
| L4-19 | E | P1-6 |  |  |
| L4-20 | C | P1-6 |  | normativo |

## Lote 4-C (P1 5.1)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| 4C-01 | E | P1-5.1 | TS |  |
| 4C-02 | C | P1-5.1 |  |  |
| 4C-03 | C | P1-5.1 | TS |  |
| 4C-04 | E | P1-5.1 | TS |  |
| 4C-05 | E | P1-5.1 |  |  |
| 4C-06 | C | P1-5.1 | TS |  |
| 4C-07 | C | P1-5.1 |  |  |
| 4C-08 | E | P1-5.1 | TS |  |
| 4C-09 | C | P1-5.1 |  |  |
| 4C-10 | E | P1-5.1 |  |  |

## Lote 5 (P1 7.1, 8.1–8.4)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| A5-01 | C | P1-7.1 |  |  |
| A5-02 | C | P1-7.1 | TS |  |
| A5-03 | E | P1-7.1 |  |  |
| A5-04 | E | P1-7.1 | TS |  |
| A5-05 | C | P1-8.1 |  |  |
| A5-06 | E | P1-8.1 | TS |  |
| A5-07 | E | P1-8.1 | TS |  |
| A5-08 | E | P1-8.2 |  |  |
| A5-09 | C | P1-8.2 | TS |  |
| A5-10 | E | P1-8.2 |  |  |
| A5-11 | C | P1-8.2 | TS |  |
| A5-12 | E | P1-8.2 |  |  |
| A5-13 | C | P1-8.2 | TS |  |
| A5-14 | C | P1-8.3 |  | VOLÁTIL |
| A5-15 | E | P1-8.3 | TS | VOLÁTIL |
| A5-16 | C | P1-8.3 |  | VOLÁTIL |
| A5-17 | E | P1-8.3 | TS | VOLÁTIL |
| A5-18 | C | P1-8.4 |  |  |
| A5-19 | E | P1-8.4 | TS |  |
| A5-20 | C | P1-8.4 |  |  |

## Lote 5-C (P1 8.2, 8.4)
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| 5C-01 | C | P1-8.2 | TS |  |
| 5C-02 | E | P1-8.2 |  |  |
| 5C-03 | E | P1-8.2 | TS |  |
| 5C-04 | C | P1-8.2 |  |  |
| 5C-05 | C | P1-8.2 |  |  |
| 5C-06 | C | P1-8.2 | TS |  |
| 5C-07 | E | P1-8.4 | TS |  |
| 5C-08 | E | P1-8.4 | TS |  |
| 5C-09 | C | P1-8.4 |  |  |
| 5C-10 | E | P1-8.4 |  |  |

## Lote 6a (P1 1 e 3) — IDs 6A-nn; marca = ferramenta
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| 6A-01 | E | P1-1 | TS | Word; VOLÁTIL |
| 6A-02 | C | P1-1 |  | Word |
| 6A-03 | C | P1-1 | TS | Word |
| 6A-04 | E | P1-1 | TS | Excel |
| 6A-05 | C | P1-1 | TS | Excel |
| 6A-06 | E | P1-1 | TS | Excel |
| 6A-07 | C | P1-1 |  | PowerPoint |
| 6A-08 | E | P1-1 |  | PowerPoint |
| 6A-09 | C | P1-1 |  | OneDrive; VOLÁTIL |
| 6A-10 | E | P1-1 | TS | OneDrive; VOLÁTIL |
| 6A-11 | E | P1-3 |  | correio |
| 6A-12 | E | P1-3 | TS | correio |
| 6A-13 | E | P1-3 | TS | correio |
| 6A-14 | C | P1-3 |  | Teams; VOLÁTIL |
| 6A-15 | C | P1-3 |  | Meet; VOLÁTIL |

## Lote 6b (P1 2, 2.1, 4.1–4.3) — IDs 6B-nn
| ID | Gab | Subitem | [TS] | Marca |
|---|---|---|---|---|
| 6B-01 | E | P1-2 |  |  |
| 6B-02 | C | P1-2.1 | TS |  |
| 6B-03 | E | P1-2.1 | TS |  |
| 6B-04 | C | P1-2.1 |  |  |
| 6B-05 | C | P1-2.1 |  |  |
| 6B-06 | E | P1-4.1 | TS |  |
| 6B-07 | E | P1-4.1 | TS |  |
| 6B-08 | C | P1-4.1 |  |  |
| 6B-09 | E | P1-4.1 |  |  |
| 6B-10 | E | P1-4.2 | TS |  |
| 6B-11 | C | P1-4.2 |  |  |
| 6B-12 | E | P1-4.2 |  |  |
| 6B-13 | E | P1-4.3 | TS |  |
| 6B-14 | C | P1-4.3 | TS |  |
| 6B-15 | C | P1-4.3 | TS |  |

FIM DO REGISTRO v3
