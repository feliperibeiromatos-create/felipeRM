# MapasPro — Pacote de Contexto Completo

**Compilado em:** 04/10/2026
**Finalidade:** levar todo o contexto do projeto MapasPro (construído no Claude entre maio e setembro de 2026) para uma conversa no ChatGPT — tanto para discutir estratégia e negócio quanto para produzir peças (carrosséis, Stories, Reels).
**Fontes:** 5 arquivos de memória do projeto, 16 documentos de referência do projeto (relatórios, instruções, changelogs, calendários) e os 17 chats do projeto (lidos por resumo e por trechos buscados).

---

## 0. Como usar este documento no ChatGPT

1. Cole o documento inteiro como primeira mensagem (ou anexe como arquivo) e, em seguida, cole o **bloco de instrução da seção 20**.
2. O documento está organizado do mais estável (marca, regras, identidade) para o mais volátil (estado atual, pendências). O que estiver nas seções 13 a 17 pode ter mudado depois de 04/10/2026.
3. Toda afirmação analítica carrega uma marcação. Peça ao ChatGPT para manter a mesma disciplina:
   - **FATO** — lido de arquivo ou declarado pelos sócios
   - **INFERÊNCIA** — julgamento a partir de fatos, com margem de erro
   - **SEM DADO** — a informação não existe nas fontes
   - **[A CONFIRMAR]** — há indício, mas não foi validado

---

## 1. Nota metodológica e limitações (leia antes)

- A pasta de transcrições (`/mnt/transcripts/`) estava **vazia** na compilação. O histórico dos chats vem de (a) resumos gerados pelo sistema de busca de conversas e (b) trechos específicos buscados dentro dos chats mais recentes. Isso significa que **detalhes finos de conversas antigas podem estar ausentes**; o que está aqui é o que ficou registrado em documento ou pôde ser recuperado.
- Os dados de vendas vão **até junho de 2026** (export Hotmart de 10/07/2026). Não há dados de jul–set/2026 em nenhuma fonte.
- Há **cinco versões** do relatório consolidado de 06/07/2026 e duas versões do documento de retomada (v1.3 e v1.4) no projeto. Elas se sobrepõem; este pacote consolida o conteúdo comum e sinaliza divergências.
- Alguns números aparecem com valores diferentes em fontes diferentes (ex.: seguidores 17.528 / 17.338 / 18.456 em datas diferentes; sazonalidade nov–jan como 41%, 43% ou 49% dependendo do recorte). Todos estão listados com a data/recorte de origem. **Não escolha um sem conferir o recorte.**
- Nenhuma lacuna foi preenchida com valor plausível.

---

## 2. A empresa em uma página

- **MapasPro** (@mapaspro · mapaspro.com.br) é uma marca brasileira **faceless** que vende **resumos esquematizados** em PDF para candidatos a concursos públicos. Distribui via **Hotmart** (e site WooCommerce — receita fora da Hotmart [A CONFIRMAR]) e faz marketing pelo **Instagram**.
- FATO: 156 vendas completas em ~23 meses (ago/2024–jun/2026); R$ 7.488 brutos; R$ 6.481 líquidos ao produtor; média ≈ R$ 325 brutos/mês. INFERÊNCIA: negócio em fase de validação, não de escala.
- FATO: a estação nov–jan concentra entre 41% e 49% da receita histórica (recorte varia), ligada a editais abertos.
- FATO: 94,9% das vendas históricas não tinham origem rastreada (SCK/UTM vazios). Atribuição implementada em set/2026 (declarado por Felipe).
- FATO: a única experiência de mídia paga (agência, out–dez/2025) teve ROAS-teto de 0,84 bruto — não se pagou nem na hipótese mais generosa — e quase fechou a empresa.
- INFERÊNCIA (diagnóstico de 29–30/09/2026): sistema editorial maduro e caro acoplado a um motor comercial que ainda não foi ligado; canal único e alugado (Instagram); custos não contabilizados (não se sabe se dá lucro); catálogo pulverizado; nenhum processo de venda com dono, meta e cadência.
- **Princípio-mestre do projeto:** validar antes de escalar; automatizar só o que provou funcionar. É o antídoto ao erro da agência.

---

## 3. Marca, posicionamento e voz

### Produto e posicionamento
- FATO: a empresa vende **apenas resumos esquematizados**. Decisão de ago/2026: o termo "mapa mental" **saiu** do posicionamento de produto e método. Se o público usar "mapa mental", tratar como linguagem de escuta, não como âncora. Pendência: bio/site/páginas ainda referenciando "mapas mentais" precisam ser atualizados.
- Slogan: **"O caminho para a aprovação"** (nunca aparece nas peças junto da logo).
- Posicionamento: **método, não milagre** — "constância vence intensidade". Concurseiro estratégico, não iniciante motivado.
- Foco histórico: concursos federais (PF, PRF, INSS, IBGE); verticais que **de fato vendem**: BB, PF, IBGE, TJ-SP, TJ-RJ.

### Voz
- Primeira pessoa do plural ("a gente"), direta ao "você", calorosa, capacitante ("chute com técnica", nunca "sem chute"), sem autoajuda vazia. Mais solta nos Stories que no carrossel, mas **sempre termina em método**.
- Enquadramento: concurso é competição relativa entre candidatos, não candidato contra a prova.
- Voz do fundador (Felipe): abre a peça com inversão do senso comum; método fecha; frases curtas, segunda pessoa direta, reticências como pausa, coloquialismos, aforismo de fechamento. **É tom e princípio — nunca vira estatística.**
- Posts de feed dedicados à "vivência do fundador"/motivação pura são **vetados** (performam mal historicamente); a voz aparece como tempero transversal dentro de outras peças.

### Regra faceless
- Os sócios **não aparecem** em vídeo ou foto. Substitutos aprovados: locução, bastidor de mãos/tela, escrita em 1ª pessoa, motion tipográfico.
- Avatares fictícios "Renata" e "Rodrigo" (concurseira/concurseiro-trabalhador, 38–42, subúrbio do RJ, estuda à noite, compra via Pix começando pelo resumo de R$ 9,90) foram criados em set/2026 como personagens **declaradamente gerados por IA** para teste A/B de gênero com o mesmo roteiro. Regras: sem concurso específico, sem alegação de aprovação, rotulados como IA na publicação.

---

## 4. Pessoas e governança

| Pessoa | Papel (FATO, corrigido em 29/09/2026) |
|---|---|
| **Felipe** | Sócio investidor e conselheiro; atuação estratégica e complementar; revisor do produto em última instância; opera o sistema editorial com IA (skills, Fase 0, análises). Trabalha no BNDES e tem ~4 h/dia disponíveis (compilação de 30/09) |
| **Cabeção** | Sócio operador: sobe materiais no Hotmart, elabora carrosséis, interage com o público (comentários e DMs) |
| **Jacaré** | Sócio operador: produz os resumos usando Perplexity e faz a revisão humana com fonte primária |
| Lorran | **Não é sócio** — videomaker contratado para um único vídeo. (Documentos até ago/2026 o tratam como sócio; isso foi corrigido em set/2026) |
| Ricardo | [A CONFIRMAR] — aparece em documentos de catálogo; papel não confirmado |
| Daniela Turati | Aprovada real (Papiloscopista PF 2024). **Nunca usar sem permissão explícita** (ainda não obtida) |

- **Mesa diretora:** Felipe, Cabeção e Jacaré.
- INFERÊNCIA registrada: há contradição entre o papel formal de Felipe ("apenas estratégico") e a prática (a maior parte da capacidade analítica e editorial passa por ele). Risco se a mesa planejar como se a operação se sustentasse sem esse trabalho.
- Proposta de governança (29/09, não ratificada): reunião quinzenal de 30 min com pauta fixa — três números (visitas rastreadas, vendas, receita), uma decisão registrada, pendências com nome e data. Donos propostos: Cabeção = conversão e atribuição; Felipe = medição; Jacaré = calendário de produto por edital e registro de revisão.
- Estrutura de chats combinada com Felipe (jul/2026): um chat semanal de produção (renovado a cada 3–4 semanas com documento de retomada), um chat de estratégia/checkpoints, chats descartáveis para tarefas pesadas.

---

## 5. Identidade visual e padrão de produção (inegociáveis)

### Sistema visual
- **Cores:** preto `#050505`, dourado `#FDB913`, branco `#FFFFFF`. Sem cores secundárias.
- **Fontes:** Archivo Black (títulos), Manrope (corpo), JetBrains Mono (labels/eyebrows). Embedadas em base64 — nunca via Google Fonts `<link>`.
- **Formatos:** carrossel 1080×1350; Stories/Reels 1080×1920.
- **Logo:** sempre **sem slogan**; 116px de altura no header das peças (Stories: 120–150px); preta sobre dourado, branca sobre preto; aplicada em pós-produção (nunca gerada por IA).
- **Proibições permanentes:** contador de slide (XX/06, 0X/05) em qualquer canto; número outline gigante; fonte/citação carimbada no visual (fontes vão como links no guia); figuras de IP de terceiros; conteúdo real de produto legível nas peças (exceção: cards R2 com página real do produto fornecida por Felipe, campanha PC); figuras públicas só com rótulo editorial e zero opinião política.
- Imagens geradas por IA: **permitidas** desde ago/2026 (revoga regra anterior); exceção: campanha PC-AL mantém regra de print real para amostras de produto.

### Padrão v3.2 de carrossel (edições permanentes de Felipe)
- Texto **centralizado** por padrão; linha única sempre que couber nos ~920px úteis; quebra só por necessidade ou enumeração; quebras manuais para silhueta simétrica (losango/afunilado).
- Mínimos: nada abaixo de 30px; corpo/subs/valores 38px+; labels 36–38px; rodapé 30px.
- Justificado só em texto corrido narrativo (bloco 900px, última linha centrada).
- Valores monetários por extenso ("R$ 50 milhões", nunca "R$ 50 mi"), isolados em linha própria.
- Máximo **1 exclamação** por peça.
- **Pilha de exemplos** (padrão para slide de regra + exemplos): regra em 1–2 linhas curtas centradas (38px) → exemplos empilhados, um por linha (44px Manrope semibold), palavra-chave em dourado inline, linhas de comprimento parecido → chip-clímax dourado + fecho de 2 linhas (a segunda mais curta).
- **Quadro de 3 colunas** (900–940px, grid 1fr/1.35fr/1fr, header mono dourado 30px, células 36–38px) para sínteses: lei·crime·pena, errado→certo, remédio·protege·gratuito. Bordão: "GRAVA ESTE QUADRO NA VÉSPERA".
- Slide de lista em dois blocos ("O QUE ACONTECE" / "COMO VIRAR O JOGO") em moldura dourada.
- Chip de save em duas linhas: "SALVA PARA A REVISÃO DE VÉSPERA / COMO SE FOSSE UM FLASHCARD".
- Slides **fecham no chip**; cortar "stingers" de coaching ("Agora você não cai", "Dez segundos"); máximo UMA frase de comentário por slide.
- Quadro-flashcard é completo ou não é (todas as variantes do conjunto entram).
- Número dito **uma vez** no carrossel; demais slides referenciam sem repetir.
- Headline pode carregar a tese inteira em 3–4 linhas afuniladas terminando no clímax dourado.
- Slide 2 sempre carrega a tensão (dor/problema/pergunta).
- Capa com arte: headline nunca cobre elementos-chave da ilustração; solução = reposicionar arte para cima e criar faixa preta inferior com gradiente para o texto; faixa superior de 180px dedicada à logo quando necessário.
- **Teste do print** (regra de 08/09/2026): a tríade selo + headline + bloco deve conter ao menos um termo **literal** do assunto; a metáfora ocupa uma camada, nunca as duas. (Capas "enigmáticas" como "PDF encolhido", "crase tipográfica", "5 chaves" falharam porque o assunto literal ficou só no subtítulo.)

### Padrão de Stories (validado em produção)
- Sequências de 3–5 quadros (ideal 3–4; drop-off chega a 50% com 7); uma ideia por quadro; frases curtas em linha única.
- Fundos alternados: dourado com texto preto (interação) e preto (narrativa).
- Logo real em todo quadro. Destaque de palavra-chave em bloco chapado na cor oposta.
- Sticker de interação no 1º quadro (countdown/enquete só com prazo real). RADAR de notícia: **sem** enquete embutida no 1º quadro.
- Zonas seguras: nada crítico nos 250px do topo nem da base. Caixas de zona de sticker dimensionadas ao conteúdo, não full-width.
- Selo de formato no topo: RADAR / COPA DO CONCURSEIRO / data comemorativa.
- Máximo 1 sequência de Stories por dia.
- Enquete como **coletor de dados**: o placar vira pauta (banca vencedora, erro mais votado, manhã × noite) — registrar sempre.

### Formatos com selo
- **RADAR · [CATEGORIA]** — categorias AUTORIZAÇÃO / EDITAL / RESULTADO / ATUALIDADE; 3 quadros; Fase 0 multi-fonte obrigatória; Radar sem notícia real **não sai**. Pode furar a fila de agendamento quando há urgência de mesmo dia.
- **RADAR deep-dive** — 1 concurso em 5 quadros: gancho + countdown → escala → "o que poucos contam" → como cai a prova/serviço → enquete de medição.
- **COPA DO CONCURSEIRO** — humor futebol × concurso; tom leve, desafio amigável, analogia que termina em lição de método; sem sarcasmo ácido; 100% tipográfico (zero marcas FIFA/CBF, zero fotos de jogador); postar **antes** dos jogos, nunca durante; reativo pós-jogo só com placar confirmado. Nunca dentro do RADAR.
- **Datas comemorativas** — arco de 4 quadros: humor A → humor B → lição → fecho emocional com "compartilha com essa pessoa".

### Regra de derivação (27/07/2026) e sua revogação parcial
- Regra original: todo carrossel e todo Reel gera uma sequência derivada de 3 quadros de Stories na manhã seguinte (11h–12h): F1 = capa/gancho adaptado + enquete do tema; F2 = um slide/card-clímax (sem resposta em quiz); F3 = CTA "post completo no feed" + sticker do post com seta.
- **Set/2026:** Felipe **não quer mais** receber Stories derivados nos kits de Reels/peças (não usa, gastam créditos). Entregar só os cards do Reel. A regra de derivação segue documentada nas skills, mas não deve ser executada por padrão.

### Cadência e agendamento
- Posts/Stories às **18h** fixas (exceção: RADAR urgente de mesmo dia). Feed seg/qua/sex no período de ago–set/2026.
- Feed: 1–2 carrosséis/semana com legendas >500 caracteres. Reels: 2×/semana (ter/sex) quando em Nível 2.
- **Fonte única de publicação: o agendador** (Meta Business Suite). Publicação manual só para RADAR urgente, removendo o slot equivalente. Motivo: 10 de 42 posts (23,8%) saíram duplicados em ago/2026 por publicação manual + agendador em paralelo; a segunda cópia rendeu menos em 4 de 5 pares.
- Cross-post Facebook: **permanentemente OFF** (foi a variável real por trás de uma queda de alcance que um relatório da Manus atribuíra erroneamente ao tema).
- Sem geotag (base nacional dispersa).
- Teste de cadência proposto (não executado): quarta à noite × domingo início de tarde, decisão pela mediana do D+7.

### Kit obrigatório de cada peça
- Legenda pronta (>500 caracteres no feed/Reel; gancho na 1ª linha; CTA de KPI; pergunta de fechamento).
- **Hashtags: exatamente 5** — 1 âncora (#concursopublico) + 1 disciplina/tema + 2 nicho profundo + #mapaspro. Em teste: #resumoesquematizado.
- Alt text por slide.
- Comentário fixado sugerido com bônus deixado fora dos slides (em post agendado, o bônus vai dentro da legenda).
- Rotina da 1ª hora (responder cada comentário validando e reforçando).
- Plano de interação nativa por objetivo (enquete 2 opções, caixa de pergunta, quiz; slider só para humor).
- Guia de postagem com seção "Legenda + Interação", configuração de stickers, tabela de fontes como links, janela de validade.
- Entregas: PNGs individuais no chat (nunca zip de PNGs); zip apenas dos HTMLs para edição futura.

### Fluxo com Manus AI (renderização visual)
- Claude = blueprint, fact-check, engenharia de prompt, QA; Manus = render visual.
- Strings de texto passadas entre aspas e reproduzidas exatamente (acentos, cedilhas, símbolos); ~40–70 palavras por arte; logo aplicada em pós-produção; Claude emite aprovação ou lista cirúrgica de correções a cada render.
- Lição registrada: a Manus tende a "preencher o vazio com plausibilidade" — no carrossel Calendário Eleitoral publicou 3 erros factuais (data "01/01/2027", "cerca de 60 dias", ícone "July 17") que o framework P1–P6 evitou. Em mapas densos perdeu ~70% do conteúdo. Relatórios de Insights gerados pela Manus já trouxeram misleituras (fuso UTC×BRT; causalidade errada tema×alcance; CTA "ausente" nos Reels) corrigidas por Felipe.

---

## 6. Disciplina editorial

### Fase 0 — regra de ouro
Todo número, data, salário, vaga, banca ou resultado esportivo é verificado em fonte confiável **antes** de produzir: fonte primária (Planalto, DOU, edital, site da banca) ou mínimo três veículos especialistas (Gran, Estratégia, Folha Dirigida, JC Concursos, PCI). Nunca afirmar resultado de jogo não terminado. Dado divergente entre fontes **não entra** (ex.: salários da Receita Federal ficaram fora de um story porque três fontes divergiam). Em dúvida, não publica. Claim não verificável vira `[A CONFIRMAR]` e **congela a peça**. Fase 0 vale também para **produto**: antes de anunciar material para um edital, conferir se cobre o edital vigente e a banca correta.

Casos em que a Fase 0 pagou (registrados para a cultura do projeto): prorrogação do Edital IBGE 01 pega antes de sair um story com prazo morto; divergência salarial da Receita; recusa de afirmar autorização de Receita/INSS antes da portaria; resultado errado "Costa do Marfim segurou a Alemanha" barrado; Lei 15.358/2026 alterando 8 leis penais descoberta antes de uma peça sair com pena desatualizada.

### Princípios P1–P6
- **P1** Fonte primária ou nada.
- **P2** Sinalizar > inventar (lacuna vira `[PLACEHOLDER]`).
- **P3** Sem matéria, sem post.
- **P4** Conflito de dados sinaliza para humano (versão qualitativa, nunca escolher um valor).
- **P5** Sem agregados retóricos ("maior ciclo da história", "X% dos candidatos" sem desagregação).
- **P6** Headline fisga sem mentir (curiosity gap fecha dentro da peça).

### Estruturas e KPIs de carrossel
| Sigla | Estrutura | KPI |
|---|---|---|
| A | Educacional | SAVE |
| B | Comparativa (bancas, caminhos) | SAVE |
| C | Listicle | SAVE/SHARE |
| D | Story do aprovado (**exige aprovado real com permissão**) | SHARE |
| E | Mito vs Verdade | COMMENT/SHARE |
| F | Urgência / reta final (evento ≤ 60 dias) | CLICK |

Cadência de estruturas testada: F → C → C → E → B → E (nunca repetir estrutura em sequência; checar `ULTIMOS_2_POSTS`). Padrão 6 slides (5–8 aceito).

### Etapa 4A — headlines
8 variações rankeadas por técnica (T1 especificidade numérica · T2 curiosity gap honesto · T3 loss aversion · T4 identificação · T5 contraste/paradoxo · T6 quebra de expectativa), ≤ 8 palavras, sem CAPS/emoji/clickbait, score 0–100 (especificidade 30, gatilho 25, honestidade 20, conformidade 15, fit 10). A #1 vira oficial; as outras ficam documentadas. Ganchos-pergunta com termo literal do tema dominam o topo dos 90 dias ("Quem julga um ministro do STF?", "Você chama todo malware de 'vírus'?").

### Validator e Radar-scorer
- Validator (Python + SQLAlchemy): NUMBER_UNSOURCED (block), NUMBER_STALE (warn, >90 dias), NAME_FABRICATED (block), HEADLINE_TOO_LONG (block, >8 palavras), BANNED_PHRASE (block), INPUT_UNVERIFIED (warn). Meta: 0 blocks, 0 warns. Lição: registrar unidade sem barra ("horas", não "horas/dia") — gerou 5 falsos positivos.
- Radar-scorer: S1 repetição entre veículos (0,35) · S2 magnitude factual (0,25) · S3 janela temporal acionável (0,25) · S4 fonte primária (0,15); limiar 55/100.

### Anti-exemplos permanentes
- "Rafael Mendes": aprovado inventado (nome + história + foto). Sem aprovado real com permissão, não fazer estrutura D.
- "60 mil vezes mais rápido": estatística apócrifa sem paper rastreável → formulação qualitativa.
- "01/01/2027": data de posse inventada (real: 05–06/01/2027). Data inventada é pior que ausente.
- "July 17" em ícone de calendário: formato americano numa marca brasileira. Revisar visualmente; datas por extenso.
- Premissa refutável ("lei seca é errada"): o nicho defende lei seca → reformular para "Lei seca sem método é tempo perdido".
- "Você não é burro": motivação que planta a dúvida que tenta remover. Banir frases que afirmam atributos pessoais.
- Repetir estrutura em sequência; duplicar publicação (reembalar, nunca repetir).

### Lições técnicas de render
- `document.fonts.check()` retorna `True` enganosamente com fallback do sistema; esperar `fonts.status === 'loaded'` (≥3 fontes) + 400ms.
- Playwright (`device_scale_factor=2`) para carrosséis; fallback `wkhtmltoimage --quiet --enable-local-file-access --width 1080 --height 1920` para Stories/Reels.
- Emoji não renderiza no pipeline → SVG próprio (bola, coração).
- QA de overflow e simetria por medição de pixels (centros validados em 540px) é etapa padrão.
- Inpaint raster para remover texto de arte da Manus falhou em 4 passadas → reconstruir em HTML.
- Template + JSON (`build-reel.py`) reduziu o handoff de 4,3 mil para 2,3 mil caracteres; o custo de produção deixou de ser o HTML e passou a ser a **entrada** (páginas candidatas do PDF, descrição) — trabalho de Cabeção e Jacaré.

---

## 7. Skills, prompts e ferramentas

### Skills (instaladas na conta Claude)
- **`mapaspro-carrossel`** — 4 fases: Radar (web search em 6 veículos + scorer) → Roteiro (8 etapas, Fase 0, Etapa 4A) → Validator → Visual (HTML → PNG). Contém P1–P6, frases banidas, estruturas A–F, padrão visual v3.2, lições, checklist de 27 itens, assets (fontes base64, logos sem slogan), `render-carrossel.py` com contagem automática de slides.
- **`mapaspro-stories`** — 9 tipos de story, stickers nativos (operador adiciona), zonas seguras, sequências temáticas, selos RADAR/COPA/datas, seção "Sequência derivada", QA por pixel. `gerar-stories.py` / `render-stories.py`.
- **`mapaspro-reels`** (criada 05/08/2026 a partir do prompt-mestre v1.0) — 7 fases (Fase 0 verificação → formato → 5 ganchos rankeados → roteiro timecodado → produção visual dos cards 1080×1920 → derivação → kit e medição), 6 formatos (PEGADINHAS / VERSUS / X ERROS / VIRADA / R2-MATERIAL / PROVA SOCIAL **bloqueado**), regras invioláveis, 11 gates, regra de aprendizado contínuo (vencer 2× = prioridade; falhar 2× = sai). Reels em "nível 2 de automação": roteiro + cards + montagem assistida (Manus/Higgsfield para TTS, animação e montagem); R2 exige o PDF original do produto fornecido por Felipe — IA nunca renderiza conteúdo legível de produto.
- Skill coordenadora `mapaspro-editorial`: adiada.

### Prompts e bancos vivos
- `prompts-engenharia-reversa-mapaspro-v1.md` — 8 prompts adaptados (P1 por que performou · P2 fórmula de gancho · P3 estrutura narrativa · P4 gatilhos · P5 retenção de Reel · P6 voz e estilo · P7 legenda e CTA · P8 auditoria comparativa) com bloco de contexto fixo e matriz de prontidão; P2 e P8 bloqueados até existir banco de benchmarks; P6 é prioridade.
- `prompt-operacional-analise-publico-mapaspro-v1.md` — chat dedicado de análise de público com 5 eixos (vocabulário/voz do cliente, dores e objeções, sinais de vertical, sinais de intenção comercial, estágio de preparação); dados entram em lotes mistos, anonimizados; a cada 3 lotes, propor recalibração do P6.
- `banco-voz-publico.md` — banco vivo de voz do público (alimenta o P6).
- `banco-vivencias-fundador.md` — captura da voz do fundador; só 1 de 7 blocos capturado ("por onde começar"); pendentes: rotina, método, matéria, navegação do edital, psicologia, tática de prova.
- `guia-atribuicao-hotmart.md` — guia de implementação da atribuição.
- Prompt de inteligência competitiva v2 (set/2026): passo 0 obrigatório de verificação de handles; dois níveis (concorrentes diretos de produto × grandes players de referência); metodologia de outlier (≥3× mediana); filtros faceless e anti-estimativa. Handles verificados: concorrente direto **@mapasdalulu**; grande player **@alfaconcursos**; descoberto **@mapasdajeh** (~128 mil). Dois handles alucinados pela Manus foram descartados.

### Planilhas e dados
- `mapaspro-mensuracao.xlsx` — abas Registro (uma linha por peça; taxas calculadas), Análise por estrutura, Como usar (taxas, não absolutos; baseline = o próprio perfil orgânico; posts turbinados ficam fora do baseline). Contém os 4 posts impulsionados de 2025. Rotina de registro proposta: D+1 (observação) · D+7 (decisão) · D+30 (perene ou não).
- Planilha-checkpoint 90 dias (01/07–08/09/2026, 42 posts).
- Banco de 238 itens Cebraspe de Direito Penal (set/2026) classificados por tópico do edital PC-AL, cobertura do resumo e potencial de Reel, com fila de 30 roteiros.

### Plataformas
- **Hotmart:** exports CSV com `;`, UTF-8-sig, decimal com vírgula; contêm CPF/telefone/endereço → **só agregados** entram em relatórios (LGPD). Dashboard de Origem de Vendas (abas UTM/SCK). Taxa média 13,4% (20% nos itens de R$ 9,90).
- **Meta Business Suite / Instagram:** agendador nativo; dados de sticker só manualmente no app; **Insights em UTC** — corrigir para BRT antes de agir (18h BRT = 21h UTC; esse erro quase mudou o horário de postagem).
- **Google Ads:** usado pela agência em 2025, sem conversão de venda configurada.
- **Manus AI / Higgsfield MCP:** render visual e montagem de vídeo. Conectores disponíveis para teste de Reels: HyperFrames (HeyGen), Descript. Protocolo de teste de ferramenta de vídeo (mesmo roteiro em 2–3 finalistas) **não executado**.
- Ferramentas avaliadas e **não recomendadas agora:** CRM pago, suítes de automação, ferramentas adicionais de IA para vídeo. Sequência obrigatória: atribuição → base própria → CTA → tráfego.

---

## 8. Público (triangulado — relatório de 09/09/2026)

- FATO (Insights, 09/06/2026): seguidores 17.528; pico 35–44 anos (35,9%); 88% entre 25–54; 52% homens; nacional e disperso (RJ 4,6%, SP 4,2%, Fortaleza 4%, Salvador 2%, Manaus 1,9%); melhor horário ~18h (janela 9h–21h).
- Três públicos que **divergem**: seguidores (base herdada, parte fantasma), engajadores (núcleo que salva) e compradores (Hotmart).
- **Comprador** (FATO, Hotmart): concurseiro-trabalhador de 25 a 54 anos (núcleo 35–44, mas 25–34 e 45–54 relevantes), gêneros em igual medida, renda apertada (recusas de cartão), pouco tempo. Engaja 18h–21h, **compra de manhã** (pico 10h; segunda-feira é o dia nº 1; 30,6% das compras entre 6h–11h; 18h–20h = 24,3%), via **Pix à vista** (56%), começando por **resumo de R$ 9,90 de matéria transversal** (LGPD lidera com ~20 vendas; depois 8.112, Licitações, LAI) antes de confiar em combo de órgão. Eixo RJ–SP com periferia metropolitana (parte é efeito de catálogo). **Idade do comprador: SEM DADO** (Hotmart não exporta).
- Temas a que o núcleo orgânico responde: Direito Penal/Processo Penal, Direito Constitucional, técnica de banca, legislação transversal, Informática, atualidade jurídica traduzida em prova. Rotina/motivação é tempero, não prato.
- Vocabulário real (100 termos de busca do Google Ads 2025): "simulado", "apostila", "pdf grátis", "lei seca", "o que cai na prova". Mapa espontâneo de concorrentes: Mapas da Lulu, Estratégia Concursos, NEAF, Nova, Brabo.
- Quem comenta ≠ quem compra; volume de lote não vira estatística de demanda; bases pequenas dão tendência, não segmentação fina.
- INSS: interesse de público alto, vendas ≈ 0 (0,5%) — serve a alcance/autoridade, não a conversão.

---

## 9. Dados comerciais e financeiros

### Vendas Hotmart (ago/2024–jun/2026)
- FATO: 156 transações completas (outra leitura em set/2026 citou 172 transações pagas — recorte/export diferente [A CONFIRMAR]). 2024: 9 · 2025: 82 · 2026 até jun: 65.
- FATO: R$ 7.487,54 brutos; R$ 6.480,68 líquidos; ticket mediano R$ 29,90; 24% das vendas a R$ 9,90; itens ≤ R$ 10 = 34% das transações e ~6% da receita.
- FATO: combos = 42 vendas = 61% da receita; 6 combos (BB, PF ×2, TJ-SP, IBGE, TJ-RJ) = 57% da receita; Combo BB (R$ 289,90) = 15% de tudo com 4 vendas.
- FATO: verticais — BB 24,2% · PF 20,6% · IBGE 12,1% · TJ-SP 12,0% · TJ-RJ 11,6% (≈ 80%); INSS 0,5%.
- FATO: 124 compradores únicos; 16 (13%) recompraram e respondem por 31% das transações — recompra acontece sem ninguém pedir.
- FATO: melhor mês nov/2025 (30 vendas, R$ 1.443); nov/25–jan/26 = 70 vendas = 42,7% da receita histórica; somando nov–jan de todos os anos = 49%; jan–jun/2026 (65 vendas, R$ 2.846) **dobrou** vs jan–jun/2025 (17 vendas, R$ 1.410); jun/2026 = 4 vendas / R$ 39,60; jul parcial R$ 44. INFERÊNCIA: a queda recente pode ser vale sazonal (set/2025 = R$ 18), não colapso — sem o export jul–set não dá para distinguir.
- FATO: ~50 produtos com venda, média 3 vendas/produto; 32 produtos com 1–2 vendas.
- FATO: Pix 56% · cartão 40% · conta Hotmart 5 · boleto 2.
- Lacunas sem produto: Receita Federal, AGU, Bacen, CGU, ANPD.

### Fluxo de caixa (Creator Cockpit, jul/2024–jul/2026)
- Entradas ≈ R$ 6.898 em 25 meses (média ≈ R$ 275/mês); saídas ≈ R$ 6.976. **SEM DADO** sobre o que são as saídas (saques ou despesas). **Custos (Perplexity, Claude, agência, videomaker, domínio, turbinados) não consolidados → hoje não é possível dizer se a MapasPro dá lucro ou prejuízo.**

### Campanha paga de 2025 (agência, Google Ads, out–dez/2025)
- FATO: investimento conhecido ≥ R$ 2.229,06; 14 exports analisados; sem conversão de venda configurada.
- FATO: ROAS-teto (100% das vendas na janela atribuídas, hipótese impossível) 0,84 bruto / 0,74 líquido. Fase de search TJ-SP quase empatou no teto (0,94); fase B display/tráfego: 4.021 cliques e efetivamente 1 venda relevante (R$ 19,90).
- FATO (planilha): posts impulsionados — Reel "Prova TJ-SP chegando": 144.220 alcance, 3.560 cliques, 1 save, 0 visitas; post Português FGV: 1.432 cliques (produto vendeu 2× na vida); vídeo com os sócios (BB): único com conexão real (182 visitas ao perfil). Engajamento dos impulsionados: 0,15%–1,97%.
- INFERÊNCIA central (30/09): o gargalo é **pós-clique** (página, preço, confiança, fit com o edital, checkout mobile), não alcance — algo perde >99% entre o clique e o Pix.

### Instagram orgânico como motor de receita
- INFERÊNCIA com aritmética explícita: ~12 posts/mês × ~100 de alcance = ~1.200 contas/mês; mesmo com 3% de clique e 5% de conversão (hipóteses generosas) a ticket R$ 30 → ~2 vendas/mês. No tamanho atual, o Instagram é ativo de credibilidade (vitrine conferida antes de dar o cartão), não motor de receita.

---

## 10. Instagram — diagnóstico e evolução

### Fase 0 do perfil (09/06/2026)
- 17.528 seguidores; últimos 90 dias: 635 visualizações, 154 contas alcançadas, 39 interações, saldo −310 seguidores; 89,5% das interações de não-seguidores. Diagnóstico: perfil "em coma", base inflada por tráfego pago.
- IBGE descartado como porta de entrada evergreen (post antigo: 0 saves/0 shares/1 visita); aceito só como RADAR/serviço. Em jul/2026 os sócios decidiram **manter IBGE ativo** no site e elegível para RADAR e CTA de serviço.

### Stories (11/06–03/07/2026, Business Suite)
- 28 Stories em 8 dias; 1.092 views, 838 alcance; engajamento médio 3,22%; retenção 88,6%; drop-off 20–30% em sequências de 3–4, 50% em sequência de 7. Quinta e segunda com melhor alcance; sexta pior. Views de abertura caíram de 117 (11/06) para ~24 em julho.

### Reativação (jul–set/2026) — análise de 90 dias (01/07–08/09, 42 posts)
- FATO: reativação estatisticamente confirmada (mediana de interação dos últimos 30 dias mais que dobrou). Seguidores ~18.456 (08/09). Mediana de alcance 98–99/post; interação 6,67%; ~2 visualizações por conta alcançada (comportamento "flashcard").
- FATO: **carrossel é o motor** — 7,64% de interação ponderada vs 1,83% dos Reels (4,17×); quase todos os saves/shares; melhor alcance médio (105 vs 78 dos vídeos). Retenção dos Reels: ~11s em vídeos de 32s.
- FATO: mix invertido — Rotina/Motivação = 40% do volume (17/42) com o pior alcance médio (77); Direito Constitucional 163, Penal 112. Recorde dos 90 dias: "Quem julga um ministro do STF?" (390 de alcance, 06/09). Informática (1 post, "todo malware é vírus?"): 23,5% de interação e recorde de 7 shares — hipótese (n=1), validar com série de 4.
- FATO: deserto de comentários — 11/42 posts comentados; 32 comentários em 90 dias, mediana zero. CTA de alternativa/palavra única é a aposta.
- FATO: zero menção a TJ-RJ, IBGE ou BB em 90 dias de legendas (~50% da receita histórica).
- FATO: 10/42 posts duplicados (manual + agendador). Correção: agendador como fonte única.
- FATO: turbinado sistemático em quase todos os posts do período, contrariando a regra escrita; entrega demográfica fora do perfil comprador (forte 18–24) em vários.
- Metas Q3 por peça (D+7): alcance ≥114; interação/alcance ≥10,52%; save/alcance ≥3,73%; share/alcance ≥1,58%. Ciclo proposto de 8 Reels em 4 semanas (8–15s, uma ideia, hipótese explícita; meta interação ≥3,0% vs 1,82% atual). Nunca republicar slides como vídeo.

### Decisão "manter ou reiniciar a conta" (ago/2026)
- Decisão: **manter**. Evidência: engajamento por alcance saudável (5,6% média, 9,6% carrosséis, 17,2% no melhor) — base não é tóxica; o teto quebra (179 no melhor carrossel do mês; 1.187–1.194 no melhor Reel histórico — discrepância registrada); o gargalo é conteúdo/retenção, que viaja com qualquer conta; 17 mil seguidores validam uma marca faceless na vitrine. Critério pré-registrado para reabrir a questão: % de não-seguidores ~zero + base majoritariamente falsa na auditoria + nenhum post >200 de alcance. Meio-termo: collabs com criadores do nicho.
- Distribuição carrossel × Reel: o "gate de validação por seguidores" é simplificação útil, não mecânica oficial; conferir split seguidores/não-seguidores nos Insights.

---

## 11. Sistema de níveis comerciais e regra de mídia paga

| Nível | O que libera | Condição |
|---|---|---|
| **0** (vigente no papel) | Bio com link do Combo Pacote Básico; zero CTA comercial, sem preço, sem link nas peças; CTAs só de save/share/comentário de 1 palavra | — |
| **1** | CTA de serviço no RADAR com prazo real (máx. 1/semana); sempre para página de produto, nunca checkout direto; Fase 0 comercial (preço/link conferidos no dia) | Atribuição implementada e testada (SCK por canal, UTM, cupom exclusivo, Pixel/API de Conversões, compra-teste ponta a ponta no mobile) **e** gatilho de alcance: Stories sentinela 50–70 views ou Reel >500 |
| **2** | Produto como conteúdo (trecho real do resumo; arquivo original fornecido por Felipe) | — |
| **3** | Campanhas pagas | 5 pré-condições: conversão de compra Hotmart configurada no Meta; Search só exato/frase; gatilho de edital de vertical provada; CPC compatível com o ticket; experiência mobile impecável |

- Escada de CTA por formato (jul/2026): Reels só CTA suave; carrosséis podem levar link de baixo atrito (R$ 9,90) quando o nível permitir; Stories são o único formato para venda explícita.
- Atribuição: SCK no checkout (ex.: `?sck=site-combo-ibge`, máx. 30 chars); UTM no site (bio `utm_medium=bio`; sticker RADAR `utm_medium=story&utm_campaign=radar-[vertical]-[data]`); cupom exclusivo (ex.: RADAR10) como fallback. **Felipe declarou a atribuição ativa em set/2026.**
- FATO: o card 8 com página real do produto (Reels dos combos) já é Nível 2 pela régua — o nível vigente no papel não descreve mais o que está no ar. Pendente: formalizar o nível com medição.
- **Mídia paga:** regra original = zero até Nível 3; proibida para venda direta. A reativação de jul–set usou turbinado sistemático. Regra atual: qualquer uso de pago exige decisão registrada dos sócios, orçamento como custo de aprendizado com critério de parada escrito **antes do primeiro real**, público 25–54, só em conteúdo validado organicamente, nunca sem atribuição funcionando. Estrutura decidida quando o Nível 3 abrir: **uma** campanha de conversão com público amplo 25–54 usando breakdown nativo da Meta (não cinco campanhas por faixa etária). Gerenciador de Anúncios, nunca o botão Turbinar.
- Recomendação em aberto (29/09): abrir o Nível 1 **por data** (até 15/10/2026, ligado ao edital IBGE), não por sentinela — o gate foi calibrado para um cenário sem atribuição que não existe mais, e cada semana de Nível 0 dentro da estação é a receita mais cara que a empresa deixa na mesa.

---

## 12. Catálogo e qualidade do produto

- FATO (ago/2026): 145 entradas / 138 produtos únicos em 3 vitrines (Órgão/Edital com 32 subcategorias, Combos, Disciplina Isolada); preços R$ 9,90–R$ 289,90; 100% do catálogo permanentemente em "Oferta!"; espinha dorsal Português/Redação e Informática.
- FATO: bug de checkout — Combo BB (R$ 289,90) e Combo INSS (R$ 129,90) compartilhavam o código `S100847229D`; **resolvido pelos fundadores** (confirmado jul/2026). Inconsistências de preço em Português (21 páginas, dois preços para um checkout) e Contabilidade; link de afiliado fora do padrão para Polícia Penal MG.
- FATO: combo IBGE rotulado "FGV" enquanto os editais ativos usam IBFC e Avalia → corrigir antes de qualquer CTA/campanha.
- **Combo Carreira Administrativa** (site): 211 resumos, 10 disciplinas, 5.464 páginas (Adm. Geral/Pública, AFO, CASP, Controle, D. Administrativo, D. Constitucional, Informática, Português, RLM, Redação Oficial; Cebraspe/FGV/Vunesp). **Combo Carreira Policial**: 233 resumos, 10 disciplinas, 5.620 páginas (Português, RLM, Informática, Direitos Humanos, Ética, D. Constitucional, D. Administrativo, D. Penal, Processo Penal, Legislação Penal Especial). Páginas não nomeiam concursos-alvo.
- **Achado grave (set/2026):** quatro de seis páginas amostradas do Combo Administrativo tinham defeito — erro de conteúdo em probabilidade (2/5 onde deveria ser 2/4), texto de IA corrompido em Lei 14.133 ("Logalidade", "O oto administrativo"), Redação Oficial ("Respertosamente", contagem que não fecha), "controle intemo". INFERÊNCIA: a Fase 0 protege o Instagram e **não protege o produto**. Consequência: não se impulsiona o Combo Administrativo até correção; o **Combo Policial passou limpo** e vai primeiro.
- **Auditoria dos resumos de Penal (set/2026):** pena do art. 316 (concussão) desatualizada (Lei 13.964/2019 elevou de 2–8 para 2–12 anos); art. 312, §3º ausente; PDF "Crimes contra a Administração Pública" corrigido diretamente (v2, 6 páginas, fontes Noto Sans preservadas). Banco de 238 itens Cebraspe mostrou 51 itens do edital respondidos errado pelos resumos e 38 não respondidos; a banca cobra com insistência arts. 6º, 8º, 10, 121-A e 147-A do CP, ausentes dos quatro resumos (inserções de meia página cada).
- [A CONFIRMAR] desde ago/2026: o resumo de LGPD lista 6 sanções (art. 52); a Lei 13.853/2019 teria elevado a 9 — Felipe confere no Planalto.
- Processo de revisão como é (FATO): Jacaré gera com Perplexity e revisa com fonte primária; Felipe revisa em última instância. INFERÊNCIA: auto-revisão sem trilha. Proposta: registro por resumo (fonte primária, versão da norma, data, revisor, data da última alteração da norma).
- Plano de 90 dias de ago/2026 (PDF estratégico) propõe +6 combos e 3 disciplinas novas; recomendação vigente: **congelar expansão de catálogo** até o fim da estação, salvo correção de fit e material pronto. Esse PDF continha erros (declarava produtos de BB como ausentes quando existem; PF com edital aberto não confirmado; era endereçado a "Ricardo"; citava skill inexistente).
- Material bônus: mapas Buzan de "Fundamentos de Macroeconomia" (5 pilares) produzidos em HTML/SVG como bônus separado do produto principal (ago/2026). Pendente: se a regra de imagens de IA se estende a bônus.

---

## 13. Linha do tempo das decisões (mai → set/2026)

| Data | Evento / decisão |
|---|---|
| out–dez/2025 | Agência + tráfego pago (Google Ads); ROAS-teto 0,84; quase fecham |
| jan/2026 | Perfil para de postar e adormece |
| mai/2026 (08–28/05) | Construção do sistema editorial: framework A–F, P1–P6, Etapa 4A, Validator, radar-scorer; 6 carrosséis produzidos (Calendário Eleitoral, BB, INSS, Lei Seca, Cebraspe×FGV, Constância) |
| 01–09/06 | Skill `mapaspro-carrossel` e `mapaspro-stories` empacotadas; Insights revelam perfil em coma; plano de reativação de 14 dias (faceless, zero venda, zero pago); IBGE descartado como evergreen; documento-mestre |
| 11–12/06 | Primeiros Stories em produção real: RADAR #1 (IBGE/INSS/PRF), deep-dive IBGE, Stories do Edital IBGE 01/2026 (6 quadros, verificados no PDF do IBFC) |
| jun/2026 | Copa do Concurseiro (reativos com placares verificados), Dia dos Namorados, SEDES-DF deep-dive; regras permanentes: sem contador, sem fonte no visual; Reel #1 em nível 2 |
| 30/06–06/07 | Calendário de julho; apresentação institucional (17 slides); produção diária (Dia D das autorizações: AGU 170, Receita 146, Bacen 170, CGU 60, ANPD 50 = 596 vagas; INSS fora; IBGE 01 prorrogado para 09/07); 5 relatórios consolidados; decisão: Reels = "roteiro + montagem assistida com ferramenta conectada" |
| 07–08/07 | Slate de 4 formatos de Reel (R1 método, R2 trecho real, R3 RADAR, R4 Copa); escada de CTA por formato; checkout BB×INSS confirmado resolvido; IBGE mantido ativo; estrutura de chats (produção semanal + estratégia + descartáveis) |
| 08–20/07 | Produção diária: crimes contra a honra, LGPD "quem decide não é quem executa", Reels de método, Dia do Amigo; análise Hotmart 24 meses |
| 22–28/07 | Regras de copy/visual v3.x; regra de derivação F1/F2/F3 (27/07); cross-post Facebook OFF; posts fixos 18h seg/qua/sex; instrução permanente: Claude sinaliza proativamente gatilhos de pago; captura da voz do fundador (bloco 1) |
| 01–03/08 | Análise completa do catálogo (138 produtos; bug de checkout; IBGE 1 produto) |
| 05/08 | Skills atualizadas; `mapaspro-reels` criada; pilha de exemplos permanente; hashtags = 5; **pivot: só resumos esquematizados**; vivência do fundador vetada no feed; retomada v1.3 |
| 05–18/08 | 18 carrosséis agendados para 05/08–14/09 (viagem 22/08–06/09); decisão **manter a conta** vs reiniciar; peça extra "régua dos editais"; prompt para Manus da campanha PC-AL (29 peças); retomada v1.4; Lei 15.358/2026 descoberta na Fase 0 |
| 07/08 | Kit de engenharia reversa (8 prompts); mapas Buzan de macroeconomia; fluxo Claude↔Manus formalizado |
| 23/08–05/09 | Viagem de Felipe (Argentina); feed 100% agendado |
| 07–09/09 | Análise de 90 dias (duplicações; mix invertido; carrossel 4×; teste do print); relatório de público-alvo (09/09); briefing de provas; PDF do perfil do comprador |
| 11/09 | Instruções permanentes v2 (resumos esquematizados; disciplina de dado; pago exige decisão registrada) |
| set/2026 (até 28/09) | Chat de análise de público (5 eixos; 3 lotes de Insights; turbinado sistemático flagrado); atribuição declarada ativa; frente Polícia Civil 06/12 (PC-BA, PC-MA, PC-AL, PC-AP) com 10 Reels planejados; avatares Renata/Rodrigo; Reels dos combos ADM/POLICIAL; Felipe dispensa Stories derivados nos kits |
| 29/09 | Estrutura societária corrigida (Cabeção, Jacaré; Lorran não é sócio); relatório de processos e governança; sprint de atribuição/funil; achado dos erros no Combo Administrativo; série "A Cebraspe perguntou. Tá no resumo." (5 cards R2, CTA "Comenta POLÍCIA"); PDF de Penal corrigido; banco de 238 itens; **decisão de focar exclusivamente em Alagoas** na frente PC (não nos quatro estados) com plano de pago em 3 fases |
| 30/09 | Diagnóstico financeiro: custos SEM DADO; reprecificar entrada; consolidar catálogo; critério de saída da estação nov–jan |

---

## 14. Frentes e campanhas ativas (estado em 29–30/09/2026)

### Frente Polícia Civil — prova 06/12/2026
- Contexto: quatro Polícias Civis com prova objetiva em 06/12/2026 (PC-BA, PC-MA, PC-AL, PC-AP; Cebraspe; Informática é a maior disciplina isolada do cluster). Abordagem definida por Felipe: **um Reel por tópico** que cai nos editais, com versão por estado (mesma matéria, selo/estado trocado) — "na cabeça de quem faz a PC-BA, não interessa a PC-AP". Prioridade às disciplinas específicas da carreira policial.
- FATO (Fase 0 de 29/09): PC-AL — Edital nº 1 de 03/07/2026 (SEPLAG/AL), Cebraspe, 150 vagas + 150 CR (Agente e Escrivão), nível superior, R$ 5.318,63, provas em 06/12 em Arapiraca e Maceió, 50 itens básicos + 70 específicos em Certo/Errado, inscrições encerradas em 11/09. Concurso anterior: 43.073 inscritos.
- **Decisão mais recente registrada (29/09, chat PC-AL):** focar **exclusivamente em Alagoas**. A memória do projeto ainda descreve a frente como quatro estados — [A CONFIRMAR] qual decisão vale.
- Série "A Cebraspe perguntou. Tá no resumo." — formato fixo de 5 cards (R2-MATERIAL com história): item real da Cebraspe + página do resumo; CTA "Comenta POLÍCIA"; sem preço, sem link no criativo. Card 5 em 4 variantes de UF. Fila de 30 roteiros em 3 blocos (9 prontos sem dependência); recomendação de priorizar itens com selo local/recente (CGE-AL 2026, POLC-AL 2023, PC-AL 2012/2021).
- Plano de pago em 3 fases (68 dias), proposto, não executado: **Teste** (até ~13/10): 3 Reels, R$ 20/dia cada por 7 dias (~R$ 420), objetivo engajamento/visualização, Alagoas, 22–50 anos, público amplo, Reels+Stories+Feed; corte escrito antes (pior sai no dia 4, melhor dobra). **Escala com retargeting** (out–nov): vencedor + 1 Reel novo/semana, R$ 30–50/dia; retargeting AL (≥50% assistido ou visita ao perfil) com CTA para a página PC-AL do site (existe, precisa atualização) com UTM/SCK. **Reta final** (nov–dez). Pré-condições: evento de compra Hotmart no Meta, UTM/SCK por criativo, página testada no mobile, teto total escrito. Produto a montar: "Reta Final PC-AL" + mini de legislação institucional da PC-AL (única lacuna que só material estadual entrega).
- INFERÊNCIA registrada: a regra "validar organicamente antes de pagar" **não se aplica na forma original** à PC-AL — a base orgânica é nacional e não vai fazer essa prova; a validação precisa ocorrer dentro do pago, com testes pequenos e regras de corte.

### IBGE Recenseador
- Projeção de 27.000+ vagas; edital esperado out/2026; cai na estação nov–jan. Alvo comercial primário quando o Nível 3 abrir; candidato à primeira CTA rastreada (Nível 1). Pré-condição: corrigir rótulo FGV → IBFC/Avalia.

### Reels dos combos (peças permanentes)
- Combo Carreira Administrativa e Combo Carreira Policial: Reels sem vínculo a concurso, CTA de uma palavra ("Comenta ADM" / "Comenta POLICIAL") para medir demanda. Peças de 25/09 e 27/09 com 53 e 35 de alcance em 3 dias. Ajuste: régua de demanda passa a ser **clique rastreado na página do combo** (UTM por peça); comentário vira sinal secundário; "vencer duas vezes" precisa de número escrito (proposto ≥100 alcance e ≥1 save em D+7).

### Outras frentes
- Série "Estudar com IA": enquete-coletor em Stories → carrossel "prompts de IA para concurseiro" (calibrado para C/E Cebraspe; IA como aliada; card sobre alucinação com material verificado como insumo).
- LGPD (19–20 vendas, evergreen): principal candidato a Reel R2.
- Peça "qualidade de segurado" (Previdenciário) em reserva até o INSS avançar na régua.
- Deep-dive Lei 15.358/2026 (8 leis penais alteradas): pauta forte pendente.
- Pauta pendente de validação: série de 4 carrosséis de Informática ("todo X é Y?").
- Estratégia de DM (jul/2026): abordagem valor-primeiro, nunca vender na primeira mensagem.
- Reativação dos 124/156 compradores por vertical na abertura de editais — condicionada à verificação da base legal LGPD para contato pós-compra via Hotmart.
- Captura de contato (WhatsApp/e-mail) em troca de resumo transversal gratuito — base própria antes de comprar tráfego.

---

## 15. Estratégia vigente e planos de 30 dias

### Diagnóstico em uma frase (30/09)
INFERÊNCIA: sistema editorial caro e maduro + catálogo pulverizado + canal único e alugado + custos não contabilizados + nenhum processo de venda — e a estação que faz ~43% da receita começa em 30 dias.

### Onde o valor vaza (29/09)
1. O sistema de gates protegeu contra o erro da agência, mas agora trava o aprendizado (Nível 0 durante a estação é o custo mais alto possível).
2. Audiência sem propriedade (tudo dentro do Instagram).
3. Produto novo antes de venda validada (5 verticais já fazem 80%).
4. Conversão sem dono.

### Recomendações estratégicas em ordem (29/09)
1. Definir meta de receita da estação nov/2026–jan/2027 e montar o funil de trás para frente (meta → ticket → vendas → conversão de página → visitas rastreadas/semana). Exemplo ilustrativo, não previsão: R$ 5.000 ÷ R$ 100 ≈ 50 combos em 12 semanas ≈ 4/semana; a 1% de conversão ≈ 400 cliques rastreados/semana.
2. Abrir o Nível 1 por data (15/10, IBGE), com regra de parada escrita.
3. Construir base própria antes de comprar tráfego.
4. Reativar compradores com upgrade para o combo da vertical (após LGPD).
5. Congelar expansão de catálogo.
6. Reduzir custo por peça; um gate só para a produção com Claude e a produção própria de Cabeção.

### Alavancas financeiras (30/09, por retorno/esforço)
- Semana 1, custo zero: fechar o custo real (DRE simples); zero turbinado até o Pixel funcionar; export Hotmart jul–set.
- Estação: meta de trás para frente; focar nas 5 verticais + PC 06/12; Nível 1 por data; corrigir fit produto×banca.
- Ticket: reprecificar entrada (R$ 9,90 → R$ 14,90–19,90 avulso ou kit transversal LGPD+LAI+8.112+Licitações+Improbidade a R$ 29,90–39,90); order bump/upsell no checkout [A CONFIRMAR na Hotmart]; consolidar catálogo (~50 → combos das 5 verticais + transversais).
- Receita mais barata: reativar compradores; captura de contato.
- Depois: vender combos pelo site com Pix para reduzir taxa — só acima de ~R$ 2–3 mil/mês.
- **Não fazer:** tráfego para venda direta antes de Pixel + conversão medida; reposicionar para assinatura agora (público compra por edital, à vista); expandir catálogo; gastar hora de sócio em ferramenta antes de existir processo de venda.

### Critério de saída da estação (a ratificar)
- Referência: nov/25–jan/26 = R$ 3.198 brutos, sem atribuição, com mídia que não deu lucro.
- Sinal positivo: nov/26–jan/27 supera a referência com custo total conhecido, atribuição ligada e lucro líquido positivo após ferramentas.
- Sinal negativo: não supera mesmo com Nível 1 aberto, reativação feita e fit corrigido → o limitante é distribuição; o tempo de Felipe rende mais em outra frente; MapasPro em modo manutenção.

### Plano de 30 dias consolidado (29–30/09)
| Prazo | Ação | Dono |
|---|---|---|
| até 06/10 | 1ª reunião da mesa: meta da estação, data do Nível 1, donos por processo | Felipe convoca |
| até 06/10 | Planilha de custos reais desde jan/2026 + definição das "saídas" do Cockpit; export Hotmart jul–set | Felipe / Cabeção |
| até 06/10 | Congelar turbinados até Pixel ativo (decisão registrada) | Mesa |
| até 13/10 | Auditoria de fit produto×banca do combo IBGE; reprecificar entrada; kit transversal; verificar order bump; lista de produtos a despublicar/agrupar; verificar base legal LGPD; iniciar registro de revisão por resumo | Cabeção / Felipe / Jacaré |
| até 20/10 | Primeira CTA rastreada (Nível 1, IBGE) com regra de parada; captura de contato ativa; meta + critério de saída ratificados | Cabeção / Mesa |
| até 27/10 | 2ª reunião: ler os três números da primeira CTA | Mesa |
| nov | Disparo de reativação dos compradores por vertical | Cabeção |

---

## 16. Pendências e itens [A CONFIRMAR] (consolidado)

**Operacionais / dados**
- Export Hotmart jul–set/2026 (SEM DADO).
- Custos da empresa e significado das "saídas" do Creator Cockpit (SEM DADO).
- Receita fora da Hotmart (site WooCommerce) [A CONFIRMAR].
- Pixel da Meta / API de Conversões no checkout Hotmart configurado? (SEM DADO).
- Se os carrosséis produzidos por Cabeção passam pelo validator/Fase 0 [A CONFIRMAR].
- Preencher a planilha com 5–9 posts orgânicos para baseline; registrar por Reel o tópico do edital e a origem do item (UF/ano).
- Discrepância 1.187 vs 1.194 no alcance do melhor Reel histórico.
- 156 vs 172 transações (recortes diferentes de export).

**Produto / jurídico**
- Corrigir rótulo FGV do combo IBGE.
- Corrigir as 4 páginas defeituosas do Combo Administrativo e auditar por amostragem estratificada.
- Inserir arts. 6º, 8º, 10, 121-A, 147-A nos resumos de Penal; revisar os 51 itens respondidos errado.
- Conferir art. 52 da LGPD (6 ou 9 sanções).
- Registro de fonte primária por resumo [A CONFIRMAR se existe].
- Base legal LGPD para contato pós-compra [A CONFIRMAR].
- Atualizar bio/site/páginas que ainda dizem "mapas mentais".
- Decidir se a regra de imagens de IA se estende a bônus (mapas Buzan).
- Papel de Ricardo [A CONFIRMAR].
- Permissão da Daniela Turati (destrava estrutura D).

**Estratégia / governança**
- Meta de receita da estação (SEM DADO em qualquer documento).
- Data de abertura do Nível 1 (proposta 15/10).
- Formalizar o nível comercial vigente com medição (card 8 já é Nível 2).
- Frente PC: quatro estados ou só Alagoas? (duas decisões registradas em set/2026; a mais recente é Alagoas).
- Reunião quinzenal da mesa diretora (proposta, não instituída).
- "Regra 80/20" citada numa estrutura de relatório: nunca localizada em fonte [A CONFIRMAR se existe].

**Produção**
- Captura da voz do fundador: 6 de 7 blocos pendentes.
- Teste A/B triplo de Stories (Radar × deep-dive × Copa) com prints reais — placeholder de priorização ainda aberto.
- Protocolo de teste das ferramentas de vídeo (mesmo roteiro em 2–3 finalistas).
- Série de 4 carrosséis de Informática para validar a veia.
- Ciclo de 8 Reels em 4 semanas com hipótese explícita.
- Deep-dive Lei 15.358/2026.
- Skill coordenadora `mapaspro-editorial` (adiada).

---

## 17. Recomendações de gestão pendentes (lista viva, com data)

| Data | Domínio | Recomendação | Status |
|---|---|---|---|
| 06/07 | Financeira | Organizar dados financeiros (receita, CAC, LTV) como pré-requisito da Fase 3 | pendente |
| 29/09 | Governança | Reunião quinzenal com três números e decisão registrada | pendente |
| 29/09 | Estratégica | Meta numérica da estação + data do Nível 1 | pendente |
| 29/09 | Marketing/CRM | Reativar os compradores como primeiro canal próprio (após LGPD) | pendente |
| 29/09 | Produto/jurídico | Registro de revisão por resumo | pendente |
| 29/09 | Operações | Nomear dono de conversão e atribuição (proposta: Cabeção) | pendente |
| 29/09 | Produto | Auditar o Combo Administrativo antes de qualquer investimento nele | pendente |
| 29/09 | Operações | Ler D+7 das peças de 25/09 e 27/09 antes da 3ª; número escrito para "venceu" | pendente |
| 29/09 | Produto/marketing | Policial primeiro, Administrativo após correção | pendente |
| 29/09 | Financeiro/marketing | Teto total e regras de corte por criativo escritos antes do primeiro real (PC-AL) | pendente |
| 29/09 | Produto | Montar "Reta Final PC-AL" + mini de legislação institucional da PC-AL | pendente |
| 30/09 | Produto/preço | Reprecificar entrada e consolidar catálogo | pendente |
| 30/09 | Financeira | Escrever critério de saída da estação antes de ela começar | pendente |
| 30/09 | Marketing/conversão | Auditar o pós-clique (página, preço, fit) das 5 verticais antes da primeira CTA | pendente |

**Recomendações desta compilação (04/10/2026) — máximo três, só com evidência do projeto:**

1. **Operações/dados — alinhar as instruções do projeto Claude ao que vale hoje.** Evidência (FATO): o bloco de instruções do projeto usado neste chat ainda diz "mapas mentais e resumos esquematizados", "os dois sócios" e trata Lorran como sócio — tudo superado pela v2 (11/09) e pela correção societária de 29/09. Impacto: médio (todo chat novo nasce com premissas erradas que Claude ou o ChatGPT vão repetir). Esforço: mínimo (colar a v2 e a tabela da seção 4). Decisão: nenhuma — é manutenção.
2. **Governança — registrar por escrito a decisão PC quatro estados × só Alagoas.** Evidência (FATO): a memória do projeto e o chat de 29/09 registram decisões opostas no mesmo mês. Impacto: alto (define roteiros, variantes de UF e o orçamento de pago da estação). Esforço: uma linha na próxima reunião da mesa.
3. **Operações/dados — eleger um documento único vivo e aposentar os cinco relatórios de 06/07.** Evidência (FATO): cinco versões do mesmo relatório e duas versões de retomada coexistem no projeto; a compilação precisou reconciliar números divergentes (seguidores, sazonalidade, transações). Impacto: médio (reduz risco de o modelo citar o dado errado). Esforço: baixo — este pacote pode ser o ponto de partida.

---

## 18. Glossário

- **Fase 0** — verificação factual em fonte primária antes de produzir (vale para conteúdo e produto).
- **FATO / INFERÊNCIA / SEM DADO / [A CONFIRMAR]** — marcação obrigatória de toda afirmação analítica.
- **Nível 0/1/2/3** — escada de ativação comercial (ver seção 11).
- **RADAR** — formato de notícia de concurso (AUTORIZAÇÃO / EDITAL / RESULTADO / ATUALIDADE); pode furar a fila.
- **Deep-dive** — RADAR de 5 quadros sobre um único concurso.
- **Copa do Concurseiro** — selo de humor futebol × concurso.
- **F1/F2/F3** — quadros da sequência derivada de Stories (gancho+enquete · clímax · CTA+sticker).
- **R1/R2/R3/R4** — slate de Reels (método · trecho real do produto · RADAR por órgão · Copa).
- **R2-MATERIAL** — Reel com página real do resumo (exige PDF original).
- **Pilha de exemplos / quadro de 3 colunas / chip / eyebrow / stinger** — componentes visuais (seção 5).
- **Teste do print** — tríade selo+headline+bloco deve ter termo literal do assunto.
- **Régua de 4 estágios** — estudo/pedido → autorizado → edital publicado → inscrições abertas.
- **Trilho RADAR → Reta Final** — funil conteúdo → conversão comprovado.
- **Turbinado** — botão "Turbinar" do Instagram (proibido; usar Gerenciador de Anúncios).
- **SCK / UTM** — parâmetros de atribuição Hotmart / site.
- **Sentinela** — Stories de 50–70 views como gatilho do Nível 1.
- **Estação** — nov–jan, período de ~41–49% da receita.
- **Mesa diretora** — Felipe, Cabeção e Jacaré.
- **KPIs** — SAVE (evergreen), CLICK (urgência real), SHARE (identificação), COMMENT (opinião dividida).

---

## 19. Inventário de arquivos do projeto (referência)

| Arquivo | Data | O que é |
|---|---|---|
| `mapaspro-documento-mestre.md` | 09/06 | Fonte de verdade original (diagnóstico, plano de reativação, pendências) — parcialmente superado |
| `instrucoes-permanentes-mapaspro-v2.md` | 11/09 | Instruções vigentes (marca, Fase 0, disciplina de dado, níveis, diretriz de recomendações) |
| `relatorio-consolidado-mapaspro.md` e 4 variantes | 06/07 | Relatórios consolidados do sistema editorial (sobrepostos) |
| `relatorio_stories_mapaspro.md` | 06/07 | Insights de Stories 11/06–03/07 |
| `prompt-mestre-reels-mapaspro-v1.md` | jul/ago | Base da skill de Reels |
| `changelog-skills-mapaspro.md` + adendo 05/08 | 05/08 | O que mudou nas skills; padrões v3.2 |
| `retomada-producao-mapaspro-v1-3.md` (v1.4 existe) | 05/08 | Handoff das 18 peças de ago–set |
| `calendario-viagem-05ago-14set.md` | 05/08 | Calendário com regras do período sem supervisão |
| `prompts-engenharia-reversa-mapaspro-v1.md` | 07/08 | Kit P1–P8 |
| `relatorio-processos-estrategia-mapaspro-2026-09-29.md` | 29/09 | Processos, donos, governança, ferramentas |
| `claude_diagnostico-financeiro-mapaspro-2026-09-30.md` | 30/09 | Diagnóstico financeiro e alavancas |
| `mapaspromensuracao.xlsx` | — | Planilha de medição |
| `sales_history_*.csv` (×3) | 10/07 | Exports Hotmart (contêm dados pessoais — só agregados) |
| `Creator Cockpit ... .csv` | 10/07 | Fluxo de caixa mensal |
| `MapasPro_Relatorio_Estrategico_Concursos_2026.pdf` | ago | Plano de 90 dias de catálogo (com erros apontados) |
| `Analise_Concursos_2026.pdf`, `01__Guia_IA_Marketing...pdf`, `Relatório Ferramentas de IA para Vídeos.pdf` | — | Insumos de pauta/estratégia (podem estar desatualizados) |
| `01_x` / `02_x` .docx | — | Identidade visual, segmentação, micro-nichos, guias de prompt (background) |
| Logos (`Logo_MapasPro_*`, `logo_mapas.png`) | — | Variações da logomarca |
| Memória do projeto: `overview.md`, `production-standards.md`, `tools-and-files.md`, `preferences.md` | set/2026 | Estado vivo (fonte principal das seções 5, 7, 11, 14) |

Arquivos referenciados mas **não presentes** no ambiente: `validator-mapaspro.zip`, `radar-scorer.py`, `plano-reativacao-mapaspro-2-semanas.md`, `calendario-multiformato-30-dias.md`, `guia-decisao-reels-mapaspro.md`, `banco-voz-publico.md`, `banco-vivencias-fundador.md`, `guia-atribuicao-hotmart.md`, `retomada-producao-mapaspro-v1-4.md`, PNGs/zips das peças, banco de 238 itens (.xlsx), PDF v2 de Penal.

---

## 20. Bloco de instrução para colar no ChatGPT

```
Você vai atuar como conselheiro de negócio e operador editorial da MapasPro, usando o pacote de contexto acima como fonte de verdade. Regras:

1. Marque toda afirmação analítica como FATO, INFERÊNCIA, SEM DADO ou [A CONFIRMAR]. Nunca preencha lacuna com valor plausível. Se um número não estiver no pacote, diga que não há dado.
2. Fase 0 é inegociável: antes de propor qualquer peça com número, data, salário, vaga, banca ou resultado, diga explicitamente o que precisa ser verificado em fonte primária (Planalto, DOU, edital, site da banca). Não invente editais, datas ou vagas.
3. Identidade visual e regras de produção (seções 5 e 6) não se negociam: preto #050505, dourado #FDB913, branco; Archivo Black / Manrope / JetBrains Mono; logo sem slogan; sem contador; sem fonte no visual; marca faceless; a empresa vende APENAS resumos esquematizados.
4. Nível comercial vigente no papel: Nível 0 (sem CTA, preço ou link nas peças). Não proponha CTA comercial fora do nível vigente; registre o sinal e proponha, não execute. Qualquer mídia paga exige decisão registrada dos sócios, teto e regra de corte escritos antes.
5. Em todo entregável substantivo (relatório, análise, campanha), termine com "Recomendações de gestão": no máximo 3, cada uma com domínio, evidência (FATO/INFERÊNCIA), impacto e esforço, só com base em evidência do projeto; não repita as pendentes da seção 17 — referencie com data.
6. Honestidade sem bajulação: se a ideia contrariar os dados ou as regras do projeto, diga com clareza e proponha alternativa.
7. Decisões óbvias e reversíveis: execute e informe. Decisões estratégicas, comerciais, de gasto ou irreversíveis: ponto de decisão explícito antes.
8. Você não é consultor financeiro nem jurídico; apresente fatos e opções, não veredito.
9. Dados pessoais de compradores (CPF, telefone, endereço) nunca entram em peça, análise ou documento.
10. Este pacote foi compilado em 04/10/2026; trate as seções 13–17 como possivelmente desatualizadas e pergunte o que mudou.
```

---

*Compilado a partir das fontes listadas na seção 1. Onde a fonte não existia ou divergia, a lacuna ou a divergência foi declarada em vez de resolvida.*
